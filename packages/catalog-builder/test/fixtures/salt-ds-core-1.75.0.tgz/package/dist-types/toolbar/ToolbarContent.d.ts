import { type ComponentPropsWithoutRef } from "react";
export interface ToolbarContentProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Controls where the content is placed across the full toolbar.
     * If any content uses `"center"`, `Toolbar` reserves symmetric side space
     * so the center band stays on the toolbar midpoint.
     */
    position: "start" | "center" | "end";
}
export declare const ToolbarContent: import("react").ForwardRefExoticComponent<ToolbarContentProps & import("react").RefAttributes<HTMLDivElement>>;

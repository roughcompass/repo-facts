import { type FocusEventHandler, type KeyboardEventHandler, type PointerEventHandler, type RefObject } from "react";
import { type ToolbarFocusMemory } from "./toolbarKeyboardUtils";
import type { ToolbarOverflowItem } from "./toolbarUtils";
interface UseToolbarKeyboardNavigationProps {
    includeTabIndexMinusOne?: boolean;
    items?: ToolbarOverflowItem[];
    overflowedIds?: Set<string>;
    scopeRef: RefObject<HTMLElement | null>;
}
interface ToolbarFocusEvent {
    relatedTarget: EventTarget | null;
    stopPropagation: () => void;
    target: EventTarget | null;
}
interface ToolbarKeyDownEvent {
    altKey: boolean;
    ctrlKey: boolean;
    key: string;
    metaKey: boolean;
    preventDefault: () => void;
    shiftKey: boolean;
    stopPropagation: () => void;
    target: EventTarget | null;
}
interface ToolbarPointerEvent {
    target: EventTarget | null;
}
export declare function useToolbarKeyboardNavigation({ includeTabIndexMinusOne, items, overflowedIds, scopeRef, }: UseToolbarKeyboardNavigationProps): {
    focusEntryTarget: () => void;
    getEntryFocusable: () => HTMLElement | null;
    handleBlurCapture: FocusEventHandler<HTMLElement>;
    handleFocusCapture: FocusEventHandler<HTMLElement>;
    handleKeyDownCapture: KeyboardEventHandler<HTMLElement>;
    handlePointerDownCapture: PointerEventHandler<HTMLElement>;
    handleScopeBlur: (event: ToolbarFocusEvent) => void;
    handleScopeFocus: (event: ToolbarFocusEvent) => void;
    handleScopeKeyDown: (event: ToolbarKeyDownEvent) => void;
    handleScopePointerDown: (event: ToolbarPointerEvent) => void;
    rememberItemFocus: (itemId: string, controlIndex: number) => void;
    rememberedFocusRef: import("react").MutableRefObject<ToolbarFocusMemory | null>;
};
export {};

import { type ReactElement, type ReactNode, type Ref } from "react";
import { type ToolbarContentProps } from "./ToolbarContent";
import { type TooltrayProps } from "./Tooltray";
export type ToolbarMode = "explicit" | "flat" | "invalid";
type ToolbarChild = Exclude<ReactNode, boolean | null | undefined>;
type ToolbarContentPosition = ToolbarContentProps["position"];
type TooltrayOverflowMode = NonNullable<TooltrayProps["overflowMode"]>;
export interface ToolbarOverflowItem {
    align: NonNullable<TooltrayProps["align"]>;
    element: ReactElement<TooltrayProps>;
    id: string;
    leadingDecorations: ReactElement[];
    order: number;
    overflowGroup: string;
    overflowGroupKey: string;
    overflowLabel?: string;
    overflowMode: TooltrayOverflowMode;
    overflowPriority: number;
    contentKey: string;
    trailingDecorations: ReactElement[];
}
export interface ToolbarOverflowRenderSlot {
    item: ToolbarOverflowItem;
    overflowed: boolean;
    showLeadingDecorations: boolean;
    showTrailingDecorations: boolean;
    triggerGroupKey?: string;
}
export interface ToolbarContentModel {
    implicit: boolean;
    items: ToolbarOverflowItem[];
    key: string;
    position: ToolbarContentPosition;
    props: Omit<ToolbarContentProps, "children" | "position">;
    ref: Ref<HTMLDivElement> | null;
}
export interface ToolbarModel {
    mode: ToolbarMode;
    content: ToolbarContentModel[];
}
export declare function buildContentOverflowRenderSlots(items: ToolbarOverflowItem[], overflowedIds: Set<string>, activeNamedGroupKeys: Set<string>): ToolbarOverflowRenderSlot[];
export declare function flattenToolbarChildren(children: ReactNode): ToolbarChild[];
export declare function normalizeToolbarChildren(children: ReactNode): ToolbarModel;
export {};

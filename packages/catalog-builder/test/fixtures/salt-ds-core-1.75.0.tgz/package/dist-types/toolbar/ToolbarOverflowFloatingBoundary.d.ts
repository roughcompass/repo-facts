import { type ReactNode } from "react";
interface ToolbarOverflowFloatingBoundaryContextValue {
    isTargetInsideBoundary: (boundaryKey: string, target: EventTarget | null) => boolean;
    registerFloatingRoot: (boundaryKey: string, root: HTMLElement) => () => void;
}
export declare function ToolbarOverflowFloatingBoundaryProvider({ children, }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useToolbarOverflowFloatingBoundary(): ToolbarOverflowFloatingBoundaryContextValue | null;
export declare function isTargetInsideOverflowBoundary(panelContent: HTMLElement | null, floatingBoundary: ToolbarOverflowFloatingBoundaryContextValue | null, boundaryKey: string, target: EventTarget | null): boolean;
export declare function getToolbarOverflowBoundaryKey(host: HTMLElement | null): string | null;
export declare function ToolbarOverflowFloatingComponentProvider({ boundaryKey, children, }: {
    boundaryKey: string | null;
    children: ReactNode;
}): import("react").JSX.Element;
export {};

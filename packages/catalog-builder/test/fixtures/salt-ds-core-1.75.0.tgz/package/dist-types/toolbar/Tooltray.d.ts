import { type ComponentPropsWithoutRef } from "react";
export interface TooltrayProps extends Omit<ComponentPropsWithoutRef<"div">, "align"> {
    /**
     * Alignment of the tooltray.
     * - When a `Tooltray` is used directly inside `Toolbar`, this acts as
     *   shorthand for which toolbar band the tray belongs to.
     * - When a `Tooltray` is used inside `ToolbarContent`, this alignment is
     *   local to that content area.
     *
     * Defaults to `"start"`.
     */
    align?: "start" | "end" | "center";
    /**
     * Controls how this tray participates in `Toolbar` overflow.
     *
     * Defaults to `"independent"`.
     */
    overflowMode?: "none" | "independent" | "grouped";
    /**
     * Higher numbers overflow before lower numbers.
     *
     * Defaults to `0`.
     */
    overflowPriority?: number;
    /**
     * Collapse this tray into the shared overflow or a named local overflow.
     *
     * Defaults to `"shared"`.
     */
    overflowGroup?: "shared" | string;
    /**
     * Accessible label for the named overflow trigger.
     */
    overflowLabel?: string;
}
export declare const Tooltray: import("react").ForwardRefExoticComponent<TooltrayProps & import("react").RefAttributes<HTMLDivElement>>;

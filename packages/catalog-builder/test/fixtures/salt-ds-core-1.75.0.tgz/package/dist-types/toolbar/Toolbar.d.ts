import { type ComponentPropsWithoutRef } from "react";
export interface ToolbarProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Visual treatment of the toolbar. Defaults to `"bordered"`.
     */
    appearance?: "bordered" | "transparent";
    /**
     * Styling variant. Defaults to `"primary"`.
     */
    variant?: "primary" | "secondary" | "tertiary";
}
export declare const Toolbar: import("react").ForwardRefExoticComponent<ToolbarProps & import("react").RefAttributes<HTMLDivElement>>;

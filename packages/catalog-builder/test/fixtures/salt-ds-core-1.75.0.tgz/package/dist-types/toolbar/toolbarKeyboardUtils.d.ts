import type { ToolbarOverflowItem } from "./toolbarUtils";
export declare const TOOLBAR_SCOPE_ROOT_ATTR = "data-salt-toolbar-scope-root";
export declare const TOOLBAR_ITEM_ATTR = "data-salt-toolbar-item-id";
export declare const TOOLBAR_GROUP_KEY_ATTR = "data-salt-toolbar-overflow-group-key";
export declare const TOOLBAR_OVERFLOW_TRIGGER_ATTR = "data-salt-toolbar-overflow-trigger";
export declare const toolbarFocusableSelector: string;
export type ToolbarFocusMemory = {
    controlIndex: number;
    itemId: string;
    scopeIndex: number;
    type: "item";
} | {
    groupKey: string;
    scopeIndex: number;
    type: "overflow-trigger";
} | {
    scopeIndex: number;
    type: "scope";
};
export interface ToolbarFocusableOptions {
    includeTabIndexMinusOne?: boolean;
}
export declare function getClosestToolbarScopeRoot(target: EventTarget | null): HTMLElement | null;
export declare function getToolbarItemId(target: Element | null): string | null;
export declare function isToolbarFocusFromPointerTarget(focusTarget: HTMLElement, pointerTarget: EventTarget | null): boolean;
export declare function getToolbarScopeFocusableElements(scopeRoot: HTMLElement, options?: ToolbarFocusableOptions): HTMLElement[];
export declare function getToolbarFocusMemory(scopeRoot: HTMLElement, target: HTMLElement, options?: ToolbarFocusableOptions): ToolbarFocusMemory | null;
export declare function resolveToolbarFocusTarget(scopeRoot: HTMLElement, focusMemory: ToolbarFocusMemory | null, { includeTabIndexMinusOne, items, overflowedIds, }?: {
    items?: ToolbarOverflowItem[];
    includeTabIndexMinusOne?: boolean;
    overflowedIds?: Set<string>;
}): HTMLElement | null;
export declare function getToolbarDirectionalMoveTarget(scopeRoot: HTMLElement, target: HTMLElement, key: string, options?: ToolbarFocusableOptions): HTMLElement | null;
export declare function getToolbarTabMoveTarget(scopeRoot: HTMLElement, shiftKey: boolean): HTMLElement | null;
export declare function shouldToolbarPreserveNativeTab(target: HTMLElement): boolean;
export declare function isToolbarFocusable(target: HTMLElement, { includeTabIndexMinusOne }?: ToolbarFocusableOptions): boolean;
export declare function focusToolbarElement(target: HTMLElement | null | undefined): void;
export declare function scheduleToolbarFocus(target: HTMLElement | null | undefined, targetWindow?: (Window & typeof globalThis) | null | undefined): () => void;
export declare function getDocumentFocusableElements(ownerDocument: Document): HTMLElement[];

import type { ToolbarContentProps } from "./ToolbarContent";
import { type ToolbarContentModel, type ToolbarOverflowItem } from "./toolbarUtils";
type ToolbarContentPosition = ToolbarContentProps["position"];
interface OverflowGroupDefinition {
    id: string;
    key: string;
    label: string;
    named: boolean;
    order: number;
    overflowGroup: string;
    contentKey?: string;
}
export interface ToolbarOverflowGroup {
    id: string;
    items: ToolbarOverflowItem[];
    key: string;
    label: string;
    named: boolean;
    overflowGroup: string;
    contentKey?: string;
}
interface UseToolbarOverflowProps {
    content: ToolbarContentModel[];
}
export declare function useToolbarOverflow({ content }: UseToolbarOverflowProps): {
    containerRef: import("react").RefObject<HTMLDivElement>;
    getBandRef: (position: ToolbarContentPosition) => (node: HTMLDivElement | null) => void;
    getItemRef: (id: string) => (node: HTMLDivElement | null) => void;
    getNamedTriggerMeasureRef: (id: string) => (node: HTMLDivElement | null) => void;
    getNamedTriggerRef: (id: string) => (node: HTMLDivElement | null) => void;
    getContentRef: (contentKey: string) => (node: HTMLDivElement | null) => void;
    getTriggerMeasureRef: (groupKey: string) => (node: HTMLButtonElement | null) => void;
    isOverflowing: boolean;
    overflowGroups: ToolbarOverflowGroup[];
    overflowedIds: Set<string>;
    overflowTriggerGroups: OverflowGroupDefinition[];
};
export {};

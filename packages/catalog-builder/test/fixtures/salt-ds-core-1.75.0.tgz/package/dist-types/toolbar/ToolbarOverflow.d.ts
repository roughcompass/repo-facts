import { type RefObject } from "react";
import { type ToolbarFocusMemory } from "./toolbarKeyboardUtils";
import type { ToolbarContentModel, ToolbarOverflowItem } from "./toolbarUtils";
import type { ToolbarOverflowGroup } from "./useToolbarOverflow";
export type ToolbarItemHostKind = "main" | "measurement" | "overflow";
interface ToolbarOverflowOwnersProps {
    hostNodes: Record<string, HTMLDivElement | null>;
    items: ToolbarOverflowItem[];
}
export declare function ToolbarOverflowOwners({ hostNodes, items, }: ToolbarOverflowOwnersProps): import("react").JSX.Element;
export declare function ToolbarOverflowTriggerContent({ label, named, }: {
    label: string;
    named: boolean;
}): import("react").JSX.Element;
interface ToolbarOverflowMenuProps {
    focusMemoryRef?: RefObject<ToolbarFocusMemory | null>;
    getItemHostRef: (id: string, kind: ToolbarItemHostKind) => (node: HTMLDivElement | null) => void;
    group: ToolbarOverflowGroup;
    onItemFocus?: (itemId: string, controlIndex: number) => void;
}
export declare function ToolbarOverflowMenu({ focusMemoryRef, getItemHostRef, group, onItemFocus, }: ToolbarOverflowMenuProps): import("react").JSX.Element;
export interface ToolbarOverflowContentProps {
    focusMemoryRef?: RefObject<ToolbarFocusMemory | null>;
    getItemHostRef: (id: string, kind: ToolbarItemHostKind) => (node: HTMLDivElement | null) => void;
    getItemRef: (id: string) => (node: HTMLDivElement | null) => void;
    getNamedTriggerRef: (id: string) => (node: HTMLDivElement | null) => void;
    getContentRef: (contentKey: string) => (node: HTMLDivElement | null) => void;
    onItemFocus?: (itemId: string, controlIndex: number) => void;
    overflowGroups: ToolbarOverflowGroup[];
    overflowedIds: Set<string>;
    content: ToolbarContentModel;
}
export declare function ToolbarOverflowContent({ content, focusMemoryRef, getItemHostRef, getItemRef, getNamedTriggerRef, getContentRef, onItemFocus, overflowGroups, overflowedIds, }: ToolbarOverflowContentProps): import("react").JSX.Element;
export {};

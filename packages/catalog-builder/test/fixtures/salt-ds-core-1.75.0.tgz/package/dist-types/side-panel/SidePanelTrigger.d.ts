import { type ComponentPropsWithoutRef } from "react";
export type SidePanelTriggerProps = ComponentPropsWithoutRef<"button">;
export declare const SidePanelTrigger: import("react").ForwardRefExoticComponent<Omit<import("react").DetailedHTMLProps<import("react").ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;

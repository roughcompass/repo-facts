interface UseSidePanelTabOrderProps {
    floating: HTMLElement | null;
    open: boolean;
    reference: HTMLElement | null;
}
export declare function useSidePanelTabOrder(props: UseSidePanelTabOrderProps): void;
export {};

import { type ComponentPropsWithRef, type RefObject } from "react";
export interface SidePanelProps extends ComponentPropsWithRef<"div"> {
    /**
     * Disable the panel's own open/close animation.
     * Set to `true` when the parent controls sizing and animation (e.g. inside a splitter).
     * @default false
     */
    disableAnimation?: boolean;
    /**
     * Edge the panel is anchored to; controls animation direction and divider side.
     * @default "right"
     */
    position?: "right" | "left";
    /**
     * Which element receives focus when the panel opens.
     * Pass a number for the tabbable element index (0 = first), or a ref to a specific element.
     * Defaults to the first tabbable element inside the panel (close button if present).
     */
    initialFocus?: number | RefObject<HTMLElement | null>;
    /**
     * The background color palette. Options are 'primary', 'secondary', 'tertiary' and 'none'.
     * @default "primary"
     */
    variant?: "primary" | "secondary" | "tertiary" | "none";
}
export declare const SidePanel: import("react").ForwardRefExoticComponent<Omit<SidePanelProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;

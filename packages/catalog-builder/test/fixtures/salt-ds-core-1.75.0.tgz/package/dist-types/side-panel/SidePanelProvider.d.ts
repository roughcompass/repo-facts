import { type ReactNode } from "react";
export interface SidePanelProviderProps {
    /**
     * Whether the panel is open.
     */
    open?: boolean;
    /**
     * Default open state when initially rendered.
     */
    defaultOpen?: boolean;
    /**
     * Callback when open state changes.
     */
    onOpenChange?: (open: boolean) => void;
    /**
     * SidePanelProvider children, should include SidePanel and SidePanelTrigger.
     */
    children: ReactNode;
}
export declare function SidePanelProvider(props: SidePanelProviderProps): import("react").JSX.Element;

import { type RefObject } from "react";
export declare function useIsScrollable(ref: RefObject<HTMLElement | null>): boolean;

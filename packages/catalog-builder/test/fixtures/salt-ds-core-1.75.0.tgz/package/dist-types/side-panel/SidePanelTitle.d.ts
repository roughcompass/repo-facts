import { type TextProps } from "../text";
export type SidePanelTitleProps = TextProps<"div">;
export declare const SidePanelTitle: import("react").ForwardRefExoticComponent<Omit<SidePanelTitleProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;

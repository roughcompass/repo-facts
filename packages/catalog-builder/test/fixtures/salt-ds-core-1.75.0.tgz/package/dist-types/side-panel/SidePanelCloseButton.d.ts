import { type ButtonProps } from "../button";
export declare const SidePanelCloseButton: import("react").ForwardRefExoticComponent<ButtonProps & import("react").RefAttributes<HTMLButtonElement>>;

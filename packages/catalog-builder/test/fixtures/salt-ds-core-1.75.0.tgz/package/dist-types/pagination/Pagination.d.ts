import { type HTMLAttributes, type SyntheticEvent } from "react";
export interface PaginationProps extends HTMLAttributes<HTMLElement> {
    /**
     * Number of pages.
     */
    count: number;
    /**
     * Current/active page.
     */
    page?: number;
    /**
     * Default current/active page.
     */
    defaultPage?: number;
    /**
     * Callback function triggered when current page changed.
     */
    onPageChange?: (event: SyntheticEvent, page: number) => void;
}
export declare const Pagination: import("react").ForwardRefExoticComponent<PaginationProps & import("react").RefAttributes<HTMLElement>>;

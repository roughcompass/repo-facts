export type PageRange = [number, number];
export declare function usePagination(page: number, count: number, boundaryCount: number, siblingCount: number): readonly [PageRange | undefined, PageRange, PageRange | undefined];

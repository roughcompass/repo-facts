import { type InputProps } from "../input";
export declare const CompactInput: import("react").ForwardRefExoticComponent<Pick<InputProps, "variant" | "inputRef"> & import("react").RefAttributes<HTMLInputElement>>;

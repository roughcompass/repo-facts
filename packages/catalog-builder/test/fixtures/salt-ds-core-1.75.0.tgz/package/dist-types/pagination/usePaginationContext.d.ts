export declare const usePaginationContext: () => import("./PaginationContext").PaginationContext;

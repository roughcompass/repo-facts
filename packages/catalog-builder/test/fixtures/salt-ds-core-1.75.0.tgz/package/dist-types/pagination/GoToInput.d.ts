import { type HTMLAttributes, type Ref } from "react";
export interface GoToInputProps extends HTMLAttributes<HTMLSpanElement> {
    /**
     * Input label.
     */
    label?: string;
    /**
     * Optional ref for the input component
     */
    inputRef?: Ref<HTMLInputElement>;
    /**
     * Change input variant.
     */
    inputVariant?: "primary" | "secondary";
}
export declare const GoToInput: import("react").ForwardRefExoticComponent<GoToInputProps & import("react").RefAttributes<HTMLDivElement>>;

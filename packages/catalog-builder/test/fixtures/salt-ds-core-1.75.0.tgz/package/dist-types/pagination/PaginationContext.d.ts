import { type SyntheticEvent } from "react";
export interface PaginationContext {
    page: number;
    count: number;
    onPageChange: (event: SyntheticEvent, page: number) => void;
}
export declare const paginationContext: import("react").Context<PaginationContext>;

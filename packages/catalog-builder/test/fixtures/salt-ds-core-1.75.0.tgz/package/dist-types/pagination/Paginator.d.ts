import { type HTMLAttributes } from "react";
export interface PaginatorProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Number of pages next to the arrow buttons when page range is truncated.
     */
    boundaryCount?: number;
    /**
     * Number of pages on each side of the current page when page range is truncated.
     */
    siblingCount?: number;
}
export declare const Paginator: import("react").ForwardRefExoticComponent<PaginatorProps & import("react").RefAttributes<HTMLDivElement>>;

export interface PageButtonProps {
    page: number;
    selected?: boolean;
    disabled?: boolean;
}
export declare const PageButton: import("react").ForwardRefExoticComponent<PageButtonProps & import("react").RefAttributes<HTMLButtonElement>>;

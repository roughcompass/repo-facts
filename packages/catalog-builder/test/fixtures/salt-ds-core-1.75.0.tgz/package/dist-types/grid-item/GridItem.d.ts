import { type ElementType, type FunctionComponent } from "react";
import { type PolymorphicComponentPropWithRef, type ResponsiveProp } from "../utils";
export declare const GRID_ALIGNMENT_BASE: readonly ["start", "end", "center", "stretch"];
type GridAlignment = (typeof GRID_ALIGNMENT_BASE)[number];
type GridProperty = number | "auto";
export type GridItemProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * The item will span across the provided number of grid columns. Defaults to "auto"
     */
    colSpan?: ResponsiveProp<GridProperty>;
    /**
     * The item will span across the provided number of grid rows. Defaults to "auto"
     */
    rowSpan?: ResponsiveProp<GridProperty>;
    /**
     * Aligns a grid item inside a cell along the inline (row) axis. Defaults to "stretch"
     */
    horizontalAlignment?: GridAlignment;
    /**
     * Aligns a grid item inside a cell along the block (column) axis. Defaults to "stretch"
     */
    verticalAlignment?: GridAlignment;
    /**
     * Defines the margin around the component. It can be specified as a number (which acts as a multiplier) or a string representing the margin value. Default is `0`.
     */
    margin?: ResponsiveProp<number | string>;
    /**
     * Defines the padding within the component. It can be specified as a number (which acts as a multiplier) or a string representing the padding value. Default is `0`.
     */
    padding?: ResponsiveProp<number | string>;
}>;
type GridItemComponent = <T extends ElementType = "div">(props: GridItemProps<T>) => ReturnType<FunctionComponent>;
export declare const GridItem: GridItemComponent;
export {};

import { type ElementType, type FunctionComponent } from "react";
import { type GridItemProps } from "../grid-item";
import { type PolymorphicComponentPropWithRef, type ResponsiveProp } from "../utils";
export declare const BORDER_POSITION: readonly ["north", "west", "center", "east", "south"];
export type BorderPosition = (typeof BORDER_POSITION)[number];
export type BorderItemProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Aligns a grid item inside a cell along the inline (row) axis. Defaults to "stretch"
     */
    horizontalAlignment?: GridItemProps<T>["horizontalAlignment"];
    /**
     * Aligns a grid item inside a cell along the block (column) axis. Defaults to "stretch"
     */
    verticalAlignment?: GridItemProps<T>["verticalAlignment"];
    /**
     * Position in the Border Layout
     */
    position: BorderPosition;
    /**
     * Defines if the item should stick to the edges of its container. Defaults to "false"
     */
    sticky?: boolean;
    /**
     * Defines the margin around the component. It can be specified as a number (which acts as a multiplier) or a string representing the margin value. Default is `0`.
     */
    margin?: ResponsiveProp<number | string>;
    /**
     * Defines the padding within the component. It can be specified as a number (which acts as a multiplier) or a string representing the padding value. Default is `0`.
     */
    padding?: ResponsiveProp<number | string>;
}>;
type BorderItemComponent = <T extends ElementType = "div">(props: BorderItemProps<T>) => ReturnType<FunctionComponent>;
export declare const BorderItem: BorderItemComponent;
export {};

import { type ReactNode } from "react";
export declare function hasOverlaySection(children: ReactNode): boolean;

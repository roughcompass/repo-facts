import { type ReactNode } from "react";
import { type UseFloatingUIProps } from "../utils";
export interface OverlayProps {
    /**
     * The content of the Overlay, typically an `OverlayTrigger` and `OverlayPanel`.
     */
    children?: ReactNode;
    /**
     * Display or hide the component.
     */
    open?: boolean;
    /**
     * Callback function triggered when open state changes.
     */
    onOpenChange?: (open: boolean) => void;
    /**
     * Set the placement of the Overlay component relative to the trigger element. Defaults to `top`.
     */
    placement?: UseFloatingUIProps["placement"];
    /**
     * When `true`, the arrow indicator is hidden
     */
    hideArrow?: boolean;
}
export declare const Overlay: ({ children, open, onOpenChange, placement: placementProp, hideArrow, }: OverlayProps) => import("react").JSX.Element;

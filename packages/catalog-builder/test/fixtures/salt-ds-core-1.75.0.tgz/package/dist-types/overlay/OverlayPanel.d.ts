import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface OverlayPanelProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of Overlay Panel
     */
    children?: ReactNode;
}
export declare const OverlayPanel: import("react").ForwardRefExoticComponent<OverlayPanelProps & import("react").RefAttributes<HTMLDivElement>>;

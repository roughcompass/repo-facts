import { type ReactNode } from "react";
export interface OverlayTriggerProps {
    children?: ReactNode;
}
export declare const OverlayTrigger: import("react").ForwardRefExoticComponent<OverlayTriggerProps & import("react").RefAttributes<HTMLElement>>;

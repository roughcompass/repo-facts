import { type ComponentPropsWithoutRef } from "react";
export interface OverlayFooterProps extends ComponentPropsWithoutRef<"div"> {
}
export declare const OverlayFooter: import("react").ForwardRefExoticComponent<OverlayFooterProps & import("react").RefAttributes<HTMLDivElement>>;

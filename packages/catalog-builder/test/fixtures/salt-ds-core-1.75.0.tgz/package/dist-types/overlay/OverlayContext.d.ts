import type { FloatingArrowProps, FloatingContext, ReferenceType, Strategy } from "@floating-ui/react";
import { type HTMLProps } from "react";
type FloatingStyleProps = {
    top: number;
    left: number;
    position: Strategy;
    width?: number;
    height?: number;
};
export interface OverlayContextValue {
    openState: boolean;
    floatingStyles: FloatingStyleProps;
    arrowProps: FloatingArrowProps;
    hideArrow: boolean;
    context: FloatingContext;
    reference?: (node: ReferenceType | null) => void;
    floating?: (node: HTMLElement | null) => void;
    getFloatingProps: (userProps?: HTMLProps<HTMLElement> | undefined) => Record<string, unknown>;
    getReferenceProps: (userProps?: HTMLProps<Element> | undefined) => Record<string, unknown>;
    headerId?: string;
    setHeaderId?: (id: string | undefined) => void;
    descriptionId?: string;
    setDescriptionId?: (id: string | undefined) => void;
}
export declare const OverlayContext: import("react").Context<OverlayContextValue>;
export declare function useOverlayContext(): OverlayContextValue;
export {};

import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface OverlayHeaderProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Description text is displayed just below the header
     **/
    description?: ReactNode;
    /**
     * Actions to be displayed in header
     */
    actions?: ReactNode;
    /**
     * Header text
     */
    header?: ReactNode;
    /**
     * Preheader text is displayed just above the header
     **/
    preheader?: ReactNode;
}
export declare const OverlayHeader: import("react").ForwardRefExoticComponent<OverlayHeaderProps & import("react").RefAttributes<HTMLDivElement>>;

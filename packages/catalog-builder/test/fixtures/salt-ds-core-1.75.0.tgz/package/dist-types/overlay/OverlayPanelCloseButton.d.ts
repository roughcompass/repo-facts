import { type ButtonProps } from "../button";
export declare const OverlayPanelCloseButton: import("react").ForwardRefExoticComponent<ButtonProps & import("react").RefAttributes<HTMLButtonElement>>;

import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface OverlayPanelContentProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of Overlay Panel Content
     */
    children?: ReactNode;
}
export declare const OverlayPanelContent: import("react").ForwardRefExoticComponent<OverlayPanelContentProps & import("react").RefAttributes<HTMLDivElement>>;

import { type ReactNode, type SyntheticEvent } from "react";
import { type TreeModel, type TreeNodeMeta } from "./treeModel";
export type { TreeModel, TreeNodeMeta } from "./treeModel";
export interface UseTreeProps {
    /**
     * Default expanded nodes (uncontrolled)
     */
    defaultExpanded?: string[];
    /**
     * Expanded nodes (controlled)
     */
    expanded?: string[];
    /**
     * Callback on expanded nodes change
     */
    onExpandedChange?: (event: SyntheticEvent, expanded: string[]) => void;
    /**
     * Default selected nodes (uncontrolled)
     */
    defaultSelected?: string[];
    /**
     * Selected nodes
     */
    selected?: string[];
    /**
     * Callback on selected nodes change
     */
    onSelectionChange?: (event: SyntheticEvent, selected: string[]) => void;
    /**
     * Sets multiselect mode with checkboxes and allows for multiple node selection
     */
    multiselect?: boolean;
    /**
     * Sets tree to disabled state, preventing all interaction
     */
    disabled?: boolean;
    /**
     * Tree children used to build the tree model for traversal an state management
     */
    children?: ReactNode;
}
export declare function useTree(props: UseTreeProps): {
    expandedArray: string[];
    setExpandedArray: import("react").Dispatch<import("react").SetStateAction<string[]>>;
    expandedState: Set<string>;
    toggleExpanded: (event: SyntheticEvent, value: string) => void;
    selectedState: string[];
    selectedSet: Set<string>;
    setSelectedState: import("react").Dispatch<import("react").SetStateAction<string[]>>;
    setVisibleSelectionState: (selection: string[]) => void;
    select: (event: SyntheticEvent, value: string) => void;
    multiselect: boolean;
    disabled: boolean;
    disabledIdsSet: Set<string>;
    treeModel: TreeModel;
    getNodeMeta: (value: string) => TreeNodeMeta | undefined;
    getParent: (value: string) => string | undefined;
    getChildren: (parentValue: string) => string[];
    getDescendants: (value: string) => string[];
    getAncestors: (value: string) => string[];
    visibleNodes: string[];
    tabbableNodeId: string | undefined;
    registerElement: (value: string, element: HTMLElement) => () => void;
    getElement: (value: string) => HTMLElement | undefined;
    activeNode: string | undefined;
    setActiveNode: import("react").Dispatch<import("react").SetStateAction<string | undefined>>;
    indeterminateState: Set<string>;
};

import type { IconProps } from "@salt-ds/icons";
import { type ComponentType, type ReactNode } from "react";
export interface TreeNodeProps {
    /**
     * Unique value representing this node within the tree
     */
    value: string;
    /**
     * Label for the node. When provided, TreeNode automatically renders a TreeNodeTrigger.
     */
    label?: ReactNode;
    /**
     * Optional icon to display before the label
     */
    icon?: ComponentType<IconProps>;
    /**
     * Whether the node is disabled.
     */
    disabled?: boolean;
    /**
     * Child nodes or content.
     */
    children?: ReactNode;
}
export declare const TreeNode: import("react").ForwardRefExoticComponent<TreeNodeProps & import("react").RefAttributes<HTMLLIElement>>;

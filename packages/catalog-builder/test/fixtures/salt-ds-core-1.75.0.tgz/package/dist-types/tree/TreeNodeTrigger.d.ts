import { type ComponentPropsWithoutRef } from "react";
export interface TreeNodeTriggerProps extends ComponentPropsWithoutRef<"li"> {
}
/**
 * The forwarded ref points to the inner trigger content span (for tooltip positioning),
 * while the <li> handles focus, ARIA, and event handling.
 */
export declare const TreeNodeTrigger: import("react").ForwardRefExoticComponent<TreeNodeTriggerProps & import("react").RefAttributes<HTMLSpanElement>>;

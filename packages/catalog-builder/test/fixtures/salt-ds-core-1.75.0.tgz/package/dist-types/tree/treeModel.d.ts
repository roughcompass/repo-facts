import { type ReactElement, type ReactNode } from "react";
export interface TreeNodeMeta {
    value: string;
    parentValue: string | undefined;
    hasChildren: boolean;
    disabled: boolean;
}
export interface TreeModel {
    /** All nodes indexed by value */
    nodes: Map<string, TreeNodeMeta>;
    /** Ordered list of root node values */
    rootValues: string[];
    /** Maps parent value to ordered list of child values */
    childrenOf: Map<string, string[]>;
}
interface TreeNodeElementProps {
    value: string;
    disabled?: boolean;
    children?: ReactNode;
}
export declare function isTreeNodeElement(child: ReactNode): child is ReactElement<TreeNodeElementProps>;
export declare function flattenTreeNodeChildren(children: ReactNode): ReactNode[];
export declare function buildTreeModel(children: ReactNode): TreeModel;
export {};

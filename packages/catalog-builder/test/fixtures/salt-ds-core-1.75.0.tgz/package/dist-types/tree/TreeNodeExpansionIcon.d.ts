import { type ComponentPropsWithoutRef } from "react";
export interface TreeNodeExpansionIconProps extends ComponentPropsWithoutRef<"span"> {
}
export declare const TreeNodeExpansionIcon: import("react").ForwardRefExoticComponent<TreeNodeExpansionIconProps & import("react").RefAttributes<HTMLSpanElement>>;

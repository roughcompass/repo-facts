import { type ComponentPropsWithoutRef } from "react";
export interface TreeNodeLabelProps extends ComponentPropsWithoutRef<"span"> {
}
export declare const TreeNodeLabel: import("react").ForwardRefExoticComponent<TreeNodeLabelProps & import("react").RefAttributes<HTMLSpanElement>>;

import { type ComponentPropsWithoutRef, type SyntheticEvent } from "react";
export interface TreeProps extends ComponentPropsWithoutRef<"ul"> {
    /**
     * Default expanded nodes (uncontrolled)
     */
    defaultExpanded?: string[];
    /**
     * Expanded nodes (controlled)
     */
    expanded?: string[];
    /**
     * Callback on expanded nodes change
     */
    onExpandedChange?: (event: SyntheticEvent, expanded: string[]) => void;
    /**
     * Default selected nodes (uncontrolled)
     */
    defaultSelected?: string[];
    /**
     * Selected nodes
     */
    selected?: string[];
    /**
     * Callback on selected nodes change
     */
    onSelectionChange?: (event: SyntheticEvent, selected: string[]) => void;
    /**
     * Sets multiselect mode with checkboxes and allows for multiple node selection
     */
    multiselect?: boolean;
    /**
     * Sets tree to disabled state, preventing all interaction
     */
    disabled?: boolean;
}
export declare const Tree: import("react").ForwardRefExoticComponent<TreeProps & import("react").RefAttributes<HTMLUListElement>>;

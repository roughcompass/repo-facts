import { type Key, type ReactElement, type ReactNode } from "react";
import type { BreadcrumbProps } from "../Breadcrumb";
export interface NormalizedBreadcrumb {
    element: ReactElement<BreadcrumbProps>;
    index: number;
    key: Key;
    props: BreadcrumbProps;
}
export declare function flattenBreadcrumbItems(children: ReactNode): ReactNode[];

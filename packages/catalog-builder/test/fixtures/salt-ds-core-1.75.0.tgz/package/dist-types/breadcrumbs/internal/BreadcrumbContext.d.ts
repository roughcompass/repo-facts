import { type Ref } from "react";
import type { RenderPropsType } from "../../utils";
export type BreadcrumbPlacement = "disclosure" | "trail";
export interface BreadcrumbContextValue {
    current: boolean;
    href?: string;
    onNavigate?: () => void;
    placement: BreadcrumbPlacement;
    render?: RenderPropsType["render"];
    showSeparator: boolean;
    triggerRef?: Ref<HTMLAnchorElement>;
}
export declare const BreadcrumbContext: import("react").Context<BreadcrumbContextValue | undefined>;
export declare function useBreadcrumbContext(): BreadcrumbContextValue | undefined;

import { type ComponentPropsWithoutRef, type ReactNode } from "react";
import { type RenderPropsType } from "../utils";
export interface BreadcrumbProps extends Omit<ComponentPropsWithoutRef<"li">, "children"> {
    /**
     * Custom breadcrumb content. Use this for advanced composition with
     * `BreadcrumbTrigger` and `BreadcrumbLabel`.
     */
    children?: ReactNode;
    /**
     * If `true`, the breadcrumb represents the current page.
     */
    current?: boolean;
    /**
     * The URL for the breadcrumb. Provide this for the current breadcrumb so it
     * renders as a focusable link with `aria-current="page"`.
     */
    href?: string;
    /**
     * Render prop to enable customization of the underlying link element.
     */
    render?: RenderPropsType["render"];
}
export declare const Breadcrumb: import("react").ForwardRefExoticComponent<BreadcrumbProps & import("react").RefAttributes<HTMLLIElement>>;

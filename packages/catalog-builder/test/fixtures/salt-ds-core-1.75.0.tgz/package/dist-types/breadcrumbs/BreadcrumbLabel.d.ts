import { type ComponentPropsWithoutRef } from "react";
export interface BreadcrumbLabelProps extends ComponentPropsWithoutRef<"span"> {
}
export declare const BreadcrumbLabel: import("react").ForwardRefExoticComponent<BreadcrumbLabelProps & import("react").RefAttributes<HTMLSpanElement>>;

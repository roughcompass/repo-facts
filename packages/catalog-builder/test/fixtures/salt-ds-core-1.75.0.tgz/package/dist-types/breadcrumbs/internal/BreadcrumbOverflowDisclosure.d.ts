import { type RenderPropsType } from "../../utils";
import type { NormalizedBreadcrumb } from "./breadcrumbItems";
interface BreadcrumbOverflowDisclosureProps {
    currentIndex: number;
    items: NormalizedBreadcrumb[];
    render?: RenderPropsType["render"];
}
export declare function BreadcrumbOverflowDisclosure({ currentIndex, items, render, }: BreadcrumbOverflowDisclosureProps): import("react").JSX.Element;
export {};

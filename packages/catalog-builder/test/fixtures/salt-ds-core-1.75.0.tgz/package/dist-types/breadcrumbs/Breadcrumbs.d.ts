import { type ComponentPropsWithoutRef, type ReactNode } from "react";
import { type RenderPropsType } from "../utils";
export interface BreadcrumbsProps extends Omit<ComponentPropsWithoutRef<"nav">, "children"> {
    /**
     * Breadcrumb items.
     */
    children?: ReactNode;
    /**
     * The number of items to keep after the collapse point.
     * Defaults to 1.
     */
    itemsAfterCollapse?: number;
    /**
     * The number of items to keep before the collapse point.
     * Defaults to 1.
     */
    itemsBeforeCollapse?: number;
    /**
     * The maximum number of breadcrumbs to render before collapsing.
     */
    maxItems?: number;
    /**
     * Render prop to enable customization of the underlying link elements.
     */
    render?: RenderPropsType["render"];
    /**
     * If `true`, breadcrumbs can wrap onto multiple lines.
     * Defaults to `false`.
     */
    wrap?: boolean;
}
export declare const Breadcrumbs: import("react").ForwardRefExoticComponent<BreadcrumbsProps & import("react").RefAttributes<HTMLElement>>;

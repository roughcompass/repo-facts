import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface BreadcrumbTriggerProps extends Omit<ComponentPropsWithoutRef<"a">, "children" | "color" | "href"> {
    /**
     * Breadcrumb trigger content.
     */
    children?: ReactNode;
}
export declare const BreadcrumbTrigger: import("react").ForwardRefExoticComponent<BreadcrumbTriggerProps & import("react").RefAttributes<HTMLAnchorElement>>;

import type { IconProps } from "@salt-ds/icons";
import { type ComponentPropsWithoutRef, type ComponentType } from "react";
import { type TextProps } from "../text";
import { type RenderPropsType } from "../utils";
/**
 * Links are a fundamental navigation element. When clicked, they take the user to an entirely different page.
 *
 * @example
 * <LinkExample to="#link">Action</LinkExample>
 */
export interface LinkProps extends Omit<ComponentPropsWithoutRef<"a">, "color">, Pick<TextProps<"a">, "maxRows" | "styleAs" | "variant"> {
    /**
     * Icon component displayed for external links. Defaults to `ExternalIcon` from `SemanticIconProvider`.
     */
    IconComponent?: ComponentType<IconProps> | null;
    /**
     * Render prop to enable customisation of anchor element.
     */
    render?: RenderPropsType["render"];
    color?: "inherit" | "primary" | "secondary" | "accent";
    /**
     *
     * Either "default" or "never".
     * Determines when underline should be applied to the link.
     *
     * @default "default".
     */
    underline?: "default" | "never";
}
export declare const Link: import("react").ForwardRefExoticComponent<LinkProps & import("react").RefAttributes<HTMLAnchorElement>>;

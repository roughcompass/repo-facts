import { type ComponentPropsWithoutRef, type ReactNode } from "react";
interface LinkActionProps extends ComponentPropsWithoutRef<"a"> {
    externalLinkContent?: ReactNode;
}
export declare const LinkAction: import("react").ForwardRefExoticComponent<LinkActionProps & import("react").RefAttributes<HTMLAnchorElement>>;
export {};

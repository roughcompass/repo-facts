import { type ElementType, type FunctionComponent, type ReactNode } from "react";
import { type FlexLayoutProps } from "../flex-layout";
import { type PolymorphicComponentPropWithRef } from "../utils";
export type SplitLayoutProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Defines the default behavior for how flex items are laid out along the cross axis on the current line.
     */
    align?: FlexLayoutProps<ElementType>["align"];
    /**
     * Establishes the main-axis, defining the direction children are placed. Default is "row".
     */
    direction?: FlexLayoutProps<ElementType>["direction"];
    /**
     * End component to be rendered.
     */
    endItem?: ReactNode;
    /**
     * Controls the space between left and right items.
     */
    gap?: FlexLayoutProps<ElementType>["gap"];
    /**
     * Start component to be rendered.
     */
    startItem?: ReactNode;
    /**
     * Defines the margin around the component. It can be specified as a number (which acts as a multiplier) or a string representing the margin value. Default is `0`.
     */
    margin?: FlexLayoutProps<ElementType>["margin"];
    /**
     * Defines the padding within the component. It can be specified as a number (which acts as a multiplier) or a string representing the padding value. Default is `0`.
     */
    padding?: FlexLayoutProps<ElementType>["padding"];
}>;
type SplitLayoutComponent = <T extends ElementType = "div">(props: SplitLayoutProps<T>) => ReturnType<FunctionComponent>;
export declare const SplitLayout: SplitLayoutComponent;
export {};

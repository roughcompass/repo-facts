import { type ElementType, type FunctionComponent } from "react";
import { type FlexLayoutProps, type LayoutDirection, type LayoutSeparator } from "../flex-layout";
import { type PolymorphicComponentPropWithRef, type ResponsiveProp } from "../utils";
export type StackLayoutProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Defines the default behavior for how flex items are laid out along the cross axis on the current line, default is "stretch".
     */
    align?: FlexLayoutProps<ElementType>["align"];
    /**
     * Establishes the main-axis, defining the direction children are placed. Default is "column".
     */
    direction?: ResponsiveProp<LayoutDirection>;
    /**
     * Controls the space between items, default is 3.
     */
    gap?: FlexLayoutProps<ElementType>["gap"];
    /**
     * Adds a separator between elements, default is false.
     */
    separators?: LayoutSeparator | boolean;
    /**
     * Defines the margin around the component. It can be specified as a number (which acts as a multiplier) or a string representing the margin value. Default is `0`.
     */
    margin?: FlexLayoutProps<ElementType>["margin"];
    /**
     * Defines the padding within the component. It can be specified as a number (which acts as a multiplier) or a string representing the padding value. Default is `0`.
     */
    padding?: FlexLayoutProps<ElementType>["padding"];
}>;
type StackLayoutComponent = <T extends ElementType = "div">(props: StackLayoutProps<T>) => ReturnType<FunctionComponent>;
export declare const StackLayout: StackLayoutComponent;
export {};

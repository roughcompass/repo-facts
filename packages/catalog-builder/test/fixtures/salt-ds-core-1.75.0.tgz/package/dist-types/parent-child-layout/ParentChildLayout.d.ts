import { type ComponentPropsWithoutRef, type ReactNode } from "react";
import type { Breakpoints } from "../breakpoints";
export interface ParentChildLayoutProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Breakpoint at which the parent and child will stack.
     */
    collapseAtBreakpoint?: keyof Breakpoints;
    /**
     * View that is displayed when in a collapsed state.
     */
    visibleView?: "child" | "parent";
    /**
     * Controls the space between parent and child components, default is 0.
     */
    gap?: number;
    /**
     * Parent component to be rendered
     */
    parent: ReactNode;
    /**
     * Child component to be rendered
     */
    child: ReactNode;
    /**
     * Function called when the viewport size equal to or less than the collapseAtBreakpoint variable
     */
    onCollapseChange?: (isCollapsed: boolean) => void;
}
export declare const ParentChildLayout: import("react").ForwardRefExoticComponent<ParentChildLayoutProps & import("react").RefAttributes<HTMLDivElement>>;

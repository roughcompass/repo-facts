import type { Breakpoints } from "../breakpoints";
export declare const useIsViewportLargerThanBreakpoint: (targetedBreakpoint: keyof Breakpoints) => boolean;

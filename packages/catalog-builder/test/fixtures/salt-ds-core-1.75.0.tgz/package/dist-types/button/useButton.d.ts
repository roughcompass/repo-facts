import { type FocusEvent, type KeyboardEvent, type MouseEvent } from "react";
export interface ButtonHookProps<T extends Element> {
    loading?: boolean;
    disabled?: boolean;
    focusableWhenDisabled?: boolean;
    onKeyUp?: (event: KeyboardEvent<T>) => void;
    onKeyDown?: (event: KeyboardEvent<T>) => void;
    onClick?: (event: MouseEvent<T>) => void;
    onBlur?: (event: FocusEvent<T>) => void;
}
export interface ButtonHookResult<T extends Element> {
    active: boolean;
    buttonProps: {
        "aria-disabled"?: boolean;
        "data-loading"?: boolean;
        disabled?: boolean;
        tabIndex: number;
        onBlur: (event: FocusEvent<T>) => void;
        onClick?: (event: MouseEvent<T>) => void;
        onKeyDown: (event: KeyboardEvent<T>) => void;
        onKeyUp: (event: KeyboardEvent<T>) => void;
    };
}
export declare const useButton: <T extends Element>({ loading, disabled, focusableWhenDisabled, onKeyUp, onKeyDown, onClick, onBlur, }: ButtonHookProps<T>) => ButtonHookResult<T>;

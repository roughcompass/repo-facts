import { type ComponentPropsWithoutRef } from "react";
export interface ButtonVariants {
    primary: string;
    secondary: string;
    cta: string;
}
export type ButtonVariant = keyof ButtonVariants;
export declare const ButtonVariantValues: readonly ["primary", "secondary", "cta"];
export interface ButtonAppearances {
    solid: string;
    bordered: string;
    transparent: string;
}
export type ButtonAppearance = keyof ButtonAppearances;
export declare const ButtonAppearanceValues: readonly ["solid", "bordered", "transparent"];
export interface ButtonSentiments {
    accented: string;
    neutral: string;
    positive: string;
    negative: string;
    caution: string;
}
export type ButtonSentiment = keyof ButtonSentiments;
export declare const ButtonSentimentValues: readonly ["accented", "neutral", "positive", "negative", "caution"];
export interface ButtonProps extends ComponentPropsWithoutRef<"button"> {
    /**
     * If `true`, the button will be disabled.
     */
    disabled?: boolean;
    /**
     * If `true`, the button will be focusable when disabled.
     */
    focusableWhenDisabled?: boolean;
    /**
     * The variant to use. Options are 'primary', 'secondary' and 'cta'.
     * 'primary' is the default value.
     *
     * @deprecated since 1.36.0. Use `appearance` and `sentiment` instead.
     *
     * | variant     | appearance    | sentiment   |
     * | ----------- | ------------- | ----------- |
     * | `cta`       | `solid`       | `accented`  |
     * | `primary`   | `solid`       | `neutral`   |
     * | `secondary` | `transparent` | `neutral`   |
     */
    variant?: ButtonVariant;
    /**
     * The appearance of the button. Options are 'solid', 'bordered', and 'transparent'.
     * 'solid' is the default value.
     *
     * @since 1.36.0.
     */
    appearance?: ButtonAppearance;
    /**
     * The sentiment of the button. Options are 'accented', 'neutral', 'positive', 'negative' and 'caution'.
     * 'neutral' is the default value.
     *
     * @since 1.36.0.
     */
    sentiment?: ButtonSentiment;
    /**
     * If `true`, the button will be in a loading state. This allows a spinner to be nested inside the button.
     *
     * @since 1.38.0.
     */
    loading?: boolean;
    /**
     * Text to be announced by screen readers, intended to be used in conjunction with the `loading` prop.
     *
     * @since 1.38.0.
     */
    loadingAnnouncement?: string;
}
export declare const Button: import("react").ForwardRefExoticComponent<ButtonProps & import("react").RefAttributes<HTMLButtonElement>>;

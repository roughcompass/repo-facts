import { type ComponentPropsWithoutRef, type ReactNode } from "react";
interface BannerActionsProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of BannerActions
     */
    children: ReactNode;
}
export declare const BannerActions: import("react").ForwardRefExoticComponent<BannerActionsProps & import("react").RefAttributes<HTMLDivElement>>;
export {};

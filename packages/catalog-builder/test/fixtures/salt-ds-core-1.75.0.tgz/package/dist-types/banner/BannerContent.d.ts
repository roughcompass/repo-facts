import { type ComponentPropsWithoutRef, type ReactNode } from "react";
interface BannerContentProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of BannerContent
     */
    children: ReactNode;
}
export declare const BannerContent: import("react").ForwardRefExoticComponent<BannerContentProps & import("react").RefAttributes<HTMLDivElement>>;
export {};

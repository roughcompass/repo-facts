import { type HTMLAttributes } from "react";
import { type ValidationStatus } from "../status-indicator";
export interface BannerProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Emphasize the styling by applying a background color: defaults to false
     */
    variant?: "primary" | "secondary";
    /**
     *  A string to determine the current state of the Banner
     */
    status?: ValidationStatus;
}
export declare const Banner: import("react").ForwardRefExoticComponent<BannerProps & import("react").RefAttributes<HTMLDivElement>>;

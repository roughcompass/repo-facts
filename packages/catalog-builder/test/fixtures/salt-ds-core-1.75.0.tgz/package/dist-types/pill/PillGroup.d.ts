import { type ComponentPropsWithoutRef, type SyntheticEvent } from "react";
interface CommonPillGroupProps extends ComponentPropsWithoutRef<"fieldset"> {
    /**
     * If `true`, the Pill group will be disabled.
     */
    disabled?: boolean;
    /**
     * Selection variant of the Pill group. If "none", the Pills will not be selectable. If "multiple", pills inside behave like checkboxes.
     */
    selectionVariant?: "none" | "multiple";
}
interface SelectablePillGroupProps extends CommonPillGroupProps {
    selectionVariant: "multiple";
    /**
     * The currently selected values.
     */
    selected?: string[];
    /**
     * The default selected values for un-controlled component.
     */
    defaultSelected?: string[];
    /**
     * Callback fired when the selection changes.
     * @param event
     * @param newSelected The new selected values.
     */
    onSelectionChange?: (event: SyntheticEvent, newSelected: string[]) => void;
}
interface NonSelectablePillGroupProps extends CommonPillGroupProps {
    selectionVariant?: "none";
}
export type PillGroupProps = SelectablePillGroupProps | NonSelectablePillGroupProps;
export declare const PillGroup: import("react").ForwardRefExoticComponent<PillGroupProps & import("react").RefAttributes<HTMLFieldSetElement>>;
export {};

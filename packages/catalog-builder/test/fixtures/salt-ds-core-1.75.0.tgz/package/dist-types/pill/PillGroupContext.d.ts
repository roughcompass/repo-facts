import { type SyntheticEvent } from "react";
export interface PillGroupContextValue {
    selected: string[];
    select: (e: SyntheticEvent, value: string) => void;
    disabled?: boolean;
    selectionVariant: "none" | "multiple";
}
export declare const PillGroupContext: import("react").Context<PillGroupContextValue>;
export declare function usePillGroup(): PillGroupContextValue;

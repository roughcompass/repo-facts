import type { ReactElement } from "react";
export interface PillCheckIconProps {
    checked?: boolean;
    className?: string;
    disabled?: boolean;
    active?: boolean;
}
export declare const PillCheckIcon: ({ className, checked, disabled, active, }: PillCheckIconProps) => ReactElement;

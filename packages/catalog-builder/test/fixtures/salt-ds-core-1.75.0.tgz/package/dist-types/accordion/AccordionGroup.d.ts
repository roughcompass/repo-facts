import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface AccordionGroupProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The child Accordions to be rendered
     */
    children?: ReactNode;
}
export declare const AccordionGroup: import("react").ForwardRefExoticComponent<AccordionGroupProps & import("react").RefAttributes<HTMLDivElement>>;

import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface AccordionPanelProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of the Accordion Panel
     */
    children?: ReactNode;
}
export declare const AccordionPanel: import("react").ForwardRefExoticComponent<AccordionPanelProps & import("react").RefAttributes<HTMLDivElement>>;

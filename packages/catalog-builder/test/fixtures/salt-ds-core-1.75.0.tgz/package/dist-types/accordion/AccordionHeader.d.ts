import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface AccordionHeaderProps extends ComponentPropsWithoutRef<"button"> {
    /**
     * The content of the Accordion Header
     */
    children?: ReactNode;
}
export declare const AccordionHeader: import("react").ForwardRefExoticComponent<AccordionHeaderProps & import("react").RefAttributes<HTMLButtonElement>>;

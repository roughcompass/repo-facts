import { type ComponentPropsWithoutRef, type SyntheticEvent } from "react";
export interface AccordionProps extends Omit<ComponentPropsWithoutRef<"div">, "onToggle"> {
    /**
     * Optional value used by controlled group patterns.
     */
    value?: string;
    /**
     * Whether the accordion is expanded.
     */
    expanded?: boolean;
    /**
     * Whether the accordion is expanded by default.
     */
    defaultExpanded?: boolean;
    /**
     * Side to align the Accordion's indicator. Defaults to `left`.
     */
    indicatorSide?: "left" | "right";
    /**
     * Callback fired when the accordion is toggled.
     */
    onToggle?: (event: SyntheticEvent<HTMLButtonElement>) => void;
    /**
     * Whether the accordion is disabled.
     */
    disabled?: boolean;
    /**
     * The status of the accordion.
     */
    status?: "error" | "warning" | "success";
}
export declare const Accordion: import("react").ForwardRefExoticComponent<AccordionProps & import("react").RefAttributes<HTMLDivElement>>;

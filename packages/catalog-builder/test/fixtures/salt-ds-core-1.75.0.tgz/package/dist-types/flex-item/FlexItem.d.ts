import { type CSSProperties, type ElementType, type FunctionComponent } from "react";
import { type PolymorphicComponentPropWithRef, type ResponsiveProp } from "../utils";
export declare const FLEX_ITEM_ALIGNMENTS: readonly ["start", "end", "center", "stretch"];
export type flexItemAlignment = (typeof FLEX_ITEM_ALIGNMENTS)[number];
export type FlexItemProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Allows the alignment specified by parent to be overridden for individual items, default is "start".
     */
    align?: flexItemAlignment;
    /**
     * Defines the ability for an item to shrink x times more compared to its siblings, default is 1.
     */
    shrink?: ResponsiveProp<number>;
    /**
     * Defines the ability for an item to grow x times more compared to its siblings, default is 0.
     */
    grow?: ResponsiveProp<number>;
    /**
     * Sets the initial main size of a flex item, default is "auto".
     */
    basis?: ResponsiveProp<CSSProperties["flexBasis"]>;
    /**
     * Defines the margin around the component. It can be specified as a number (which acts as a multiplier) or a string representing the margin value. Default is `0`.
     */
    margin?: ResponsiveProp<number | string>;
    /**
     * Defines the padding within the component. It can be specified as a number (which acts as a multiplier) or a string representing the padding value. Default is `0`.
     */
    padding?: ResponsiveProp<number | string>;
}>;
type FlexItemComponent = <T extends ElementType = "div">(props: FlexItemProps<T>) => ReturnType<FunctionComponent>;
export declare const FlexItem: FlexItemComponent;
export {};

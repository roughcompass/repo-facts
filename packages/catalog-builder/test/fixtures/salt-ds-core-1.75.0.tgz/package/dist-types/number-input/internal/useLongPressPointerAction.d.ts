import { type PointerEvent } from "react";
export declare function useLongPressPointerAction(actionFn: (event?: PointerEvent) => void, isAtLimit: boolean): (event: PointerEvent) => void;

import { type ComponentPropsWithoutRef, type InputHTMLAttributes, type ReactNode, type Ref, type SyntheticEvent } from "react";
import { type FormFieldValidationStatus } from "../form-field-context";
export interface NumberInputProps extends Omit<ComponentPropsWithoutRef<"div">, "onChange" | "defaultValue" | "value"> {
    /**
     * Styling variant with full border.
     * @default false
     */
    bordered?: boolean;
    /**
     * A boolean that, when true, ensures the input value is clamped within the specified min and max range upon losing focus.
     * @default false
     */
    clamp?: boolean;
    /**
     * Number of decimal places allowed (only used by default parser/formatter).
     * Defaults to the decimal scale of either the initial value provided or the step, whichever is greater.
     * For high precision of larger numbers, consider a custom parser/formatter from a third-party library.
     */
    decimalScale?: number;
    /**
     * Custom decrement function to override the default increment behavior, use when higher precision or large numbers are required
     * value: current value
     * step: step value
     * stepMultiplier: step multiplier value, when using shift key navigation
     */
    decrement?: (value: string, step: number, stepMultiplier: number) => string;
    /**
     * The default value. Use when the component is uncontrolled.
     */
    defaultValue?: number | string;
    /**
     * Disable the `NumberInput`.
     * @default false
     */
    disabled?: boolean;
    /**
     * The marker to use in an empty read only Input.
     * @default "—"
     */
    emptyReadOnlyMarker?: string;
    /**
     * End adornment component.
     */
    endAdornment?: ReactNode;
    /**
     * Callback to format the NumberInput value.
     * For high precision or large numbers, consider creating a custom parser/format using a third-party library.
     */
    format?: (value: string) => string;
    /**
     * Hide the number buttons.
     * @default false
     */
    hideButtons?: boolean;
    /**
     * Custom increment function to override the default increment behavior, use when higher precision or large numbers are required
     * value: current value
     * step: step value
     * stepMultiplier: step multiplier value, when using shift key navigation
     */
    increment?: (value: string, step: number, stepMultiplier: number) => string;
    /**
     * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element.
     */
    inputProps?: InputHTMLAttributes<HTMLInputElement>;
    /**
     * Optional ref for the input component.
     */
    inputRef?: Ref<HTMLInputElement>;
    /**
     * Callback that matches on values as you type and determines whether the value can be entered.
     */
    pattern?: (inputValue: string) => boolean;
    /**
     * The maximum value that can be selected.
     * @default Number.MAX_SAFE_INTEGER
     */
    max?: number;
    /**
     * The minimum value that can be selected.
     * @default Number.MIN_SAFE_INTEGER
     */
    min?: number;
    /**
     * The name applied to the input.
     */
    name?: string;
    /**
     * Callback function that is triggered when the value changes via user input or increment/decrement.
     * Use `onNumberChange` if you want stable number, after blur or through increment/decrement
     *
     * @param event - The event that triggers the value change, can be null if called by long-press of increment/decrement
     * @param value - value as string
     */
    onChange?: (event: SyntheticEvent | null, value: string) => void;
    /**
     * Callback function that is triggered when the value changes via increment/decrement or on blur.
     *
     * @param event - The event that triggers the change, can be null if called by long-press of increment/decrement
     * @param value - The committed, parsed number value or null if an empty value
     */
    onNumberChange?: (event: SyntheticEvent | null, value: number | null) => void;
    /**
     * Callback to parse the NumberInput value, used with the `format` callback.
     * For high precision or large numbers, consider creating a custom parser/format using a third-party library.   * Return null for empty input.
     */
    parse?: (value: string) => number | null;
    /**
     * A string displayed in a dimmed color when the `NumberInput` value is empty.
     */
    placeholder?: string;
    /**
     * A boolean property that controls the read-only state of the `NumberInput`.
     * - When set to `true`, the `NumberInput` becomes read-only, preventing user edits.
     * - When set to `false` or omitted, the `NumberInput` is editable by the user.
     */
    readOnly?: boolean;
    /**
     * Start adornment component.
     */
    startAdornment?: ReactNode;
    /**
     * The amount to increment or decrement the value by when using the `NumberInput` buttons or Up Arrow and Down Arrow keys.
     * @default 1
     */
    step?: number;
    /**
     * Defines the factor by which the step value is multiplied to determine the maximum increment or decrement when the Shift key
     * is held while pressing the Up Arrow or Down Arrow keys for faster adjustments of the value.
     * @default 2
     */
    stepMultiplier?: number;
    /**
     * Specifies the alignment of the text within the `NumberInput`.
     *
     * @default "left"
     */
    textAlign?: "left" | "center" | "right";
    /**
     * Validation status.
     */
    validationStatus?: FormFieldValidationStatus;
    /**
     * Styling variant.
     * @default "primary"
     */
    variant?: "primary" | "secondary" | "tertiary";
    /**
     * Value of the `NumberInput`, to be used when in a controlled state.
     */
    value?: number | string;
}
export declare const isOutOfRange: (value: number | string, min: number, max: number) => boolean;
export declare const NumberInput: import("react").ForwardRefExoticComponent<NumberInputProps & import("react").RefAttributes<HTMLDivElement>>;

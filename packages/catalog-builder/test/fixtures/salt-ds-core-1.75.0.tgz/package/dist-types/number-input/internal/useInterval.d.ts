type IntervalFunction = () => void;
declare function useInterval(callback: IntervalFunction, delay: number | null): void;
export { useInterval };

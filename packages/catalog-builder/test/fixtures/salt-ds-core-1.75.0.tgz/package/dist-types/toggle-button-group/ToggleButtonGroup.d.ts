import { type ComponentPropsWithoutRef, type SyntheticEvent } from "react";
import type { ButtonAppearance, ButtonSentiment } from "../button";
import { type Value } from "./ToggleButtonGroupContext";
export interface ToggleButtonGroupProps extends Omit<ComponentPropsWithoutRef<"div">, "onChange"> {
    /**
     * The appearance of all the toggle buttons within the group.
     * @default solid
     */
    appearance?: Extract<ButtonAppearance, "bordered" | "solid">;
    /**
     * The default value. Use when the component is not controlled.
     */
    defaultValue?: Value;
    /**
     * If `true`, the Toggle Button Group will be disabled.
     */
    disabled?: boolean;
    /**
     * Value of the toggle button group, to be used when the component is controlled.
     */
    value?: Value;
    /**
     * Callback fired when the selection changes.
     */
    onChange?: (event: SyntheticEvent<HTMLButtonElement>) => void;
    /**
     * If `true`, the toggle button group will be read-only.
     */
    readOnly?: boolean;
    /**
     * The orientation of the toggle buttons.
     */
    orientation?: "horizontal" | "vertical";
    /**
     * The visual sentimenent of all the toggle buttons within the group.
     * @default neutral
     */
    sentiment?: ButtonSentiment;
}
export declare const ToggleButtonGroup: import("react").ForwardRefExoticComponent<ToggleButtonGroupProps & import("react").RefAttributes<HTMLDivElement>>;

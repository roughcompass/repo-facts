import { type HTMLAttributes } from "react";
export interface SliderProps extends Omit<HTMLAttributes<HTMLDivElement>, "onChange" | "defaultValue"> {
    /**
     * Accessible text to announce maximum value label.
     */
    accessibleMaxText?: string;
    /**
     * Accessible text to announce minimum value label.
     */
    accessibleMinText?: string;
    /**
     * When minimum and maximum labels are defined, ensure
     * they are confined within the boundary of the slider.
     * @default false
     */
    constrainLabelPosition?: boolean;
    /**
     * The number of allowed decimal places
     * @default 2
     */
    decimalPlaces?: number;
    /**
     * The default value. Use when the component is not controlled.
     * @default min + (max - min) / 2,
     */
    defaultValue?: number;
    /**
     * Disable the slider.
     */
    disabled?: boolean;
    /**
     * A callback to format the display value in the tooltip, min and max labels
     * and the `aria-valuetext` attribute.
     */
    format?: (value: number) => string | number;
    /**
     * Marks that are displayed under the track.
     */
    marks?: {
        label: string;
        value: number;
    }[];
    /**
     * Maximum slider value.
     * @default 10
     */
    max?: number;
    /**
     * Minimum slider value.
     * @default 0
     */
    min?: number;
    /**
     * Label for maximum value.
     */
    maxLabel?: string;
    /**
     * Label for the minimum value.
     */
    minLabel?: string;
    /**
     * The name applied to the input.
     */
    name?: string;
    /**
     * Callback called when slider value is changed.
     * It provides a generic event and the current value of the slider.
     */
    onChange?: (event: Event, value: number) => void;
    /**
     * Callback called when the slider is stopped from being dragged or
     * its value is changed from the keyboard. It provides a generic
     * event and the current value of the slider.
     */
    onChangeEnd?: (event: Event, value: number) => void;
    /**
     * Restrict slider value to marks only. The step will be ignored.
     */
    restrictToMarks?: boolean;
    /**
     * Show visual ticks above the marks.
     */
    showTicks?: boolean;
    /**
     * Show the slider value in a tooltip when the thumb is hovered.
     * @default true
     */
    showTooltip?: boolean;
    /**
     * Minimum interval the slider thumb can move.
     * @default 1
     */
    step?: number;
    /**
     * Maximum interval the slider thumb can move when using PageUp and PageDown keys.
     * @default 2
     */
    stepMultiplier?: number;
    /**
     * Value of the slider, to be used when in a controlled state.
     */
    value?: number;
}
export declare const Slider: import("react").ForwardRefExoticComponent<SliderProps & import("react").RefAttributes<HTMLDivElement>>;

import { type ChangeEvent, type Dispatch, type RefObject, type SetStateAction } from "react";
import type { SliderProps } from "../Slider";
type UseRangeSliderThumbProps = Pick<SliderProps, "min" | "max" | "step"> & {
    decimalPlaces: number;
    handleInputChange: (event: ChangeEvent<HTMLInputElement>, thumbIndex: number) => void;
    inputRefs: RefObject<HTMLInputElement | null>[];
    marks?: {
        label: string;
        value: number;
    }[];
    onChange?: (event: Event, value: [number, number]) => void;
    onChangeEnd?: (event: Event, value: [number, number]) => void;
    restrictToMarks?: boolean;
    setValue: Dispatch<SetStateAction<[number, number]>>;
    stepMultiplier: number;
    value: [number, number];
};
export declare const useRangeSliderThumb: ({ decimalPlaces, handleInputChange, inputRefs, marks, min, max, step, onChange, onChangeEnd, restrictToMarks, setValue, stepMultiplier, value, }: UseRangeSliderThumbProps) => {
    handleBlur: (thumbIndex: number) => void;
    handleFocus: (thumbIndex: number) => void;
    handleKeydownOnThumb: (event: React.KeyboardEvent, thumbIndex: number) => void;
    handlePointerDownOnThumb: (event: React.PointerEvent<HTMLDivElement>, thumbIndex: number) => void;
    handlePointerDownOnTrack: (event: React.PointerEvent<HTMLDivElement>) => void;
    isDragging: boolean;
    isFocusVisible: boolean;
    preventThumbOverlap: (currentValue: number, value: [number, number], thumbIndex: number) => [number, number];
    sliderRef: RefObject<HTMLDivElement>;
    thumbIndexState: number;
};
export {};

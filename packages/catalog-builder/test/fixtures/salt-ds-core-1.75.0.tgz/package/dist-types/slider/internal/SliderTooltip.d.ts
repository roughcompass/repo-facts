interface SliderTooltipProps {
    value: number | string;
    open?: boolean;
}
export declare const SliderTooltip: ({ value, open }: SliderTooltipProps) => import("react").JSX.Element;
export {};

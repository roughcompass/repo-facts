import type { RefObject } from "react";
export declare const toFloat: (value: number | string) => number;
export declare const calculateMarkPosition: (value: number | string, max: number, min: number) => number;
export declare const calculatePercentage: (value: number, max: number, min: number) => number;
export declare const clamp: (value: number, max: number, min: number, step: number, decimalPlaces: number, marks?: {
    value: number;
    label: string;
}[], restrictToMarks?: boolean) => number;
export declare const clampRange: (range: [number, number], max: number, min: number, step: number, decimalPlaces: number, marks?: {
    value: number;
    label: string;
}[], restrictToMarks?: boolean) => [number, number];
export declare const getClickedPosition: (sliderRef: RefObject<HTMLDivElement | null>, clientX: number, max: number, min: number, step: number, decimalPlaces: number, marks?: {
    label: string;
    value: number;
}[], restrictToMarks?: boolean) => number | undefined;
export declare const getKeyboardValue: (event: React.KeyboardEvent, value: number, step: number, stepMultiplier: number, max: number, min: number, restrictToMarks?: boolean, marks?: {
    label: string;
    value: number;
}[]) => number;

import { type ReactNode } from "react";
declare const ViewportContext: import("react").Context<number | null>;
type ViewportProviderProps = {
    children?: ReactNode;
};
declare const ViewportProvider: ({ children }: ViewportProviderProps) => import("react").JSX.Element;
declare const useViewport: () => number;
export { useViewport, ViewportContext, ViewportProvider };

import { type ComponentPropsWithoutRef } from "react";
export interface OnSolidButtonProps extends ComponentPropsWithoutRef<"button"> {
    /**
     * If `true`, the button will be disabled.
     */
    disabled?: boolean;
    /**
     * If `true`, the button will be focusable when disabled.
     */
    focusableWhenDisabled?: boolean;
}
export declare const OnSolidButton: import("react").ForwardRefExoticComponent<OnSolidButtonProps & import("react").RefAttributes<HTMLButtonElement>>;

import { type ElementType, type FunctionComponent } from "react";
import { type PolymorphicComponentPropWithRef, type ResponsiveProp } from "../utils";
export type GridLayoutProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Number of columns to be displayed. Defaults to 12
     */
    columns?: ResponsiveProp<number | string>;
    /**
     * Number of rows to be displayed. Defaults to 1
     */
    rows?: ResponsiveProp<number | string>;
    /**
     * Defines the size of the gutter between the columns and the rows by setting a density multiplier. Defaults to 3
     */
    gap?: ResponsiveProp<number | string>;
    /**
     * Defines the size of the gutter between the columns by setting a density multiplier. Defaults to 1
     */
    columnGap?: ResponsiveProp<number | string>;
    /**
     * Defines the size of the gutter between the rows by setting a density multiplier. Defaults to 1
     */
    rowGap?: ResponsiveProp<number | string>;
    /**
     * Defines the margin around the component. It can be specified as a number (which acts as a multiplier) or a string representing the margin value. Default is `0`.
     */
    margin?: ResponsiveProp<number | string>;
    /**
     * Defines the padding within the component. It can be specified as a number (which acts as a multiplier) or a string representing the padding value. Default is `0`.
     */
    padding?: ResponsiveProp<number | string>;
}>;
type GridLayoutComponent = <T extends ElementType = "div">(props: GridLayoutProps<T>) => ReturnType<FunctionComponent>;
export declare const GridLayout: GridLayoutComponent;
export {};

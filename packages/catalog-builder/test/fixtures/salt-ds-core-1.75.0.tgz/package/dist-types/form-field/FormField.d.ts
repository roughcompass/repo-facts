import { type HTMLAttributes } from "react";
import { type A11yValueProps, type FormFieldValidationStatus } from "../form-field-context";
export type FormFieldLabelPlacement = "top" | "left" | "right";
export interface FormFieldProps extends HTMLAttributes<HTMLDivElement>, A11yValueProps {
    /**
     * If `true`, the field will be disabled.
     */
    disabled?: boolean;
    /**
     * Location of the label relative to the control.
     *
     * Either 'top', 'left', or 'right'`.
     */
    labelPlacement?: FormFieldLabelPlacement;
    /**
     * If `true`, the field will be read-only.
     */
    readOnly?: boolean;
    /**
     * Optional id prop
     *
     * Used as suffix of FormFieldLabel id: `label-{id}`
     * Used as suffix of FormFieldHelperText id: `helperText-{id}`
     */
    id?: string;
    /**
     * Displays necessity on label
     */
    necessity?: "required" | "optional" | "asterisk";
    /**
     * Validation status
     */
    validationStatus?: FormFieldValidationStatus;
}
export declare const FormField: import("react").ForwardRefExoticComponent<FormFieldProps & import("react").RefAttributes<HTMLDivElement>>;

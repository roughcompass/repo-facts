import { type TextProps } from "../text";
export interface FormFieldHelperTextProps extends Omit<TextProps<"label">, "variant" | "styleAs" | "fontWeight"> {
}
export declare const FormFieldHelperText: ({ className, children, ...restProps }: FormFieldHelperTextProps) => import("react").JSX.Element;

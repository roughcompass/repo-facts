import type { IconProps } from "@salt-ds/icons";
export type WarningAdornmentIconProps = IconProps;
export declare const WarningAdornmentIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import type { IconProps } from "@salt-ds/icons";
export type SuccessAdornmentIconProps = IconProps;
export declare const SuccessAdornmentIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import type { IconProps } from "@salt-ds/icons";
import type { FormFieldValidationStatus } from "../form-field-context";
import type { ValidationStatus } from "../status-indicator";
export type AdornmentValidationStatus = Exclude<ValidationStatus, "info">;
export interface StatusAdornmentProps extends IconProps {
    /**
     * Status adornment to be displayed.
     */
    status: FormFieldValidationStatus;
}
export declare const StatusAdornment: import("react").ForwardRefExoticComponent<StatusAdornmentProps & import("react").RefAttributes<SVGSVGElement>>;

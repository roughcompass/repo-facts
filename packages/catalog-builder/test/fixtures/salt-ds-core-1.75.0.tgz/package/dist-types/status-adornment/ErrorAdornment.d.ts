import type { IconProps } from "@salt-ds/icons";
export type ErrorAdornmentIconProps = IconProps;
export declare const ErrorAdornmentIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

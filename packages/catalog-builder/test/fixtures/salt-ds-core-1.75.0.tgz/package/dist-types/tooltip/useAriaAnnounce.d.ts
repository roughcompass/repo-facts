import type { ElementProps, FloatingContext } from "@floating-ui/react";
type Props = {
    delay?: number | Partial<{
        open: number;
        close: number;
    }>;
};
export declare const useAriaAnnounce: (context: FloatingContext, { delay }: Props) => ElementProps;
export {};

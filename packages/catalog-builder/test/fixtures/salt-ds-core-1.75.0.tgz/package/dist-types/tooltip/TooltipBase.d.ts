import { type FloatingArrowProps } from "@floating-ui/react";
import { type ValidationStatus } from "../status-indicator";
import type { TooltipProps } from "./Tooltip";
interface TooltipBaseProps extends Omit<TooltipProps, "children"> {
    arrowProps: FloatingArrowProps;
    /**
     * Optional string to determine the status of the Tooltip.
     */
    status?: ValidationStatus;
}
export declare const TooltipBase: (props: TooltipBaseProps) => import("react").JSX.Element;
export {};

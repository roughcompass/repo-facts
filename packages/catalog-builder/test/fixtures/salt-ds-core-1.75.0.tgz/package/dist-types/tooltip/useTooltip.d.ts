import { type FloatingContext, type Strategy } from "@floating-ui/react";
import { type HTMLProps, type MutableRefObject } from "react";
import { type UseFloatingUIProps, type UseFloatingUIReturn } from "../utils";
export interface UseTooltipProps extends Partial<Pick<UseFloatingUIProps, "onOpenChange" | "open" | "placement">> {
    /**
     * When `true`, the tooltip will be disabled.
     */
    disabled?: boolean;
    /**
     * Do not respond to focus events.
     */
    disableFocusListener?: boolean;
    /**
     * Do not respond to hover events.
     */
    disableHoverListener?: boolean;
    /**
     * The number of milliseconds to wait before showing the tooltip.
     * This prop won't impact the enter touch delay (`enterTouchDelay`).
     */
    enterDelay?: number;
    /**
     * The number of milliseconds to wait before hiding the tooltip.
     * This prop won't impact the leave touch delay (`leaveTouchDelay`).
     */
    leaveDelay?: number;
}
interface UseTooltipReturn {
    arrowProps: {
        ref: MutableRefObject<SVGSVGElement | null>;
        context: FloatingContext;
    };
    open: boolean;
    floating: UseFloatingUIReturn["floating"];
    reference: UseFloatingUIReturn["reference"];
    getTooltipProps: () => HTMLProps<HTMLDivElement>;
    getTriggerProps: () => Record<string, unknown>;
    getTooltipPosition: () => {
        top: number;
        left: number;
        position: Strategy;
        width: number | undefined;
        height: number | undefined;
    };
}
export declare function useTooltip(props?: UseTooltipProps): UseTooltipReturn;
export {};

import { type ElementType, type FunctionComponent } from "react";
import type { ValidationStatus } from "../status-indicator";
import { type PolymorphicComponentPropWithRef } from "../utils";
export type TextProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Applies disabled styling when true
     */
    disabled?: boolean;
    /**
     * Adjust the font weight using the theme's weights for the current text style.
     * This is a visual change only and isn't conveyed to assistive technologies; use `<strong>` or `<em>` to convey importance or stress.
     */
    fontWeight?: "lighter" | "bolder";
    /**
     * Apply text truncation by mentioning number of rows to be displayed
     */
    maxRows?: number;
    /**
     * Match styling to another text component's style.
     * Use `inherit` to inherit the font and color from the parent element.
     * The `lighter` and `bolder` weights then come from the closest `Text`-based ancestor.
     */
    styleAs?: "h1" | "h2" | "h3" | "h4" | "label" | "label2" | "body2" | "eyebrow" | "display1" | "display2" | "display3" | "display4" | "editorial1" | "editorial2" | "editorial3" | "editorial4" | "editorial5" | "editorial6" | "notation" | "action" | "code" | "inherit";
    /**
     * Change text color palette
     * @deprecated since 1.27.1. Use `color` instead.
     */
    variant?: "primary" | "secondary";
    color?: "inherit" | "primary" | "secondary" | ValidationStatus;
}>;
type TextComponent = <T extends ElementType = "div">(props: TextProps<T>) => ReturnType<FunctionComponent>;
export declare const Text: TextComponent;
export {};

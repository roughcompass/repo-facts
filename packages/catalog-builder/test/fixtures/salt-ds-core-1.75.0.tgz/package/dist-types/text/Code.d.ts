import { type TextProps } from "./Text";
export declare const Code: import("react").ForwardRefExoticComponent<Omit<Omit<TextProps<"code">, "as">, "ref"> & import("react").RefAttributes<HTMLSpanElement>>;

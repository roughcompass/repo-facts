import { type TextProps } from "./Text";
export declare const H1: import("react").ForwardRefExoticComponent<Omit<Omit<TextProps<"h1">, "as">, "ref"> & import("react").RefAttributes<HTMLHeadingElement>>;
export declare const H2: import("react").ForwardRefExoticComponent<Omit<Omit<TextProps<"h2">, "as">, "ref"> & import("react").RefAttributes<HTMLHeadingElement>>;
export declare const H3: import("react").ForwardRefExoticComponent<Omit<Omit<TextProps<"h3">, "as">, "ref"> & import("react").RefAttributes<HTMLHeadingElement>>;
export declare const H4: import("react").ForwardRefExoticComponent<Omit<Omit<TextProps<"h4">, "as">, "ref"> & import("react").RefAttributes<HTMLHeadingElement>>;

import { type TextProps } from "./Text";
export declare const Label: import("react").ForwardRefExoticComponent<Omit<Omit<TextProps<"label">, "as">, "ref"> & import("react").RefAttributes<HTMLLabelElement>>;

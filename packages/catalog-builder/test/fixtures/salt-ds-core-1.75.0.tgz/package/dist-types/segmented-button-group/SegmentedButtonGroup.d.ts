import { type ComponentPropsWithoutRef } from "react";
export interface SegmentedButtonGroupProps extends ComponentPropsWithoutRef<"div"> {
}
export declare const SegmentedButtonGroup: import("react").ForwardRefExoticComponent<SegmentedButtonGroupProps & import("react").RefAttributes<HTMLDivElement>>;

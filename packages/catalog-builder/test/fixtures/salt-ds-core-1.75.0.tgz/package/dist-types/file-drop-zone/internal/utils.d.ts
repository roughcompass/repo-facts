import type { DragEvent } from "react";
export declare const containsFiles: (e: DragEvent) => boolean | FileList | null;
export declare const extractFiles: (e: DragEvent) => File[];

import type { IconProps } from "@salt-ds/icons";
import { type ValidationStatus } from "../status-indicator";
export interface FileDropZoneIconProps extends IconProps {
    /**
     * Status indicator to be displayed.
     */
    status?: ValidationStatus;
}
export declare const FileDropZoneIcon: import("react").ForwardRefExoticComponent<FileDropZoneIconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type ChangeEvent, type ComponentPropsWithoutRef } from "react";
import { type ButtonProps } from "../button";
export interface FileDropZoneTriggerProps extends Omit<ComponentPropsWithoutRef<"button">, "onChange"> {
    /**
     * `accept` attribute for HTML <input>.
     *
     * A comma separated list of file types the user can pick from the file input dialog box.
     */
    accept?: string;
    /**
     * Disable all trigger elements.
     */
    disabled?: boolean;
    /**
     * Allows multiple files to be uploaded.
     */
    multiple?: boolean;
    /**
     * The name applied to the hidden input.
     */
    name?: string;
    /**
     * Callback for input change event
     */
    onChange?: (event: ChangeEvent<HTMLInputElement>, files: File[]) => void;
    /**
     * The appearance of the button. Options are 'solid', 'bordered', and 'transparent'.
     * 'solid' is the default value.
     */
    appearance?: ButtonProps["appearance"];
    /**
     * The sentiment of the button. Options are 'accented' and 'neutral'.
     * 'neutral' is the default value.
     *
     */
    sentiment?: Extract<ButtonProps["sentiment"], "accented" | "neutral">;
}
export declare const FileDropZoneTrigger: import("react").ForwardRefExoticComponent<FileDropZoneTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;

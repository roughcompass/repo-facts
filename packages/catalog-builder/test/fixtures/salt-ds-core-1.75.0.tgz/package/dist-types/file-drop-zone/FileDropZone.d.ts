import { type ComponentPropsWithoutRef, type DragEvent } from "react";
import type { ValidationStatus } from "../status-indicator";
export interface FileDropZoneProps extends Omit<ComponentPropsWithoutRef<"div">, "onDrop"> {
    /**
     * If `true`, the file drop zone will be disabled.
     */
    disabled?: boolean;
    /**
     * Status indicator to be displayed.
     */
    status?: Exclude<ValidationStatus, "info" | "warning">;
    /**
     * Callback for on drop event
     */
    onDrop?: (event: DragEvent<HTMLDivElement>, files: File[]) => void;
}
export declare const FileDropZone: import("react").ForwardRefExoticComponent<FileDropZoneProps & import("react").RefAttributes<HTMLDivElement>>;

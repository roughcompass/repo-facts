import { type ReactNode } from "react";
import type { Accent, ActionFont, Corner, Density, HeadingFont, Mode, ThemeName } from "../theme/index";
export interface ThemeApplicatorProps {
    /**
     * Either "root", "scope" or "child".
     * Specifies the location of salt theme class and attributes should be applied to.
     *
     * Defaults to "root" for a root provider, otherwise "scope".
     */
    applyClassesTo: "root" | "scope" | "child";
    /**
     * Either "high", "medium", "low", "touch" or "mobile".
     * Determines the amount of content that can fit on a screen based on the size and spacing of components.
     * Refer to [density](https://www.saltdesignsystem.com/salt/foundations/density) doc for more detail.
     *
     * @default "medium"
     */
    density: Density;
    /**
     * A string. Specifies custom theme name(s) you want to apply, similar to `className`.
     */
    theme: ThemeName;
    /**
     * Either "light" or "dark". Enable the color palette to change from light to dark.
     * Refer to [modes](https://www.saltdesignsystem.com/salt/foundations/modes) doc for more detail.
     *
     * @default "light"
     */
    mode: Mode;
    /**
     * Either "sharp" or "rounded".
     * Determines selected components corner radius.
     * @default "sharp"
     */
    corner?: Corner;
    /**
     * Either "Open Sans" or "Amplitude".
     * Determines font family of display and heading text.
     * @default "Open Sans"
     */
    headingFont?: HeadingFont;
    /**
     * Either "blue" or "teal".
     * Determines accent color used across components, e.g. Accent Button, List, Calendar.
     * @default "blue"
     */
    accent?: Accent;
    /**
     * Either "Open Sans" or "Amplitude".
     * Determines font family of action components, mostly Buttons.
     * @default "Open Sans"
     */
    actionFont?: ActionFont;
    children?: ReactNode;
}
export declare function ThemeApplicator({ applyClassesTo, children, density, mode, theme, corner, headingFont, accent, actionFont, }: ThemeApplicatorProps): string | number | boolean | Iterable<ReactNode> | import("react").JSX.Element | null | undefined;

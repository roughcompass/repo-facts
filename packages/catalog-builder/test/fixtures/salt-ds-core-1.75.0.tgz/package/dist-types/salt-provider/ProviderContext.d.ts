import type { WindowContextType } from "@salt-ds/window";
export interface ProviderContext {
    targetWindow: WindowContextType;
}
export declare const ProviderContext: import("react").Context<ProviderContext | null>;

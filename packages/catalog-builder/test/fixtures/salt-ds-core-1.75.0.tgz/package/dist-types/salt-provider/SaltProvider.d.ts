import { type WindowContextType } from "@salt-ds/window";
import { type ReactElement, type ReactNode } from "react";
import { type Breakpoints } from "../breakpoints";
import type { Accent, ActionFont, Corner, Density, HeadingFont, Mode, ThemeName } from "../theme";
import { type ThemeApplicatorProps } from "./ThemeApplicator";
export declare const DEFAULT_DENSITY = "medium";
export interface ThemeContextProps {
    theme: ThemeName;
    mode: Mode;
    window?: WindowContextType;
    /** Only available when using SaltProviderNext. */
    themeNext: boolean;
    corner: Corner;
    /** @deprecated since 1.32.0. Use `corner`. */
    UNSTABLE_corner: Corner;
    headingFont: HeadingFont;
    /** @deprecated since 1.32.0. Use `headingFont`. */
    UNSTABLE_headingFont: HeadingFont;
    accent: Accent;
    /** @deprecated since 1.32.0. Use `accent`. */
    UNSTABLE_accent: Accent;
    actionFont: ActionFont;
    /** @deprecated since 1.32.0. Use `actionFont`. */
    UNSTABLE_actionFont: ActionFont;
}
export declare const DensityContext: import("react").Context<"high" | "low" | "touch" | "medium" | "mobile">;
export declare const ThemeContext: import("react").Context<ThemeContextProps>;
export declare const BreakpointContext: import("react").Context<Breakpoints>;
type ThemeNextOnlyAttributes = "accent" | "corner" | "actionFont" | "headingFont";
interface SaltProviderBaseProps extends Partial<Omit<ThemeApplicatorProps, "children" | ThemeNextOnlyAttributes>> {
    /**
     * Shape of `{ xs: number; sm: number; md: number; lg: number; xl: number; }`.
     * Determines breakpoints used in responsive calculation for layout components.
     */
    breakpoints?: Breakpoints;
    /**
     * A boolean. Enables dynamic style injection for each component.
     *
     * If `false`, you'll need to include component CSS yourself.
     *
     * @default true
     */
    enableStyleInjection?: boolean;
}
interface SaltProviderThatAppliesClassesToChild extends SaltProviderBaseProps {
    children: ReactElement;
    applyClassesTo: "child";
}
interface SaltProviderThatInjectsThemeElement extends SaltProviderBaseProps {
    children: ReactNode;
}
interface SaltProviderThatClassesToRoot extends SaltProviderThatInjectsThemeElement {
    applyClassesTo: "root";
}
type SaltProviderProps = SaltProviderThatAppliesClassesToChild | SaltProviderThatInjectsThemeElement | SaltProviderThatClassesToRoot;
export declare function SaltProvider({ enableStyleInjection, ...restProps }: SaltProviderProps): import("react").JSX.Element;
export type SaltProviderNextProps = SaltProviderProps & Pick<ThemeApplicatorProps, ThemeNextOnlyAttributes>;
export declare function SaltProviderNext({ enableStyleInjection, ...restProps }: SaltProviderNextProps): import("react").JSX.Element;
/** @deprecated since 1.32.0. Use `SaltProviderNextProps`. */
export type UNSTABLE_SaltProviderNextProps = SaltProviderNextProps;
/** @deprecated since 1.32.0. Use `SaltProviderNext`. */
export declare const UNSTABLE_SaltProviderNext: typeof SaltProviderNext;
export declare const useTheme: () => ThemeContextProps;
/**
 * `useDensity` merges density value from `DensityContext` with the one from component's props.
 */
export declare function useDensity(density?: Density): Density;
export declare const useBreakpoints: () => Breakpoints;
export {};

import { type ComponentPropsWithoutRef } from "react";
export interface KbdProps extends ComponentPropsWithoutRef<"kbd"> {
    /**
     * The variant of the kbd. Defaults to `"primary"`.
     */
    variant?: "primary" | "secondary" | "tertiary";
}
export declare const Kbd: import("react").ForwardRefExoticComponent<KbdProps & import("react").RefAttributes<HTMLDivElement>>;

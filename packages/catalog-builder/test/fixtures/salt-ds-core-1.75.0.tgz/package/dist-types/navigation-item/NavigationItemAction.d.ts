import type { ComponentPropsWithoutRef } from "react";
interface NavigationItemActionProps extends ComponentPropsWithoutRef<any> {
}
export declare function NavigationItemAction(props: NavigationItemActionProps): import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>>;
export {};

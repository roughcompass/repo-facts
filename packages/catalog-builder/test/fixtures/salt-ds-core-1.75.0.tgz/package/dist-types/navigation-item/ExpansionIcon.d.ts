interface ExpansionIconProps {
    /**
     * Whether the navigation item is expanded.
     */
    expanded?: boolean;
    /**
     * The orientation of the navigation item.
     */
    orientation?: "horizontal" | "vertical";
}
export declare const ExpansionIcon: ({ expanded, orientation, }: ExpansionIconProps) => import("react").JSX.Element;
export {};

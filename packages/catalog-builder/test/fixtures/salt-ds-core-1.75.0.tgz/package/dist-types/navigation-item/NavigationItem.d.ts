import { type ComponentPropsWithoutRef, type MouseEventHandler } from "react";
import type { RenderPropsType } from "../utils";
export interface NavigationItemProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Whether the navigation item is active.
     */
    active?: boolean;
    /**
     * Whether the nested group is collapsed and there is an active nested item within it.
     */
    blurActive?: boolean;
    /**
     * Whether the navigation item is expanded.
     */
    expanded?: boolean;
    /**
     * Level of nesting.
     */
    level?: number;
    /**
     * The orientation of the navigation item.
     */
    orientation?: "horizontal" | "vertical";
    /**
     * Whether the navigation item is a parent with nested items.
     */
    parent?: boolean;
    /**
     * Render prop to enable customisation of navigation item element.
     */
    render?: RenderPropsType["render"];
    /**
     * Action to be triggered when the navigation item is expanded.
     */
    onExpand?: MouseEventHandler<HTMLButtonElement>;
    /**
     * Href to be passed to the Link element.
     */
    href?: string;
}
export declare const NavigationItem: import("react").ForwardRefExoticComponent<NavigationItemProps & import("react").RefAttributes<HTMLDivElement>>;

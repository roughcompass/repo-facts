import type { Breakpoints } from "../breakpoints";
type BreakpointProp<T> = {
    [K in keyof Breakpoints]?: T;
};
export type ResponsiveProp<T> = T | BreakpointProp<T>;
export declare const getCurrentBreakpoint: (breakpoints: Breakpoints, width: number) => keyof Breakpoints;
export declare const useCurrentBreakpoint: () => keyof Breakpoints;
export declare const useOrderedBreakpoints: () => string[];
export declare const useResponsiveProp: <T>(value: ResponsiveProp<T>, defaultValue: T) => T;
export declare function resolveResponsiveValue<Value>(value: ResponsiveProp<Value>, matchedBreakpoints: (keyof Breakpoints)[]): Value | undefined;
export {};

import { type Dispatch, type SetStateAction } from "react";
export interface UseControlledProps<T> {
    /**
     * Holds the component value when it's controlled.
     */
    controlled?: T;
    /**
     * The default value when uncontrolled.
     */
    default: T;
    /**
     * The component name displayed in warnings.
     */
    name: string;
    /**
     * The name of the state variable displayed in warnings.
     */
    state?: string;
}
/**
 * Copied from MUI (v5) useControlled hook with one additional returned value
 * @see https://github.com/mui-org/material-ui/blob/0979e6a54ba47c278d1f535953c0520a86349811/packages/material-ui-utils/src/useControlled.js
 */
export declare function useControlled<S>({ controlled, default: defaultProp, name, state, }: UseControlledProps<S>): [S, Dispatch<SetStateAction<S>>, boolean];

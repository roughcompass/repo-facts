export declare function ownerWindow(node: Node | null | undefined): Window & typeof globalThis;

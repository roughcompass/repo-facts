export type ClassNamePrefixer = (...names: string[]) => string;
export declare const makePrefixer: (prefix: string) => ClassNamePrefixer;

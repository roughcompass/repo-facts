import { type Context } from "react";
export declare function createContext<ContextValueType>(name: string, defaultValue: ContextValueType): Context<ContextValueType>;

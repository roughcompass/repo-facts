import { type ReactNode } from "react";
export declare function getRefFromChildren(child: ReactNode): any;

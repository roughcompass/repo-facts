import { type FocusEvent, type MutableRefObject, type Ref } from "react";
export declare function teardown(doc: Document): void;
export declare function useIsFocusVisible<T extends HTMLElement = HTMLElement>(): {
    isFocusVisibleRef: MutableRefObject<boolean>;
    onBlur: () => void;
    onFocus: (event: FocusEvent<T>) => void;
    ref: Ref<T>;
};

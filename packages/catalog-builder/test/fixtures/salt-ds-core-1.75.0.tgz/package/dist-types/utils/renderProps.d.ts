import { type ComponentProps, type ElementType, type ReactElement } from "react";
export interface RenderPropsType {
    render?: ReactElement | ((props: any) => ReactElement);
}
export declare function renderProps<Type extends ElementType>(Type: Type | null, props: RenderPropsType & ComponentProps<Type>): ReactElement;

import { type RefObject } from "react";
export interface UseResizeObserverProps {
    ref: RefObject<HTMLElement | null>;
    onResize: () => void;
}
export declare function useResizeObserver({ ref, onResize }: UseResizeObserverProps): void;

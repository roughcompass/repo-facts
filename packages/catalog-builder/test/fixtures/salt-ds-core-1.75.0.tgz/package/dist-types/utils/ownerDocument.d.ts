export declare function ownerDocument(node: Node | null | undefined): Document;

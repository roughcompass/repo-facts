/**
 * https://github.com/facebook/react/issues/14099#issuecomment-440013892
 */
export declare function useEventCallback<const T extends (...args: any[]) => void>(fn: T): T;

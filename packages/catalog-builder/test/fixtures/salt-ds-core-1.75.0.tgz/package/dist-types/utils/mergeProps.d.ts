interface Props {
    [key: string]: unknown;
}
/**
 * This utility merges two prop objects according to the following rules:
 *
 * - If the prop is a function and begins with "on" then chain the functions together
 * - If the prop key is "className" then merge them using `clsx`
 * - If the prop key is "style" and both values are objects then shallow-merge them
 *   (values from the second parameter win on key conflicts). This preserves CSS
 *   custom properties set internally by the component (e.g. `--saltAvatar-size-multiplier`)
 *   when a consumer passes their own `style` via a render prop.
 * - If the prop is anything else, then use the value from the second parameter unless it's undefined then use the value from the first parameter
 */
export declare function mergeProps(propsA: Props, propsB: Props): Record<string, unknown>;
export {};

export interface Cancelable {
    clear(): void;
}
export declare function debounce<T extends (...args: any[]) => any>(func: T, wait?: number, leading?: boolean): T & Cancelable;

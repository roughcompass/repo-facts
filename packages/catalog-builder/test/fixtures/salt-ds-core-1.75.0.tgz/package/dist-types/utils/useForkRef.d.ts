import { type Ref } from "react";
export declare function useForkRef<Instance>(refA: Ref<Instance> | null | undefined, refB: Ref<Instance> | null | undefined): Ref<Instance> | null;

import { type FloatingFocusManagerProps, type Middleware, type Platform, type Strategy, type UseFloatingOptions, useFloating } from "@floating-ui/react";
import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface FloatingComponentProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Whether the floating component is open (used for determining whether to show the component)
     * We pass this as a prop rather than not rendering the component to allow more advanced use-cases e.g.
     * for caching windows and reusing them, rather than always spawning a new one
     */
    open: boolean;
    /**
     * Use this prop when `FloatingFocusManager` is needed for floating component
     */
    focusManagerProps?: Omit<FloatingFocusManagerProps, "children">;
    /**
     * Position and sizing optional props for the floating component. `top`, `left`, and `position` for floating elements where they aren't positioned with relative to the trigger.
     * `width` and `height` are used to define the size of the floating element.
     *
     */
    top?: number;
    left?: number;
    width?: number;
    height?: number;
    position?: Strategy;
    /**
     * Makes the page unscrollable when the floating component is open.
     */
    lockScroll?: boolean;
}
declare const DefaultFloatingComponent: import("react").ForwardRefExoticComponent<FloatingComponentProps & import("react").RefAttributes<HTMLDivElement>>;
export interface FloatingComponentContextType {
    Component: typeof DefaultFloatingComponent;
}
export interface FloatingComponentProviderProps extends FloatingComponentContextType {
    children: ReactNode;
}
export declare function FloatingComponentProvider(props: FloatingComponentProviderProps): import("react").JSX.Element;
export declare function useFloatingComponent(): FloatingComponentContextType;
export interface UseFloatingUIProps extends Pick<UseFloatingOptions, "placement" | "strategy" | "open" | "onOpenChange" | "nodeId" | "rootContext"> {
    /**
     * Function to update the default middleware used to extend or replace it
     */
    middleware?: Middleware[];
}
type GetMiddleware = (middleware: Middleware[]) => Middleware[];
interface FloatingPlatformContextType {
    platform: Platform;
    middleware: GetMiddleware;
    animationFrame: boolean;
}
export interface FloatingPlatformProviderProps {
    platform?: Platform;
    middleware?: GetMiddleware;
    children: ReactNode;
    animationFrame?: boolean;
}
export declare function FloatingPlatformProvider(props: FloatingPlatformProviderProps): import("react").JSX.Element;
export declare function useFloatingPlatform(): FloatingPlatformContextType;
export declare const DEFAULT_FLOATING_UI_MIDDLEWARE: Middleware[];
type UseFloatingRefs = ReturnType<typeof useFloating>["refs"];
export interface UseFloatingUIReturn extends ReturnType<typeof useFloating> {
    reference: UseFloatingRefs["setReference"];
    floating: UseFloatingRefs["setFloating"];
}
export declare function useFloatingUI(props: UseFloatingUIProps): UseFloatingUIReturn;
export {};

import type { Middleware } from "@floating-ui/react";
export declare const margin: (value?: number) => Middleware;

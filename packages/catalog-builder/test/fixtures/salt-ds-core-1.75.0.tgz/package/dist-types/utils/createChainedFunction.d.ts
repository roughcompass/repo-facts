type ChainedFunction<Args extends any[], This> = ((this: This, ...args: Args) => any) | undefined | null;
export declare function createChainedFunction<Args extends any[], This>(...funcs: ChainedFunction<Args, This>[]): (this: This, ...args: Args) => any;
export {};

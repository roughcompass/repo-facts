import type { Ref, RefCallback } from "react";
/**
 * Merges two refs into a callback ref. Components and hooks should use
 * `useForkRef`, so the merged ref only changes when one of the refs changes.
 * This is for places that can't call a hook, such as a props getter.
 *
 * The returned ref never returns a cleanup itself, so every React version
 * detaches it by calling it with `null`; that is when the cleanups collected
 * from refA and refB are run.
 */
export declare function forkRef<Instance>(refA: Ref<Instance> | null | undefined, refB: Ref<Instance> | null | undefined): RefCallback<Instance>;

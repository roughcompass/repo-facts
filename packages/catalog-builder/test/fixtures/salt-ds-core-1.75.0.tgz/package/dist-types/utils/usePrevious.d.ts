import { type DependencyList } from "react";
export declare function usePrevious<T>(value: T, deps?: DependencyList, initialValue?: T): T | undefined;

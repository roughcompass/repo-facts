import { type ComponentPropsWithoutRef, type SyntheticEvent } from "react";
export interface CollapsibleProps extends Omit<ComponentPropsWithoutRef<"div">, "onToggle"> {
    /**
     * Whether the accordion is open.
     */
    open?: boolean;
    /**
     * Whether the accordion is open by default.
     */
    defaultOpen?: boolean;
    /**
     * Callback fired when the accordion is opened or closed.
     */
    onOpenChange?: (event: SyntheticEvent<HTMLButtonElement>, open: boolean) => void;
}
export declare const Collapsible: import("react").ForwardRefExoticComponent<CollapsibleProps & import("react").RefAttributes<HTMLDivElement>>;

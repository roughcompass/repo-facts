import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface CollapsibleTriggerProps extends Pick<ComponentPropsWithoutRef<"button">, "className" | "onClick"> {
    children: ReactNode;
}
export declare const CollapsibleTrigger: import("react").ForwardRefExoticComponent<CollapsibleTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;

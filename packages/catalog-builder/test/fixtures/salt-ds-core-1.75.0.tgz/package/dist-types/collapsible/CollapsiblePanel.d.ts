import { type ComponentPropsWithoutRef, type ReactElement } from "react";
export interface CollapsiblePanelProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Element used to customize the panel's root, e.g. `<CardContent />`.
     * Props are merged onto this element, and its own props take precedence.
     * Don't set `children`, `hidden` or `aria-hidden` on it, as they replace the
     * panel's content and open state.
     */
    render?: ReactElement;
}
export declare const CollapsiblePanel: import("react").ForwardRefExoticComponent<CollapsiblePanelProps & import("react").RefAttributes<HTMLDivElement>>;

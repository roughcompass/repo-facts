import { type SyntheticEvent } from "react";
export type CollapsibleContextValue = {
    open: boolean;
    setOpen: (event: SyntheticEvent<HTMLButtonElement>, open: boolean) => void;
    panelId?: string;
    setPanelId?: (panelId: string) => void;
};
export declare const CollapsibleContext: import("react").Context<CollapsibleContextValue>;
export declare function useCollapsibleContext(): CollapsibleContextValue;

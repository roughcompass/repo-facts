import { type ChangeEventHandler, type ComponentPropsWithoutRef, type FocusEventHandler, type InputHTMLAttributes, type ReactNode, type Ref } from "react";
import type { AdornmentValidationStatus } from "../status-adornment";
import type { DataAttributes } from "../types";
export interface RadioButtonProps extends Omit<ComponentPropsWithoutRef<"label">, "onChange" | "onBlur" | "onFocus"> {
    /**
     * Set the default selected radio button in the group
     */
    checked?: boolean;
    /**
     * Set the disabled state
     */
    disabled?: boolean;
    /**
     * **Deprecated**: Use validationStatus instead
     * Set the error state
     */
    error?: boolean;
    /**
     * Props to be passed to the radio input
     */
    inputProps?: Partial<InputHTMLAttributes<HTMLInputElement>> & DataAttributes;
    /**
     * Used to access the hidden `<input>` element.
     */
    inputRef?: Ref<HTMLInputElement>;
    /**
     * The label to be shown next to the radio icon
     */
    label?: ReactNode;
    /**
     * Name of the radio group
     */
    name?: string;
    /**
     * Callback for blur event
     */
    onBlur?: FocusEventHandler<HTMLInputElement>;
    /**
     * Callback for change event
     */
    onChange?: ChangeEventHandler<HTMLInputElement>;
    /**
     * Callback for focus event
     */
    onFocus?: FocusEventHandler<HTMLInputElement>;
    /**
     * Set the read only state.
     * **Note**: Setting a standalone radio button as read-only is not accessible. The whole radio buttton group should be set as read-only instead.
     */
    readOnly?: boolean;
    /**
     * Value of radio button
     */
    value?: string;
    /**
     * Validation status, one of "warning" | "error" | "success"
     *
     * RadioButton has styling variants for "error" and "warning".
     * No visual styling will be applied on "success" variant.
     */
    validationStatus?: AdornmentValidationStatus;
}
export declare const RadioButton: import("react").ForwardRefExoticComponent<RadioButtonProps & import("react").RefAttributes<HTMLLabelElement>>;

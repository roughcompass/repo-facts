import type { ComponentPropsWithoutRef } from "react";
import type { AdornmentValidationStatus } from "../status-adornment";
export interface RadioButtonIconProps extends ComponentPropsWithoutRef<"div"> {
    checked?: boolean;
    disabled?: boolean;
    /**
     * @deprecated since 1.8.0-rc.2. Use `validationStatus` instead.
     */
    error?: boolean;
    readOnly?: boolean;
    validationStatus?: AdornmentValidationStatus;
}
/**
 * Default radio icon
 */
export declare const RadioButtonIcon: ({ checked, className, error, disabled, validationStatus, readOnly, ...rest }: RadioButtonIconProps) => import("react").JSX.Element;

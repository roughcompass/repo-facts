import { type ChangeEventHandler, type ComponentPropsWithoutRef } from "react";
export interface RadioButtonGroupProps extends Omit<ComponentPropsWithoutRef<"fieldset">, "onChange"> {
    /**
     * Set the selected value when initialized.
     */
    defaultValue?: string;
    /**
     * Set the group direction.
     */
    direction?: "horizontal" | "vertical";
    /**
     * Disable the RadioButton group
     */
    disabled?: boolean;
    /**
     * Only for horizontal direction. When `true` the text in radio button label will wrap to fit within the container. Otherwise the radio buttons will wrap onto the next line.
     */
    wrap?: boolean;
    /**
     * The name to be set on each radio button within the group. If not set, then one will be generated for you.
     */
    name?: string;
    /**
     * Callback for change event.
     */
    onChange?: ChangeEventHandler<HTMLInputElement>;
    /**
     * Set the RadioButton group to read only.
     */
    readOnly?: boolean;
    /**
     * The value of the radio group, required for a controlled component.
     */
    value?: string;
    /**
     * Validation status.
     */
    validationStatus?: "error" | "warning";
}
export declare const RadioButtonGroup: import("react").ForwardRefExoticComponent<RadioButtonGroupProps & import("react").RefAttributes<HTMLFieldSetElement>>;

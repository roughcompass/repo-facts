import type { ChangeEventHandler } from "react";
import type { AdornmentValidationStatus } from "../../status-adornment";
export interface RadioGroupContextValue {
    disabled?: boolean;
    name?: string;
    value?: string;
    onChange?: ChangeEventHandler<HTMLElement>;
    readOnly?: boolean;
    validationStatus?: AdornmentValidationStatus;
}
export declare const RadioGroupContext: import("react").Context<RadioGroupContextValue | undefined>;

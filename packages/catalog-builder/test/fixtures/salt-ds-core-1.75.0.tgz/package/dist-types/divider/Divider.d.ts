import { type ComponentPropsWithoutRef } from "react";
export interface DividerProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The orientation of the divider. Defaults to `"horizontal"`.
     */
    orientation?: "horizontal" | "vertical";
    /**
     * The variant of the divider. Defaults to `"primary"`.
     */
    variant?: "primary" | "secondary" | "tertiary";
}
export declare const Divider: import("react").ForwardRefExoticComponent<DividerProps & import("react").RefAttributes<HTMLDivElement>>;

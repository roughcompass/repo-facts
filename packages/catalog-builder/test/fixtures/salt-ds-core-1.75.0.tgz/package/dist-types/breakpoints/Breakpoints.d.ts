export interface Breakpoints {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
}
export declare const DEFAULT_BREAKPOINTS: Breakpoints;

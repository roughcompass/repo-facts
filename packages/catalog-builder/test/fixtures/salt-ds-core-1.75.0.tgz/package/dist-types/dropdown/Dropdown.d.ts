import { type ComponentPropsWithoutRef, type ReactElement, type ReactNode, type Ref } from "react";
import { type FormFieldValidationStatus } from "../form-field-context";
import { type ListControlProps } from "../list-control/ListControlState";
import type { DataAttributes } from "../types";
export interface DropdownProps<Item = string> extends Omit<ComponentPropsWithoutRef<"button">, "value" | "defaultValue">, ListControlProps<Item> {
    /**
     * If `true`, the dropdown will be disabled.
     */
    disabled?: boolean;
    /**
     * If `true`, the dropdown will be read-only.
     */
    readOnly?: boolean;
    /**
     * The options to display in the dropdown.
     */
    children?: ReactNode;
    /**
     * The marker to use in an empty read only dropdown.
     * Use `''` to disable this feature. Defaults to '—'.
     */
    emptyReadOnlyMarker?: string;
    /**
     * If `true`, the dropdown will be multiselect.
     */
    multiselect?: boolean;
    /**
     * The text shown when the dropdown has no value.
     */
    placeholder?: string;
    /**
     * If `true`, the dropdown will be required.
     */
    required?: boolean;
    /**
     * Start adornment component
     */
    startAdornment?: ReactNode;
    /**
     * Styling variant. Defaults to "primary".
     */
    variant?: "primary" | "secondary" | "tertiary";
    /**
     * The content of the dropdown shown in the button. The component will be controlled if this prop is provided.
     */
    value?: string;
    /**
     * Validation status, one of "error" | "warning" | "success".
     */
    validationStatus?: FormFieldValidationStatus;
    /** Styling variant with a full border. Defaults to false
     */
    bordered?: boolean;
    /**
     *  Props to pass to Dropdown's overlay.
     */
    OverlayProps?: Omit<ComponentPropsWithoutRef<"div">, "children" | "id"> & DataAttributes;
}
export declare const Dropdown: <Item = string>(props: DropdownProps<Item> & {
    ref?: Ref<HTMLButtonElement>;
}) => ReactElement;

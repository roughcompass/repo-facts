import type { IconProps } from "@salt-ds/icons";
import { type ComponentPropsWithoutRef, type ReactElement } from "react";
import { type ValidationStatus } from "../status-indicator";
export interface ToastProps extends ComponentPropsWithoutRef<"div"> {
    /**
     *  A string to determine the current state of the Toast.
     */
    status?: ValidationStatus;
    /**
     * (Optional) if provided, this icon component will be used instead of the status icon
     */
    icon?: ReactElement<IconProps>;
}
export declare const Toast: import("react").ForwardRefExoticComponent<ToastProps & import("react").RefAttributes<HTMLDivElement>>;

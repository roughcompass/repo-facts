import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface ToastContentProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of Toast Content
     */
    children?: ReactNode;
}
export declare const ToastContent: import("react").ForwardRefExoticComponent<ToastContentProps & import("react").RefAttributes<HTMLDivElement>>;

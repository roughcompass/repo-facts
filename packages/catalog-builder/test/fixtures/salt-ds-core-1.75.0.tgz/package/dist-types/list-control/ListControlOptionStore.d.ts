import type { OptionValue } from "./ListControlContext";
export declare const OPTION_STATE_ACTIVE = 1;
export declare const OPTION_STATE_SELECTED = 2;
export declare const OPTION_STATE_FOCUS_VISIBLE = 4;
export type OptionStateSnapshot = number;
export declare function hasOptionState(snapshot: OptionStateSnapshot, state: OptionStateSnapshot): boolean;
/** Internal per-list store used to target updates at affected Options. */
export declare class ListControlOptionStore<Item> {
    #private;
    constructor(selected?: readonly Item[]);
    subscribe(id: string, listener: () => void): () => void;
    register(option: OptionValue<Item>): () => void;
    getSnapshot(id: string, currentOption?: OptionValue<Item>): OptionStateSnapshot;
    setActiveId(id: string | undefined): void;
    setFocusVisible(focusVisible: boolean): void;
    setSelected(selected: readonly Item[]): void;
}

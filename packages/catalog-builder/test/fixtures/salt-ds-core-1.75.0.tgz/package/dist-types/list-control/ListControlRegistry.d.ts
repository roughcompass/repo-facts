import type { OptionValue } from "./ListControlContext";
export interface RegisteredOption<Item> {
    data: OptionValue<Item>;
    element: HTMLElement;
}
export declare function createCoalescedRebuild(rebuild: () => void, enqueue?: (callback: () => void) => void): {
    schedule: () => void;
    cancel: () => void;
};
/** Internal option registry optimized for large, non-virtualized lists. */
export declare class ListControlRegistry<Item> {
    #private;
    register(option: OptionValue<Item>, element: HTMLElement): () => void;
    rebuild(listElement: Pick<HTMLElement, "querySelectorAll">): void;
    getAt(index: number): RegisteredOption<Item> | undefined;
    get length(): number;
    indexOfId(id: string): number;
    indexOfValue(value: Item): number;
    findByData(option: OptionValue<Item>): RegisteredOption<Item> | undefined;
    matching(predicate: (option: OptionValue<Item>) => boolean): RegisteredOption<Item>[];
    snapshot(): readonly RegisteredOption<Item>[];
}

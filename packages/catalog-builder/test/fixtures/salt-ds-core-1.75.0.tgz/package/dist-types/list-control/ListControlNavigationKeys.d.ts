import type { OptionValue } from "./ListControlContext";
export declare function isListControlNavigationKey(key: string): boolean;
/**
 * Navigation keys pressed with Ctrl or Meta (e.g. Ctrl+End, Cmd+ArrowDown,
 * Ctrl+PageDown) are browser or OS shortcuts, so list controls leave them to
 * the browser. Alt is only used with ArrowUp and ArrowDown, as in the ARIA
 * combobox pattern.
 */
export declare function isModifiedListControlNavigationKey(event: {
    key: string;
    altKey: boolean;
    ctrlKey: boolean;
    metaKey: boolean;
}): boolean;
export interface OptionAndElement<Item> {
    data: OptionValue<Item>;
    element: HTMLElement;
}
export interface ListControlNavigationGetters<Item> {
    getFirstOption: () => OptionAndElement<Item> | undefined;
    getLastOption: () => OptionAndElement<Item> | undefined;
    getOptionAfter: (option: OptionValue<Item>) => OptionAndElement<Item> | undefined;
    getOptionBefore: (option: OptionValue<Item>) => OptionAndElement<Item> | undefined;
    getOptionPageAbove: (option: OptionValue<Item>) => OptionAndElement<Item> | undefined;
    getOptionPageBelow: (option: OptionValue<Item>) => OptionAndElement<Item> | undefined;
}
/** Shared by Dropdown and ListBox, which always have an active option. */
export declare function getListControlNavigationTarget<Item>(key: string, activeOption: OptionValue<Item>, getters: ListControlNavigationGetters<Item>): OptionAndElement<Item> | undefined;
/** For ComboBox, where the active option may be undefined. */
export declare function getComboBoxNavigationTarget<Item>(key: string, activeOption: OptionValue<Item> | undefined, getters: ListControlNavigationGetters<Item>): OptionAndElement<Item> | undefined;

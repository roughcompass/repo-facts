import { type SyntheticEvent } from "react";
import type { OptionValue } from "./ListControlContext";
import { ListControlOptionStore } from "./ListControlOptionStore";
import { type RegisteredOption } from "./ListControlRegistry";
export type OpenChangeReason = "input" | "manual";
export type ListControlProps<Item> = {
    /**
     * If true, the control will be disabled.
     */
    disabled?: boolean;
    /**
     * If true, the control will be read-only.
     */
    readOnly?: boolean;
    /**
     * If true, the list will be open by default.
     */
    defaultOpen?: boolean;
    /**
     * If true, the list will be open. Useful for controlling the component.
     */
    open?: boolean;
    /**
     * Callback fired when the open state changes.
     */
    onOpenChange?: (newOpen: boolean, reason?: OpenChangeReason) => void;
    /**
     * The default selected options. If this is provided `defaultValue` should be provided as well.
     */
    defaultSelected?: Item[];
    /**
     * The selected options. The component will be controlled if this prop is provided.
     */
    selected?: Item[];
    /**
     * Callback fired when the selected options change.
     */
    onSelectionChange?: (event: SyntheticEvent, newSelected: Item[]) => void;
    /**
     * If true, multiple options can be selected.
     */
    multiselect?: boolean;
    /**
     * Callback used to convert an option's `value` to a string. This is needed when the value is different to the display value or the value is not a string.
     */
    valueToString?: (item: Item) => string;
};
export declare function defaultValueToString<Item>(item: Item): string;
export declare function findOptionFromSearch<Item>(options: readonly Pick<RegisteredOption<Item>, "data">[], search: string, valueToString: (item: Item) => string, startFrom?: OptionValue<Item>): OptionValue<Item> | undefined;
export declare function useListControl<Item>(props: ListControlProps<Item>): {
    multiselect: boolean;
    openState: boolean;
    setOpen: (newOpen: boolean, reason?: OpenChangeReason, key?: string) => void;
    openKey: import("react").MutableRefObject<string | undefined>;
    activeState: OptionValue<Item> | undefined;
    setActive: import("react").Dispatch<import("react").SetStateAction<OptionValue<Item> | undefined>>;
    selectedState: Item[];
    setSelectedState: import("react").Dispatch<import("react").SetStateAction<Item[]>>;
    select: (event: SyntheticEvent, option: OptionValue<Item>) => void;
    clear: (event: SyntheticEvent) => void;
    focusVisibleState: boolean;
    setFocusVisibleState: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    focusedState: boolean;
    setFocusedState: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    setListRef: import("react").Ref<HTMLDivElement>;
    listRef: import("react").RefObject<HTMLDivElement>;
    register: (optionValue: OptionValue<Item>, element: HTMLElement) => () => void;
    getOptionAtIndex: (index: number) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getIndexOfOption: (option: OptionValue<Item>) => number;
    getOptionsMatching: (predicate: (option: OptionValue<Item>) => boolean) => RegisteredOption<Item>[];
    getOptionFromSearch: (search: string, startFrom?: OptionValue<Item>) => OptionValue<Item> | undefined;
    getOptionAfter: (option: OptionValue<Item>) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getOptionBefore: (option: OptionValue<Item>) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getOptionPageAbove: (start: OptionValue<Item>) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getOptionPageBelow: (start: OptionValue<Item>) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getFirstOption: () => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getLastOption: () => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    valueToString: (item: Item) => string;
    disabled: boolean | undefined;
    optionStateStore: ListControlOptionStore<Item>;
};

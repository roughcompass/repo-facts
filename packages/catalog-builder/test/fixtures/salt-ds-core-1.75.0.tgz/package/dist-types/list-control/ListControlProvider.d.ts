import { type ReactNode } from "react";
import { type ListControlContextValue } from "./ListControlContext";
import type { ListControlOptionStore } from "./ListControlOptionStore";
type ListControlProviderValue<Item> = ListControlContextValue<Item> & {
    optionStateStore: ListControlOptionStore<Item>;
};
export declare function ListControlProvider<Item>({ children, value, }: {
    children: ReactNode;
    value: ListControlProviderValue<Item>;
}): import("react").JSX.Element;
export {};

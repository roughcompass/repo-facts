import { type ReactNode, type RefObject, type SyntheticEvent } from "react";
import type { OptionValue } from "./ListControlContext";
import { ListControlOptionStore } from "./ListControlOptionStore";
export interface ListControlOptionContextValue<Item> {
    disabled?: boolean;
    listRef?: RefObject<HTMLDivElement | null>;
    multiselect: boolean;
    optionStateStore: ListControlOptionStore<Item>;
    register: (optionValue: OptionValue<Item>, element: HTMLElement) => () => void;
    select: (event: SyntheticEvent, option: OptionValue<Item>) => void;
    setActive: (option: OptionValue<Item>) => void;
    valueToString: (item: Item) => string;
}
export declare function ListControlOptionContextProvider<Item>({ children, value, }: {
    children: ReactNode;
    value: ListControlOptionContextValue<Item>;
}): import("react").JSX.Element;
export declare function useListControlOptionContext<Item>(): ListControlOptionContextValue<Item>;

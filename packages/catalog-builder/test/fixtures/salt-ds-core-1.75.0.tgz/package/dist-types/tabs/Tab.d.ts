import { type ComponentPropsWithoutRef } from "react";
export interface TabProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * If `true`, the tab will be disabled.
     */
    disabled?: boolean;
    /**
     * The value of the tab. This must be unique within a `Tabs` instance.
     */
    value: string;
}
export declare const Tab: import("react").ForwardRefExoticComponent<TabProps & import("react").RefAttributes<HTMLDivElement>>;

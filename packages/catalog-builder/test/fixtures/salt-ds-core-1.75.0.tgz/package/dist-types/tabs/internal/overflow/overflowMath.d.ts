export declare const MIN_TRUSTED_TAB_WIDTH = 0.5;
export interface MeasuredOverflowTab {
    value: string;
    width: number | null;
}
interface CalculateVisibleCountProps {
    gap: number;
    maxWidth: number;
    overflowWidth: number;
    pinnedValue?: string;
    tabs: MeasuredOverflowTab[];
}
export declare function calculateVisibleCount({ gap, maxWidth: initialMaxWidth, overflowWidth, pinnedValue, tabs, }: CalculateVisibleCountProps): number | null;
export declare function partitionVisibleValues(orderedValues: string[], visibleCount: number, pinnedValue?: string): {
    visibleValues: string[];
    hiddenValues: string[];
};
export {};

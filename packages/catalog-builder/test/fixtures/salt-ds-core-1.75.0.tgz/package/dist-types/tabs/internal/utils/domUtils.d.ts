export declare function isHTMLElement(node: unknown): node is HTMLElement;

import type { TabListLayoutContextValue } from "../contexts/TabListLayoutContext";
interface UseOverflowLayoutStateArgs {
    hiddenValues: string[];
    menuOpen: boolean;
    overflowMenuOpen: boolean;
    visibleValues: string[];
}
interface UseOverflowLayoutStateResult {
    resolvedOverflowActiveValue: string | null;
    tabListLayoutContext: TabListLayoutContextValue;
}
export declare function useOverflowLayoutState({ hiddenValues, menuOpen, overflowMenuOpen, visibleValues, }: UseOverflowLayoutStateArgs): UseOverflowLayoutStateResult;
export {};

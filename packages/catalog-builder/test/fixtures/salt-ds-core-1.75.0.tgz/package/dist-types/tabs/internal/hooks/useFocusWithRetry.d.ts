interface UseFocusWithRetryArgs {
    maxAttempts?: number;
    targetWindow: Window | null | undefined;
}
export declare function useFocusWithRetry({ maxAttempts, targetWindow, }: UseFocusWithRetryArgs): {
    cancelScheduledFocus: () => void;
    focusElementWithRetry: (getElement: () => HTMLElement | null | undefined) => void;
};
export {};

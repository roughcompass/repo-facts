import { type ComponentPropsWithoutRef, type ReactNode, type SyntheticEvent } from "react";
export interface TabsProps extends Omit<ComponentPropsWithoutRef<"div">, "onChange"> {
    children?: ReactNode;
    /**
     * The default value. Use when the component is not controlled.
     */
    defaultValue?: string;
    /**
     * The value. Use when the component is controlled.
     */
    value?: string;
    /**
     * Callback fired when the selection changes.
     * The event will be null when selection is moved automatically, such as when
     * the currently selected tab is removed and the next available tab is
     * selected.
     */
    onChange?: (event: SyntheticEvent | null, value: string) => void;
}
export declare const Tabs: import("react").ForwardRefExoticComponent<TabsProps & import("react").RefAttributes<HTMLDivElement>>;

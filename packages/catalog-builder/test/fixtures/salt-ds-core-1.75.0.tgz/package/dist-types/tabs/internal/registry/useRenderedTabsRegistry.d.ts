import type { RenderedTab, TabsRenderMode } from "../contexts/TabsContext";
export declare function useRenderedTabsRegistry(): {
    renderMode: TabsRenderMode;
    registerBootstrapTab: (tabValue: string) => () => void;
    setBootstrapTabReady: (tabValue: string, ready: boolean) => void;
    setBootstrapOverflowReady: (ready: boolean) => void;
    registerRenderedTab: (tab: RenderedTab) => () => void;
    updateRenderedTab: (value: string, updates: Partial<Omit<RenderedTab, "value">>) => void;
    getRenderedTab: (value: string) => RenderedTab | undefined;
    getRenderedTabOrder: (value: string) => number;
    renderedTabs: RenderedTab[];
};

import { type MutableRefObject, type RefObject } from "react";
import type { Item, TabsContextValue } from "../contexts/TabsContext";
interface RemovedItem {
    id: string;
    value: string;
    staleIndex?: number;
}
interface UseTabRemovalHandlerArgs {
    activeTab: MutableRefObject<Pick<Item, "id" | "value"> | undefined>;
    focusElementWithRetry: (getElement: () => HTMLElement | null | undefined) => void;
    getFirst: TabsContextValue["getFirst"];
    getIndex: TabsContextValue["getIndex"];
    getLast: TabsContextValue["getLast"];
    getRemovedItems: () => Map<string, RemovedItem>;
    getRenderedTab: TabsContextValue["getRenderedTab"];
    getSelectedTabElement: () => HTMLElement | null | undefined;
    item: TabsContextValue["item"];
    itemAt: TabsContextValue["itemAt"];
    maxRetryAttempts: number;
    menuOpen: boolean;
    overflowButtonRef: RefObject<HTMLButtonElement | null>;
    overflowListRef: RefObject<HTMLDivElement | null>;
    pendingRemovalRecoveryRef: MutableRefObject<boolean>;
    pendingRemovalRecoveryRetriesRef: MutableRefObject<number>;
    removalRecoveryRafRef: MutableRefObject<number | null>;
    selected?: string;
    setSelected: TabsContextValue["setSelected"];
    tabstripRef: RefObject<HTMLDivElement | null>;
    targetWindow: Window | null | undefined;
}
export declare function useTabRemovalHandler({ activeTab, focusElementWithRetry, getFirst, getIndex, getLast, getRemovedItems, getRenderedTab, getSelectedTabElement, item, itemAt, maxRetryAttempts, menuOpen, overflowButtonRef, overflowListRef, pendingRemovalRecoveryRef, pendingRemovalRecoveryRetriesRef, removalRecoveryRafRef, selected, setSelected, tabstripRef, targetWindow, }: UseTabRemovalHandlerArgs): () => void;
export {};

export type TabSlotLocation = "hidden" | "main" | "overflow";
export interface TabListLayoutContextValue {
    getLocation: (value: string) => TabSlotLocation;
    overflowActiveValue: string | null;
    setOverflowActiveValue: (value: string | null) => void;
    moveOverflowFocus: (key: "ArrowDown" | "ArrowUp" | "Home" | "End", value: string) => boolean;
}
export declare const TabListLayoutContext: import("react").Context<TabListLayoutContextValue | null>;
export declare function useTabListLayout(): TabListLayoutContextValue | null;

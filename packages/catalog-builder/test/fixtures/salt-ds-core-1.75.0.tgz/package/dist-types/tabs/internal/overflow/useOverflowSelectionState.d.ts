import { type Dispatch, type MutableRefObject, type SetStateAction, type SyntheticEvent } from "react";
interface UseOverflowSelectionStateArgs {
    commitSelection: (event: SyntheticEvent | null, value: string) => void;
    menuOpen: boolean;
    selected?: string;
    setMenuOpen: Dispatch<SetStateAction<boolean>>;
}
interface UseOverflowSelectionStateResult {
    selectionFromOverflowValueRef: MutableRefObject<string | null>;
    setSelected: (event: SyntheticEvent | null, value: string, source?: "main" | "overflow") => void;
}
export declare function useOverflowSelectionState({ commitSelection, menuOpen, selected, setMenuOpen, }: UseOverflowSelectionStateArgs): UseOverflowSelectionStateResult;
export {};

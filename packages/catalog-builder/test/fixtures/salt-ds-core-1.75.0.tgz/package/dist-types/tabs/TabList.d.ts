import { type ComponentPropsWithoutRef } from "react";
export interface TabListProps extends Omit<ComponentPropsWithoutRef<"div">, "onChange"> {
    /**
     * Styling active color variant. Defaults to "primary".
     */
    activeColor?: "primary" | "secondary" | "tertiary";
    /**
     * The appearance of the tabs. Defaults to "bordered".
     */
    appearance?: "bordered" | "transparent";
}
export declare const TabList: import("react").ForwardRefExoticComponent<TabListProps & import("react").RefAttributes<HTMLDivElement>>;

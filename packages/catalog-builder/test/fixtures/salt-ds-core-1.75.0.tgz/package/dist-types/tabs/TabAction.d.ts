import { type ButtonProps } from "../button";
export interface TabActionProps extends ButtonProps {
}
export declare const TabAction: import("react").ForwardRefExoticComponent<TabActionProps & import("react").RefAttributes<HTMLButtonElement>>;

import { type ComponentPropsWithRef } from "react";
export interface TabBarProps extends ComponentPropsWithRef<"div"> {
    /**
     * Styling variant with a bottom separator. Defaults to false
     */
    divider?: boolean;
    /**
     * Styling variant with left and right padding. Defaults to false
     */
    inset?: boolean;
}
export declare const TabBar: import("react").ForwardRefExoticComponent<Omit<TabBarProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;

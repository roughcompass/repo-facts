interface TabContextValue {
    tabId?: string;
    focused: boolean;
    selected: boolean;
    value: string;
    disabled: boolean;
    actions: string[];
    registerAction: (id: string) => () => void;
}
export declare const TabContext: import("react").Context<TabContextValue>;
export declare function useTab(): TabContextValue;
export {};

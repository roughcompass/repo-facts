import { type ComponentPropsWithoutRef } from "react";
export interface TabTriggerProps extends Omit<ComponentPropsWithoutRef<"button">, "id"> {
}
export declare const TabTrigger: import("react").ForwardRefExoticComponent<TabTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;

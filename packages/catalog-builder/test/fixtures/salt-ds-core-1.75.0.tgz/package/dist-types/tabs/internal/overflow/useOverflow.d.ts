import { type RefObject } from "react";
import type { RenderedTab } from "../contexts/TabsContext";
interface UseOverflowProps {
    container: RefObject<HTMLElement | null>;
    selected?: string;
    tabs: RenderedTab[];
    overflowButton: RefObject<HTMLButtonElement | null>;
    menuOpen: boolean;
}
export declare function useOverflow({ container, overflowButton, tabs, selected, menuOpen, }: UseOverflowProps): readonly [string[], string[], boolean];
export {};

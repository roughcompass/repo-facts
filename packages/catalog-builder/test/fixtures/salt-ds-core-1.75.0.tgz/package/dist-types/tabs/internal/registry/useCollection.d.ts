export interface Item {
    id: string;
    element?: HTMLElement | null;
    value: string;
    location?: "hidden" | "main" | "overflow";
    order?: number;
    stale?: boolean;
}
interface StaleItem extends Item {
    staleIndex?: number;
}
interface UseCollectionProps {
    targetWindow: Window | null | undefined;
    wrap: boolean;
}
export declare function useCollection({ wrap, targetWindow }: UseCollectionProps): {
    registerItem: (item: Item) => () => void;
    item: (id?: string | null) => Item | null;
    getNext: (current: string) => Item | null;
    getPrevious: (current: string) => Item | null;
    getFirst: () => Item | null;
    getLast: () => Item | null;
    getIndex: (current: string) => number;
    itemAt: (index: number) => Item | null;
    updateItem: (id: string, updates: Partial<Omit<Item, "id" | "value">>) => void;
    getRemovedItems: () => Map<string, StaleItem>;
    removalVersion: number;
    sortItems: () => void;
};
export {};

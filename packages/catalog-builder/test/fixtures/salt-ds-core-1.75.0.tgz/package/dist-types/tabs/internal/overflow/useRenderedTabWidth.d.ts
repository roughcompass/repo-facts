import { type RefObject } from "react";
import type { TabsContextValue, TabsRenderMode } from "../contexts/TabsContext";
interface UseRenderedTabWidthProps {
    hostElement: HTMLDivElement | null;
    renderMode: TabsRenderMode;
    tabRootRef: RefObject<HTMLDivElement | null>;
    targetWindow: Window | null | undefined;
    updateRenderedTab: TabsContextValue["updateRenderedTab"];
    value: string;
}
export declare function useRenderedTabWidth({ hostElement, renderMode, tabRootRef, targetWindow, updateRenderedTab, value, }: UseRenderedTabWidthProps): void;
export {};

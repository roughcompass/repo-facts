import { type ComponentPropsWithoutRef } from "react";
export interface TabSlotProps extends ComponentPropsWithoutRef<"div"> {
    slotId: string;
    value: string;
}
export declare function TabSlot({ slotId, value, ...rest }: TabSlotProps): import("react").JSX.Element;

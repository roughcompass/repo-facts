import { type ComponentPropsWithoutRef, type Dispatch, type Ref, type SetStateAction } from "react";
interface TabOverflowListProps extends ComponentPropsWithoutRef<"button"> {
    buttonRef?: Ref<HTMLButtonElement>;
    hiddenValues: string[];
    open: boolean;
    setOpen: Dispatch<SetStateAction<boolean>>;
    order: number;
}
export declare const TabOverflowList: import("react").ForwardRefExoticComponent<TabOverflowListProps & import("react").RefAttributes<HTMLDivElement>>;
export {};

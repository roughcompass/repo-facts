import { type MutableRefObject, type RefObject } from "react";
interface UseTabListRecoveryArgs {
    removalVersion: number;
    targetWindow: Window | null | undefined;
    tabstripRef: RefObject<HTMLDivElement | null>;
    overflowListRef: RefObject<HTMLDivElement | null>;
    handleTabRemoval: () => void;
    pendingRemovalRecoveryRef: MutableRefObject<boolean>;
    pendingRemovalRecoveryRetriesRef: MutableRefObject<number>;
}
export declare function useTabListRecovery({ removalVersion, targetWindow, tabstripRef, overflowListRef, handleTabRemoval, pendingRemovalRecoveryRef, pendingRemovalRecoveryRetriesRef, }: UseTabListRecoveryArgs): void;
export {};

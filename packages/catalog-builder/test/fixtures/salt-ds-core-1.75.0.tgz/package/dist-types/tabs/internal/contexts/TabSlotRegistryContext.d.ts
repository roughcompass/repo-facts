export interface TabSlotRegistryContextValue {
    registerSlot: (slotId: string, element: HTMLDivElement | null) => void;
}
export declare const TabSlotRegistryContext: import("react").Context<TabSlotRegistryContextValue | null>;
export declare function useTabSlotRegistry(): TabSlotRegistryContextValue | null;

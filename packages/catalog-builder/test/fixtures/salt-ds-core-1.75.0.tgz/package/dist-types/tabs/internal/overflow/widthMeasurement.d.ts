export declare function getMeasuredWidth(element: HTMLElement | null | undefined): number;
export declare function getIntrinsicMeasuredWidth(element: HTMLElement | null | undefined): number;
export declare function getGapValue(styles: CSSStyleDeclaration): number;
export declare function seedWidthMap(elements: HTMLElement[]): Map<HTMLElement, number>;
export declare function updateWidthMap(widths: Map<HTMLElement, number>, element: HTMLElement, nextWidth: number, epsilon?: number): boolean;

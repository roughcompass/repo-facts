import { type ComponentPropsWithoutRef } from "react";
export interface TabPanelProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The value of the panel. This should map to the corresponding tab and must
     * be unique within a `Tabs` instance.
     */
    value: string;
}
export declare const TabPanel: import("react").ForwardRefExoticComponent<TabPanelProps & import("react").RefAttributes<HTMLDivElement>>;

import type { MutableRefObject } from "react";
import type { TabsContextValue } from "../contexts/TabsContext";
interface UseTabSelectionFocusArgs {
    announce: (message: string, timeout?: number) => void;
    focusElementWithRetry: (getElement: () => HTMLElement | null | undefined) => void;
    getRenderedTab: TabsContextValue["getRenderedTab"];
    getSelectedTabElement: () => HTMLElement | null | undefined;
    menuOpen: boolean;
    resolvedOverflowActiveValue: string | null;
    selected?: string;
    selectionFromOverflowValueRef: MutableRefObject<string | null>;
    targetWindow: Window | null | undefined;
}
export declare function useTabSelectionFocus({ announce, focusElementWithRetry, getRenderedTab, getSelectedTabElement, menuOpen, resolvedOverflowActiveValue, selected, selectionFromOverflowValueRef, targetWindow, }: UseTabSelectionFocusArgs): void;
export {};

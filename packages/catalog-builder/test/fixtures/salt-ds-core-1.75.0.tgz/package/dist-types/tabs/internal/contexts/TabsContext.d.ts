import { type Dispatch, type MutableRefObject, type SetStateAction, type SyntheticEvent } from "react";
import type { useCollection } from "../registry/useCollection";
export interface Item {
    id: string;
    value: string;
    element: HTMLElement | null;
    location?: "hidden" | "main" | "overflow";
    order?: number;
}
export interface RenderedTab {
    host: HTMLDivElement;
    id: string;
    marker: HTMLElement | null;
    root: HTMLElement | null;
    trigger: HTMLButtonElement | null;
    value: string;
    width: number;
}
export type TabsRenderMode = "inline" | "portal";
export interface TabsContextValue extends Omit<ReturnType<typeof useCollection>, "registerItem" | "updateItem"> {
    renderMode: TabsRenderMode;
    registerBootstrapTab: (value: string) => () => void;
    setBootstrapTabReady: (value: string, ready: boolean) => void;
    setBootstrapOverflowReady: (ready: boolean) => void;
    registerTab: (item: Item) => () => void;
    updateTab: (id: string, updates: Partial<Omit<Item, "id" | "value">>) => void;
    registerRenderedTab: (tab: RenderedTab) => () => void;
    updateRenderedTab: (value: string, updates: Partial<Omit<RenderedTab, "value">>) => void;
    getRenderedTab: (value: string) => RenderedTab | undefined;
    getRenderedTabOrder: (value: string) => number;
    renderedTabs: RenderedTab[];
    registerPanel: (id: string, value: string) => () => void;
    getPanelId: (value: string) => string | undefined;
    getTabId: (value: string) => string | undefined;
    selected?: string;
    setSelected: (event: SyntheticEvent | null, value: string, source?: "main" | "overflow") => void;
    activeTab: MutableRefObject<Pick<Item, "id" | "value"> | undefined>;
    selectionFromOverflowValueRef: MutableRefObject<string | null>;
    menuOpen: boolean;
    setMenuOpen: Dispatch<SetStateAction<boolean>>;
}
export declare const TabsContext: import("react").Context<TabsContextValue>;
export declare function useTabs(): TabsContextValue;

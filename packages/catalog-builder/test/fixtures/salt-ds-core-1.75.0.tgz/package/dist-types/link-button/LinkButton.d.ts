import type { IconProps } from "@salt-ds/icons";
import { type ComponentPropsWithoutRef, type ComponentType } from "react";
import { type RenderPropsType } from "../utils";
export interface LinkButtonProps extends ComponentPropsWithoutRef<"a"> {
    /**
     * Icon component displayed when `target="_blank"`. Defaults to `ExternalIcon` from `SemanticIconProvider`.
     */
    IconComponent?: ComponentType<IconProps> | null;
    /**
     * The sentiment of the button. Options are 'accented' and 'neutral'.
     * 'neutral' is the default value.
     */
    sentiment?: "accented" | "neutral";
    /**
     * Render prop to enable customisation of anchor element.
     */
    render?: RenderPropsType["render"];
    /**
     * Either "default" or "never".
     * Determines when underline should be applied to the link button.
     *
     * @default "default".
     */
    underline?: "default" | "never";
}
export declare const LinkButton: import("react").ForwardRefExoticComponent<LinkButtonProps & import("react").RefAttributes<HTMLAnchorElement>>;

import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface ToggletipPanelProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of Toggletip Panel
     */
    children?: ReactNode;
}
export declare const ToggletipPanel: import("react").ForwardRefExoticComponent<ToggletipPanelProps & import("react").RefAttributes<HTMLDivElement>>;

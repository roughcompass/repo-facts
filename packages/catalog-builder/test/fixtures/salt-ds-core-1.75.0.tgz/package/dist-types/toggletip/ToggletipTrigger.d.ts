import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface ToggletipTriggerProps extends ComponentPropsWithoutRef<"button"> {
    children?: ReactNode;
}
export declare const ToggletipTrigger: import("react").ForwardRefExoticComponent<ToggletipTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;

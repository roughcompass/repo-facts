import { type ReactNode } from "react";
export interface ToggletipProps {
    children?: ReactNode;
    /**
     * Display or hide the component.
     */
    open?: boolean;
    /**
     * Callback function triggered when open state changes.
     */
    onOpenChange?: (open: boolean) => void;
    placement?: "top" | "bottom" | "left" | "right";
}
export declare const Toggletip: ({ children, open, onOpenChange, placement, }: ToggletipProps) => import("react").JSX.Element;

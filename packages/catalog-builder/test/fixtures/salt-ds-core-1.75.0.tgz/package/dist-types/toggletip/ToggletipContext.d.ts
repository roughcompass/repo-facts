import type { FloatingRootContext, Placement } from "@floating-ui/react";
import { type Dispatch, type HTMLProps, type SetStateAction } from "react";
export interface ToggletipContextValue {
    openState: boolean;
    floatingRootContext: FloatingRootContext;
    placement: Placement;
    floatingContent: HTMLDivElement | null;
    getFloatingProps: (userProps?: HTMLProps<HTMLElement> | undefined) => Record<string, unknown>;
    getReferenceProps: (userProps?: HTMLProps<Element> | undefined) => Record<string, unknown>;
    setFloating: Dispatch<SetStateAction<HTMLDivElement | null>>;
    setFloatingContent: Dispatch<SetStateAction<HTMLDivElement | null>>;
    setReference: Dispatch<SetStateAction<HTMLButtonElement | null>>;
    setTriggerId: Dispatch<SetStateAction<string | undefined>>;
    triggerId: string | undefined;
}
export declare const ToggletipContext: import("react").Context<ToggletipContextValue>;
export declare function useToggletipContext(): ToggletipContextValue;

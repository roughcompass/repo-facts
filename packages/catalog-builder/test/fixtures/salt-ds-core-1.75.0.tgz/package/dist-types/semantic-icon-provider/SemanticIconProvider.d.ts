import { type ElementType, type ReactNode } from "react";
export interface SemanticIconMap {
    ActiveIcon: ElementType;
    CalendarIcon: ElementType;
    CloseIcon: ElementType;
    CollapseGroupIcon: ElementType;
    CollapseIcon: ElementType;
    CollapseLeftIcon: ElementType;
    CollapseRightIcon: ElementType;
    CompletedIcon: ElementType;
    DecreaseIcon: ElementType;
    EntityIcon: ElementType;
    ErrorIcon: ElementType;
    ErrorStatusAdornment: ElementType;
    ExpandGroupIcon: ElementType;
    ExpandIcon: ElementType;
    ExternalIcon: ElementType;
    IncreaseIcon: ElementType;
    InfoIcon: ElementType;
    InProgressIcon: ElementType;
    LockedIcon: ElementType;
    LevelSeparatorIcon: ElementType;
    NextIcon: ElementType;
    OverflowIcon: ElementType;
    PendingIcon: ElementType;
    PreviousIcon: ElementType;
    RatingIcon: ElementType;
    RatingSelectedIcon: ElementType;
    RatingUnselectingIcon: ElementType;
    SuccessIcon: ElementType;
    SuccessStatusAdornment: ElementType;
    UploadIcon: ElementType;
    UserIcon: ElementType;
    WarningIcon: ElementType;
    WarningStatusAdornment: ElementType;
}
export interface SemanticIconProviderProps {
    /**
     * Custom mapping of icon names to components. Overrides default icons if provided.
     */
    iconMap?: Partial<SemanticIconMap>;
    /**
     * Child elements that will use the provided icons.
     */
    children: ReactNode;
}
export declare const SemanticIconProvider: ({ iconMap, children, }: SemanticIconProviderProps) => import("react").JSX.Element;
export declare const useIcon: () => SemanticIconMap;

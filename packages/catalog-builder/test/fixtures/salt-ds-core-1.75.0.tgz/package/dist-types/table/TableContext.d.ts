export interface TableContextValue {
    id?: string;
    setId: (id: string) => void;
    labelledBy?: string;
    setLabelledBy: (labelId: string) => void;
}
export declare const TableContext: import("react").Context<TableContextValue>;
export declare function useTable(): TableContextValue;

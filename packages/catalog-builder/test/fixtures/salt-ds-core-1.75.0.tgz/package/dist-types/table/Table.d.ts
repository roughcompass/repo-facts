import { type ComponentPropsWithoutRef } from "react";
export interface TableProps extends ComponentPropsWithoutRef<"table"> {
    /**
     * Styling variant. Defaults to "primary".
     * @default primary
     */
    variant?: "primary" | "secondary" | "tertiary";
    /**
     * Divider styling variant. Defaults to "tertiary";
     * @default tertiary
     */
    divider?: "primary" | "secondary" | "tertiary" | "none";
    /**
     * Zebra styling. Applies a different fill to every other row.
     * @default false
     */
    zebra?: boolean;
}
export declare const withTableBaseName: import("..").ClassNamePrefixer;
export declare const Table: import("react").ForwardRefExoticComponent<TableProps & import("react").RefAttributes<HTMLTableElement>>;

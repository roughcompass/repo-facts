import { type ComponentPropsWithoutRef } from "react";
export interface TRProps extends ComponentPropsWithoutRef<"tr"> {
}
export declare const TR: import("react").ForwardRefExoticComponent<TRProps & import("react").RefAttributes<HTMLTableRowElement>>;

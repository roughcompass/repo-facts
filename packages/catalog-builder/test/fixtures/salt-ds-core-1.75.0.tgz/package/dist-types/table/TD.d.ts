import { type ComponentPropsWithoutRef } from "react";
export interface TDProps extends ComponentPropsWithoutRef<"td"> {
    /**
     * Specifies the alignment of the text within the `TD`.
     *
     * @default "left"
     */
    textAlign?: "left" | "right";
}
export declare const TD: import("react").ForwardRefExoticComponent<TDProps & import("react").RefAttributes<HTMLTableCellElement>>;

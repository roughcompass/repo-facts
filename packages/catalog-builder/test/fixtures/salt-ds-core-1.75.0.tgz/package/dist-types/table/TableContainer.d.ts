import { type ComponentPropsWithoutRef } from "react";
export interface TableContainerProps extends Omit<ComponentPropsWithoutRef<"div">, "aria-label" | "aria-labelledby" | "role"> {
}
export declare const TableContainer: import("react").ForwardRefExoticComponent<TableContainerProps & import("react").RefAttributes<HTMLDivElement>>;

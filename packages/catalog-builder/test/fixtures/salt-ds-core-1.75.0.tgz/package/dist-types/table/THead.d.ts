import { type ComponentPropsWithoutRef } from "react";
export interface THeadProps extends ComponentPropsWithoutRef<"thead"> {
    /**
     * If header is positioned with sticky styling.
     * @default false
     */
    sticky?: boolean;
    /**
     * Divider styling variant. Defaults to "primary";
     * @default primary
     */
    divider?: "primary" | "secondary" | "tertiary" | "none";
    /**
     * Styling variant for header.
     * If undefined, will match variant of parent Table component's variant.
     * @default undefined
     */
    variant?: "primary" | "secondary" | "tertiary";
}
export declare const THead: import("react").ForwardRefExoticComponent<THeadProps & import("react").RefAttributes<HTMLTableSectionElement>>;

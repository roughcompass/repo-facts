import { type ComponentPropsWithoutRef } from "react";
export interface TBodyProps extends ComponentPropsWithoutRef<"tbody"> {
}
export declare const TBody: import("react").ForwardRefExoticComponent<TBodyProps & import("react").RefAttributes<HTMLTableSectionElement>>;

import { type ComponentPropsWithoutRef } from "react";
export interface THProps extends ComponentPropsWithoutRef<"th"> {
    /**
     * Specifies the alignment of the text within the `TH`.
     *
     * @default "left"
     */
    textAlign?: "left" | "right";
}
export declare const TH: import("react").ForwardRefExoticComponent<THProps & import("react").RefAttributes<HTMLTableCellElement>>;

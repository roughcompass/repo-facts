import { type ChangeEvent, type ComponentPropsWithoutRef, type MouseEvent } from "react";
export interface RatingItemProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * specifies the value of the feedback item.
     */
    value: number;
    /**
     * To define if the current star is being hovered.
     */
    isHovered?: boolean;
    /**
     * To specify if the item is selected.
     */
    isSelected?: boolean;
    /**
     * defines the current selected rating.
     */
    currentRating?: number;
    /**
     *  callback function when feedback item is hovered.
     */
    onMouseEnter: (event: MouseEvent<HTMLInputElement>) => void;
    /**
     *  callback function when feedback item is clicked.
     */
    onChange: (event: ChangeEvent<HTMLInputElement>) => void;
    /**
     * If true, the rating item will be in a read-only state.
     */
    readOnly?: boolean;
    /**
     * If true, the rating item will be in a disabled state.
     */
    disabled?: boolean;
    /**
     * Indicates whether the current rating item is in an active state.
     * An active state typically means that the item is visually highlighted
     * or styled differently to indicate that it is part of the current selection
     * or interaction (e.g., hover or focus).
     */
    isUnselecting?: boolean;
    /**
     * Name of the radio group
     */
    name?: string;
}
export declare const RatingItem: import("react").ForwardRefExoticComponent<RatingItemProps & import("react").RefAttributes<HTMLInputElement>>;

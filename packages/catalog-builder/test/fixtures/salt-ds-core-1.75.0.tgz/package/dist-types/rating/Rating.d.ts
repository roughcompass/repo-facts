import { type ChangeEvent, type ComponentPropsWithoutRef } from "react";
export interface RatingProps extends Omit<ComponentPropsWithoutRef<"div">, "onChange"> {
    /**
     * When provided, the component is controlled.
     */
    value?: number;
    /**
     * Default rating value for uncontrolled mode.
     * @default 0
     */
    defaultValue?: number;
    /**
     * Callback function for rating change.
     * The first parameter is the event, and the second is the selected rating value.
     */
    onChange?: (event: ChangeEvent<HTMLInputElement>, value: number) => void;
    /**
     * If true, the rating component will be in a read-only state.
     */
    readOnly?: boolean;
    /**
     * If true, the rating component will be in a disabled state.
     */
    disabled?: boolean;
    /**
     * Total number of icons displayed.
     * @default 5
     */
    max?: number;
    /**
     * Function used to provide a user-friendly name for the current value of the rating. Primarily used by screen readers.
     */
    getLabel?: (value: number) => string;
    /**
     * Function used to provide a visible label for the rating.
     */
    getVisibleLabel?: (value: number, max: number) => string;
    /**
     * Position of the label relative to the rating component.
     * @default "right"
     */
    labelPlacement?: "right" | "bottom";
    /**
     * The name to be set on each radio button within the group. If not set, then one will be generated for you.
     */
    name?: string;
}
export declare const Rating: import("react").ForwardRefExoticComponent<RatingProps & import("react").RefAttributes<HTMLDivElement>>;

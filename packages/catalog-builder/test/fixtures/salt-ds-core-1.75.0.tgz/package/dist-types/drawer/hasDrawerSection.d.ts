import { type ReactNode } from "react";
export declare function hasDrawerSection(children: ReactNode): boolean;

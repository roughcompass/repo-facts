import { type ComponentPropsWithoutRef } from "react";
export type DrawerContentProps = ComponentPropsWithoutRef<"div">;
export declare const DrawerContent: import("react").ForwardRefExoticComponent<Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;

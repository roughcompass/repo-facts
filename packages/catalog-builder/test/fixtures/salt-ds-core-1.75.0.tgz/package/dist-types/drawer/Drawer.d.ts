import { type FloatingFocusManager } from "@floating-ui/react";
import { type ComponentPropsWithoutRef } from "react";
export interface DrawerProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Defines the drawer position within the screen. Defaults to `left`.
     */
    position?: "left" | "top" | "right" | "bottom";
    /**
     * Display or hide the component.
     */
    open?: boolean;
    /**
     * Callback function triggered when open state changes.
     */
    onOpenChange?: (newOpen: boolean) => void;
    /**
     * Change background color palette
     */
    variant?: "primary" | "secondary" | "tertiary";
    /**
     * Prevent the drawer closing on click away
     * */
    disableDismiss?: boolean;
    /**
     * Prevent Scrim from rendering
     * */
    disableScrim?: boolean;
    /**
     * Allow the user to resize the drawer. Set size limits with the `--saltDrawer-minResize`/`--saltDrawer-maxResize`
     * variables, which apply to the width of `left` and `right` drawers and the height of `top` and `bottom` drawers.
     * The drawer never shrinks below `--salt-size-base`, unless `min-width`/`min-height` is set directly.
     * */
    resizable?: boolean;
    /**
     * Which element to initially focus. Can be either a number (tabbable index as specified by the order) or a ref.
     * Default value is 0 (first tabbable element).
     * */
    initialFocus?: ComponentPropsWithoutRef<typeof FloatingFocusManager>["initialFocus"];
}
export declare const Drawer: import("react").ForwardRefExoticComponent<DrawerProps & import("react").RefAttributes<HTMLDivElement>>;

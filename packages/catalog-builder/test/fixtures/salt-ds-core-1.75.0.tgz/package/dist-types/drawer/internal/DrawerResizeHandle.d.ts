import { type ComponentPropsWithoutRef } from "react";
import type { DrawerProps } from "../Drawer";
export interface DrawerResizeHandleProps extends ComponentPropsWithoutRef<"div"> {
    position: NonNullable<DrawerProps["position"]>;
    resizing?: boolean;
    hovered?: boolean;
}
export declare const DrawerResizeHandle: import("react").ForwardRefExoticComponent<DrawerResizeHandleProps & import("react").RefAttributes<HTMLDivElement>>;

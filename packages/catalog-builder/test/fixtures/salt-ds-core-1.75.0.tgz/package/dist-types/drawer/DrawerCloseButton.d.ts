import { type ButtonProps } from "../button";
/**
 * @deprecated since 1.71.0. Use `Button` in `DrawerHeader`'s `actions` instead.
 */
export declare const DrawerCloseButton: import("react").ForwardRefExoticComponent<ButtonProps & import("react").RefAttributes<HTMLButtonElement>>;

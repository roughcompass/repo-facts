import { type ComponentPropsWithoutRef } from "react";
export type DrawerFooterProps = ComponentPropsWithoutRef<"div">;
export declare const DrawerFooter: import("react").ForwardRefExoticComponent<Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "ref"> & import("react").RefAttributes<HTMLDivElement>>;

import type { AriaAttributes, CSSProperties, KeyboardEvent as ReactKeyboardEvent, MouseEvent as ReactMouseEvent, PointerEvent as ReactPointerEvent } from "react";
import type { DrawerProps } from "../Drawer";
type DrawerPosition = NonNullable<DrawerProps["position"]>;
export interface SeparatorProps extends Pick<AriaAttributes, "aria-orientation" | "aria-valuenow" | "aria-valuemin" | "aria-valuemax"> {
    role: "separator";
    tabIndex: number;
    ref: (element: HTMLElement | null) => void;
    onKeyDown: (event: ReactKeyboardEvent<HTMLElement>) => void;
    onFocus: () => void;
}
export interface GuideProps {
    ref: (element: HTMLElement | null) => void;
    onPointerDown: (event: ReactPointerEvent<HTMLElement>) => void;
    onPointerMove: (event: ReactPointerEvent<HTMLElement>) => void;
    onClick: (event: ReactMouseEvent<HTMLElement>) => void;
    onContextMenu: () => void;
}
export interface UseDrawerResizeProps {
    enabled: boolean;
    position: DrawerPosition;
    element: HTMLElement | null | undefined;
}
export interface UseDrawerResizeResult {
    sizeStyle: CSSProperties | undefined;
    isResizing: boolean;
    isHovered: boolean;
    isPlacing: boolean;
    /** Whether the event is the Escape that cancelled a resize, so it shouldn't close the drawer. */
    isCancelResizeEvent: (event?: Event) => boolean;
    separatorProps: SeparatorProps;
    guideProps: GuideProps;
}
export declare function useDrawerResize({ enabled, position, element, }: UseDrawerResizeProps): UseDrawerResizeResult;
export {};

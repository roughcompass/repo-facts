import type { DrawerProps } from "./Drawer";
export interface DrawerContextValue {
    drawerId?: string;
    position?: DrawerProps["position"];
    resizable?: boolean;
    headerId?: string;
    setHeaderId?: (id: string | undefined) => void;
    descriptionId?: string;
    setDescriptionId?: (id: string | undefined) => void;
}
export declare const DrawerContext: import("react").Context<DrawerContextValue>;
export declare const useDrawerContext: () => DrawerContextValue;

import { type ComponentPropsWithoutRef } from "react";
import type { DrawerProps } from "../Drawer";
export interface DrawerResizeGuideProps extends ComponentPropsWithoutRef<"div"> {
    position: NonNullable<DrawerProps["position"]>;
}
/** Covers the viewport while placing the edge by click, so the click doesn't reach the content. */
export declare const DrawerResizeGuide: import("react").ForwardRefExoticComponent<DrawerResizeGuideProps & import("react").RefAttributes<HTMLDivElement>>;

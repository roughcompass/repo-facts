import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface DrawerHeaderProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Hides the accent bar in the Drawer Header. Defaults to `true` when the Drawer is resizable and positioned `right`, otherwise `false`.
     */
    disableAccent?: boolean;
    /**
     * Displays the header at the top of the Drawer
     */
    header?: ReactNode;
    /**
     * Displays the preheader just above the header
     **/
    preheader?: ReactNode;
    /**
     * Description text is displayed just below the header
     **/
    description?: ReactNode;
    /**
     * Actions to be displayed in header
     */
    actions?: ReactNode;
}
export declare const DrawerHeader: import("react").ForwardRefExoticComponent<DrawerHeaderProps & import("react").RefAttributes<HTMLDivElement>>;

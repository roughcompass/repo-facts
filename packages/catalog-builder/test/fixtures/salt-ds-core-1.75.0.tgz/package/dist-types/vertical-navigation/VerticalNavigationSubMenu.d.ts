import { type ComponentPropsWithoutRef } from "react";
export interface VerticalNavigationSubMenuProps extends ComponentPropsWithoutRef<"ul"> {
}
export declare const VerticalNavigationSubMenu: import("react").ForwardRefExoticComponent<VerticalNavigationSubMenuProps & import("react").RefAttributes<HTMLUListElement>>;

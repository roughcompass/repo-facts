import { type ComponentPropsWithoutRef } from "react";
import { type RenderPropsType } from "../utils";
export interface VerticalNavigationItemTriggerProps extends ComponentPropsWithoutRef<"a"> {
    render?: RenderPropsType["render"];
}
export declare const VerticalNavigationItemTrigger: import("react").ForwardRefExoticComponent<VerticalNavigationItemTriggerProps & import("react").RefAttributes<HTMLAnchorElement>>;

import { type Dispatch, type ReactNode, type SetStateAction } from "react";
type SubMenuContextValue = {
    depth: number;
    iconPaddingCount: number;
    setDirectIcons?: Dispatch<SetStateAction<string[]>>;
};
export declare const SubMenuContext: import("react").Context<SubMenuContextValue>;
export declare const useSubMenuContext: () => SubMenuContextValue;
export declare function SubMenuProvider({ children, directIcons, setDirectIcons, }: {
    children: ReactNode;
    directIcons: string[];
    setDirectIcons?: Dispatch<SetStateAction<string[]>>;
}): import("react").JSX.Element;
export {};

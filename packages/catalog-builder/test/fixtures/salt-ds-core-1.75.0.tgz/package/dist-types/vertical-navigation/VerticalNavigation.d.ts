import { type ComponentPropsWithoutRef } from "react";
export interface VerticalNavigationProps extends ComponentPropsWithoutRef<"nav"> {
    /**
     * The appearance of the tabs. Defaults to "bordered".
     */
    appearance?: "indicator" | "bordered";
}
export declare const VerticalNavigation: import("react").ForwardRefExoticComponent<VerticalNavigationProps & import("react").RefAttributes<HTMLElement>>;

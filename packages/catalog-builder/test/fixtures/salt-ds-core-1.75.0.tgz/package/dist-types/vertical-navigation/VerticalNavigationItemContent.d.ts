import { type ComponentPropsWithoutRef } from "react";
export interface VerticalNavigationItemContentProps extends ComponentPropsWithoutRef<"span"> {
}
export declare const VerticalNavigationItemContent: import("react").ForwardRefExoticComponent<VerticalNavigationItemContentProps & import("react").RefAttributes<HTMLSpanElement>>;

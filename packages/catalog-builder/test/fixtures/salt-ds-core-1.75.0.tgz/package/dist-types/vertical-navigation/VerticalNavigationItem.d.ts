import { type ComponentPropsWithoutRef, type Dispatch, type SetStateAction } from "react";
export interface VerticalNavigationItemProps extends ComponentPropsWithoutRef<"li"> {
    active?: boolean;
}
type VerticalNavigationItemContextType = {
    active: boolean;
    focusVisible: boolean;
    setFocusVisible: Dispatch<SetStateAction<boolean>>;
};
export declare function useVerticalNavigationItem(): VerticalNavigationItemContextType;
export declare const VerticalNavigationItem: import("react").ForwardRefExoticComponent<VerticalNavigationItemProps & import("react").RefAttributes<HTMLLIElement>>;
export {};

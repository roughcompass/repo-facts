import { type ComponentPropsWithoutRef } from "react";
export interface VerticalNavigationItemLabelProps extends ComponentPropsWithoutRef<"span"> {
}
export declare const VerticalNavigationItemLabel: import("react").ForwardRefExoticComponent<VerticalNavigationItemLabelProps & import("react").RefAttributes<HTMLSpanElement>>;

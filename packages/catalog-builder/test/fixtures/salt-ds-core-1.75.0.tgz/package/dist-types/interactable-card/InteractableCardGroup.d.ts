import { type ComponentPropsWithoutRef, type SyntheticEvent } from "react";
import { type InteractableCardValue } from "./InteractableCardGroupContext";
export interface InteractableCardGroupProps extends Omit<ComponentPropsWithoutRef<"div">, "onChange"> {
    /**
     * The default value. Use when the component is not controlled. Should be an array when `multiSelect` is true.
     */
    defaultValue?: InteractableCardValue;
    /**
     * If `true`, the Interactable Card Group will be disabled.
     */
    disabled?: boolean;
    /**
     * The value. Use when the component is controlled. Should be an array when `multiSelect` is true.
     */
    value?: InteractableCardValue;
    /**
     * If `true` the Interactable Card Group will allow multiple selection functionality, with keyboard interactions matching those of a checkbox.
     * By default the group allows mutually exclusive selection with keyboard interactions matching radio buttons.
     */
    multiSelect?: boolean;
    /**
     * Callback fired when the selection changes.
     * @param event
     */
    onChange?: (event: SyntheticEvent<HTMLDivElement>, value: InteractableCardValue) => void;
}
export declare const InteractableCardGroup: import("react").ForwardRefExoticComponent<InteractableCardGroupProps & import("react").RefAttributes<HTMLDivElement>>;

import { type ComponentPropsWithoutRef, type SyntheticEvent } from "react";
import { type InteractableCardValue } from "./InteractableCardGroupContext";
export interface InteractableCardProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * If provided an accent is shown in the specified position.
     */
    accent?: "bottom" | "top" | "left" | "right";
    /**
     * Visual elevation.
     */
    elevation?: "flat" | "raised";
    /**
     * Border color strength.
     */
    borderColor?: "strong" | "subtle" | "none";
    /**
     * @deprecated since 1.23.0. Use the `accent` prop instead.
     */
    accentPlacement?: "bottom" | "top" | "left" | "right";
    /**
     * If `true`, the card will be disabled.
     */
    disabled?: boolean;
    /**
     * Callback fired when the selection changes.
     * @param event
     */
    onChange?: (event: SyntheticEvent<HTMLDivElement>) => void;
    /**
     * Styling variant; defaults to "primary".
     */
    variant?: "primary" | "secondary" | "tertiary";
    /**
     * Value of card (for selectable use case).
     */
    value?: InteractableCardValue;
}
export declare const InteractableCard: import("react").ForwardRefExoticComponent<InteractableCardProps & import("react").RefAttributes<HTMLDivElement>>;

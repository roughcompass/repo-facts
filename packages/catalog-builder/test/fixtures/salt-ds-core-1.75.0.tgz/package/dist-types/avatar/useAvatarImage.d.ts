import { type ImgHTMLAttributes } from "react";
type ImageLoadingStatus = "pending" | "loading" | "loaded" | "error";
export declare function useAvatarImage({ src, referrerPolicy, crossOrigin, }: ImgHTMLAttributes<HTMLImageElement>): ImageLoadingStatus;
export {};

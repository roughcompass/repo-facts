import { type HTMLAttributes, type ReactNode } from "react";
import { type RenderPropsType } from "../utils";
export type NameToInitials = (name?: string) => string;
export interface AvatarProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * The name that Avatar represents.
     */
    name?: string;
    /**
     * Defines the function that gets initials. Default is capital first letter of each separate word in name.
     * If a function is not passed or returns undefined, Avatar will default to Icon.
     */
    nameToInitials?: NameToInitials;
    /**
     * Image src of Avatar.
     */
    src?: string;
    /**
     * Multiplier for the base avatar.
     */
    size?: number;
    /**
     * Icon to be used as a default item. Defaults to the semantic `UserIcon` when
     * `kind` is `"person"`, and the semantic `EntityIcon` when `kind`
     * is `"entity"`.
     */
    fallbackIcon?: ReactNode;
    /**
     * What the Avatar depicts, which determines its default shape and fallback icon:
     * - `"person"` renders a circular Avatar (default).
     * - `"entity"` renders a square Avatar.
     *
     * @default "person"
     */
    kind?: "person" | "entity";
    /**
     * Changes Avatar's color.
     */
    color?: "accent" | "category-1" | "category-2" | "category-3" | "category-4" | "category-5" | "category-6" | "category-7" | "category-8" | "category-9" | "category-10" | "category-11" | "category-12" | "category-13" | "category-14" | "category-15" | "category-16" | "category-17" | "category-18" | "category-19" | "category-20";
    /**
     * Render prop to enable customization of the avatar root element.
     */
    render?: RenderPropsType["render"];
}
export declare const Avatar: import("react").ForwardRefExoticComponent<AvatarProps & import("react").RefAttributes<HTMLDivElement>>;

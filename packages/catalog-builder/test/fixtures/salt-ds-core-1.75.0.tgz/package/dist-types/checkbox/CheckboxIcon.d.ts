import type { ReactElement } from "react";
import type { AdornmentValidationStatus } from "../status-adornment";
export interface CheckboxIconProps {
    checked?: boolean;
    className?: string;
    disabled?: boolean;
    /**
     * @deprecated since 1.8.0-rc.2. Use `validationStatus` instead.
     */
    error?: boolean;
    indeterminate?: boolean;
    readOnly?: boolean;
    validationStatus?: AdornmentValidationStatus;
}
export declare const CheckboxIcon: ({ checked, className, disabled, error, indeterminate, validationStatus, readOnly, }: CheckboxIconProps) => ReactElement;

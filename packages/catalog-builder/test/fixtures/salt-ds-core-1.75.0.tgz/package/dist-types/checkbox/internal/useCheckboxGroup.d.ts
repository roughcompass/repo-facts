export declare function useCheckboxGroup(): import("./CheckboxGroupContext").CheckboxGroupState | undefined;

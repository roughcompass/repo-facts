import { type ChangeEventHandler, type ComponentPropsWithoutRef } from "react";
import type { AdornmentValidationStatus } from "../status-adornment";
export interface CheckboxGroupProps extends Omit<ComponentPropsWithoutRef<"fieldset">, "onChange"> {
    /**
     * The current checked options.
     */
    checkedValues?: string[];
    /**
     * The default selected options for un-controlled component.
     */
    defaultCheckedValues?: string[];
    /**
     * Display group of elements in a compact row.
     */
    direction?: "horizontal" | "vertical";
    /**
     * Disable the Checkbox group
     */
    disabled?: boolean;
    /**
     * The name used to reference the value of the control.
     */
    name?: string;
    /**
     * Callback fired when a checkbox is clicked.
     * `event.target.value` returns the value of the checkbox that was clicked.
     */
    onChange?: ChangeEventHandler<HTMLInputElement>;
    /**
     * If `true`, the component is read only.
     */
    readOnly?: boolean;
    /**
     * Only for horizontal direction. When `true` the text in radio button label will wrap to fit within the container. Otherwise, the checkboxes will wrap onto the next line.
     */
    wrap?: boolean;
    /**
     * Validation status.
     */
    validationStatus?: AdornmentValidationStatus;
}
export declare const CheckboxGroup: import("react").ForwardRefExoticComponent<CheckboxGroupProps & import("react").RefAttributes<HTMLFieldSetElement>>;

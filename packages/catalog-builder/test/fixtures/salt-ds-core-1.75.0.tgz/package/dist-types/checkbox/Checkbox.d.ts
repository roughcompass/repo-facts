import { type ChangeEventHandler, type FocusEventHandler, type InputHTMLAttributes, type ReactNode, type Ref } from "react";
import type { AdornmentValidationStatus } from "../status-adornment";
import type { DataAttributes } from "../types";
export interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLLabelElement>, "onChange" | "onBlur" | "onFocus"> {
    /**
     * If `true`, the checkbox will be checked.
     */
    checked?: boolean;
    /**
     * Whether the checkbox component is checked by default
     * This will be disregarded if checked is already set.
     */
    defaultChecked?: boolean;
    /**
     * If `true`, the checkbox will be disabled.
     */
    disabled?: boolean;
    /**
     * **Deprecated**: Use validationStatus instead
     * If `true`, the checkbox will be in the error state.
     */
    error?: boolean;
    /**
     * If true, the checkbox appears indeterminate. A data-indeterminate attribute is set on the input.
     */
    indeterminate?: boolean;
    /**
     * Properties applied to the input element.
     */
    inputProps?: Partial<InputHTMLAttributes<HTMLInputElement>> & DataAttributes;
    /**
     * Used to access the hidden `<input>` element.
     */
    inputRef?: Ref<HTMLInputElement>;
    /**
     * The label to be shown next to the checkbox.
     */
    label?: ReactNode;
    /**
     * The name applied to the input.
     */
    name?: string;
    /**
     * Callback when checkbox loses focus.
     */
    onBlur?: FocusEventHandler<HTMLInputElement>;
    /**
     * Callback when checked state is changed.
     */
    onChange?: ChangeEventHandler<HTMLInputElement>;
    /**
     * Callback when checkbox gains focus.
     */
    onFocus?: FocusEventHandler<HTMLInputElement>;
    /**
     * The value of the checkbox.
     */
    value?: string;
    /**
     * Validation status, one of "warning" | "error" | "success"
     *
     * Checkbox has styling variants for "error" and "warning".
     * No visual styling will be applied on "success" variant.
     */
    validationStatus?: AdornmentValidationStatus;
}
export declare const Checkbox: import("react").ForwardRefExoticComponent<CheckboxProps & import("react").RefAttributes<HTMLLabelElement>>;

import type { AdornmentValidationStatus } from "../../status-adornment";
import type { CheckboxGroupProps } from "../CheckboxGroup";
export interface CheckboxGroupState {
    disabled?: boolean;
    name?: CheckboxGroupProps["name"];
    onChange?: CheckboxGroupProps["onChange"];
    checkedValues?: CheckboxGroupProps["checkedValues"];
    readOnly?: boolean;
    validationStatus?: AdornmentValidationStatus;
}
declare const CheckboxGroupContext: import("react").Context<CheckboxGroupState | undefined>;
export { CheckboxGroupContext };

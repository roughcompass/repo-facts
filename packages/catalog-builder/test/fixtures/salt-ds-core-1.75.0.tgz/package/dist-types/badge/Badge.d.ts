import { type HTMLAttributes, type ReactNode } from "react";
export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
    /**
     * The number to display on the badge. If `value` is not provided,
     * the badge will render as a dot badge.
     */
    value?: number | string;
    /**
     * If a child is provided the Badge will render top right. By defualt renders inline.
     */
    children?: ReactNode;
    /**
     * The max number to display on the badge.
     */
    max?: number;
}
export declare const Badge: import("react").ForwardRefExoticComponent<BadgeProps & import("react").RefAttributes<HTMLSpanElement>>;

export interface MegaMenuGroupContextValue {
    /**
     * The rendered heading's id, used to label the item list via `aria-labelledby`.
     * `undefined` when the group has no `MegaMenuGroupHeading`.
     */
    headingId: string | undefined;
    /** Register (or clear, with `undefined`) the heading's id. */
    setHeadingId: (id: string | undefined) => void;
}
export declare const MegaMenuGroupContext: import("react").Context<MegaMenuGroupContextValue>;
/** Access the nearest `MegaMenuGroup` context. */
export declare function useMegaMenuGroup(): MegaMenuGroupContextValue;

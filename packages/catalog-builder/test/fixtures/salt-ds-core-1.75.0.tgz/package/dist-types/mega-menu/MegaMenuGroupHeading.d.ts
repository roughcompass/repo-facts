import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MegaMenuGroupHeadingProps extends ComponentPropsWithoutRef<"h2"> {
    /**
     * The content of the mega menu group heading.
     */
    children?: ReactNode;
    /**
     * The heading element to render.
     * @default "h3"
     */
    as?: "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
}
export declare const MegaMenuGroupHeading: import("react").ForwardRefExoticComponent<MegaMenuGroupHeadingProps & import("react").RefAttributes<HTMLHeadingElement>>;

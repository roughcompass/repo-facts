import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MegaMenuContentProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of the mega menu navigation area, typically a `MegaMenuGroups`
     * and an optional `MegaMenuActions`.
     */
    children?: ReactNode;
}
export declare const MegaMenuContent: import("react").ForwardRefExoticComponent<MegaMenuContentProps & import("react").RefAttributes<HTMLDivElement>>;

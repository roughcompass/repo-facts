import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MegaMenuGroupsProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The `MegaMenuGroup` columns of the mega menu.
     */
    children?: ReactNode;
}
export declare const MegaMenuGroups: import("react").ForwardRefExoticComponent<MegaMenuGroupsProps & import("react").RefAttributes<HTMLDivElement>>;

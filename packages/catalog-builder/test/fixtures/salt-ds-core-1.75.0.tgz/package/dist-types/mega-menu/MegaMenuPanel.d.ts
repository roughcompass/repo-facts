import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MegaMenuPanelProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of the mega menu panel.
     */
    children?: ReactNode;
}
export declare const MegaMenuPanel: import("react").ForwardRefExoticComponent<MegaMenuPanelProps & import("react").RefAttributes<HTMLDivElement>>;

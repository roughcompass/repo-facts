/**
 * Resolves the panel's page-margin token to pixels for floating-ui padding, to
 * handle token (`--saltMegaMenuPanel-pageMargin`) override by consumers
 * (edge to edge example).
 */
export declare function usePageMargin(referenceEl: HTMLElement | null | undefined): number;

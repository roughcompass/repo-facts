import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MegaMenuAsideProps extends ComponentPropsWithoutRef<"aside"> {
    /**
     * The content. Renders to the left of `MegaMenuContent` when placed before
     * it, and to the right when placed after.
     */
    children?: ReactNode;
}
export declare const MegaMenuAside: import("react").ForwardRefExoticComponent<MegaMenuAsideProps & import("react").RefAttributes<HTMLElement>>;

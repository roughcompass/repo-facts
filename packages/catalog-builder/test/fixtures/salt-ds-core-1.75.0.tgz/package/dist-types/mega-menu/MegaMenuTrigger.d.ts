import { type ReactNode } from "react";
export interface MegaMenuTriggerProps {
    /**
     * The trigger element for the mega menu, typically a `NavigationItem` or `Button`.
     * Wrap each mega menu in its own `<li>` — arrow-key navigation between triggers depends on it.
     */
    children?: ReactNode;
}
export declare const MegaMenuTrigger: import("react").ForwardRefExoticComponent<MegaMenuTriggerProps & import("react").RefAttributes<HTMLElement>>;

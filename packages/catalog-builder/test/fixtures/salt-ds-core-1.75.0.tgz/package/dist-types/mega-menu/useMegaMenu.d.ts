import { type MegaMenuContextValue } from "./MegaMenuContext";
/**
 * Access the nearest MegaMenu context.
 * Must be used within a `MegaMenu` provider.
 */
export declare function useMegaMenu(): MegaMenuContextValue;

import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MegaMenuGroupProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of the mega menu group: a `MegaMenuGroupHeading` and a
     * `MegaMenuList` of `MegaMenuListItem`s.
     */
    children?: ReactNode;
}
export declare const MegaMenuGroup: import("react").ForwardRefExoticComponent<MegaMenuGroupProps & import("react").RefAttributes<HTMLDivElement>>;

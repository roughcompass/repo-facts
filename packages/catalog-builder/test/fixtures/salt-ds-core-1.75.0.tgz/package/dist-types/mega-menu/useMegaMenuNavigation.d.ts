import type { ElementProps, FloatingRootContext } from "@floating-ui/react";
export declare const FOCUSABLE_SELECTOR = "a[href], button:not([disabled]), [tabindex]:not([tabindex=\"-1\"])";
export interface UseMegaMenuNavigationProps {
    /**
     * Whether the interaction is enabled.
     * @default true
     */
    enabled?: boolean;
}
/**
 * Floating-ui interaction hook for mega menu keyboard navigation. Handles keys
 * on the panel only; the trigger keys are owned by `MegaMenuTrigger`.
 */
export declare function useMegaMenuNavigation(context: FloatingRootContext, props?: UseMegaMenuNavigationProps): ElementProps;
/** Focus the first navigable item inside a mega menu panel, retrying until rendered. */
export declare function focusFirstItem(panel: HTMLElement, attempt?: number): void;

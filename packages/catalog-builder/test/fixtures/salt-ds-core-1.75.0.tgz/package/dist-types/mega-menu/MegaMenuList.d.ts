import { type ElementType, type FunctionComponent, type ReactNode } from "react";
import { type PolymorphicComponentPropWithRef } from "../utils";
export type MegaMenuListProps<T extends ElementType = "ul"> = PolymorphicComponentPropWithRef<T, {
    /**
     * The items of the group, typically `MegaMenuListItem` components. Each
     * `MegaMenuListItem` renders its own `<li>`.
     */
    children?: ReactNode;
}>;
type MegaMenuListComponent = <T extends ElementType = "ul">(props: MegaMenuListProps<T>) => ReturnType<FunctionComponent>;
/**
 * The list of a group's `MegaMenuListItem`s. Renders a `<ul>` by default; pass
 * `as="ol"` for an ordered list.
 */
export declare const MegaMenuList: MegaMenuListComponent;
export {};

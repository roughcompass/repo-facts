import { type ReactNode } from "react";
/**
 * Supported placements for the mega menu panel.
 */
export type MegaMenuPlacement = "bottom" | "bottom-start" | "bottom-end";
export interface MegaMenuProps {
    /**
     * The content of the mega menu, typically `MegaMenuTrigger` and `MegaMenuPanel`.
     */
    children?: ReactNode;
    /**
     * Whether the mega menu is open. Use for controlled mode.
     */
    open?: boolean;
    /**
     * Whether the mega menu is initially open. Use for uncontrolled mode.
     * @default false
     */
    defaultOpen?: boolean;
    /**
     * Callback fired when the open state changes.
     */
    onOpenChange?: (open: boolean) => void;
    /**
     * The placement of the mega menu panel relative to the trigger.
     * @default "bottom"
     */
    placement?: MegaMenuPlacement;
}
/**
 * Root of a mega menu, coordinating its trigger and panel.
 *
 * Not intended to be nested inside another floating overlay (e.g. a dialog or
 * popover): the mega menu does not participate in floating-ui's `FloatingTree`
 */
export declare function MegaMenu({ children, open, defaultOpen, onOpenChange, placement, }: MegaMenuProps): import("react").JSX.Element;

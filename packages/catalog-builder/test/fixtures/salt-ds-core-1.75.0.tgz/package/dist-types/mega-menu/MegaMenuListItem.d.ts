import { type ComponentPropsWithoutRef, type MouseEventHandler, type ReactNode } from "react";
import { type RenderPropsType } from "../utils";
export interface MegaMenuListItemProps extends Omit<ComponentPropsWithoutRef<"li">, "onClick"> {
    /**
     * The content of the mega menu item.
     */
    children?: ReactNode;
    /**
     * Whether the item is the current page. Sets `aria-current="page"`
     */
    current?: boolean;
    /**
     * Href passed to the link action element.
     */
    href?: string;
    /**
     * Called when the item's action is activated, before the menu closes.
     */
    onClick?: MouseEventHandler<HTMLAnchorElement>;
    /**
     * Render prop to enable customization of the underlying action element (e.g. a router `Link`).
     */
    render?: RenderPropsType["render"];
}
export declare const MegaMenuListItem: import("react").ForwardRefExoticComponent<MegaMenuListItemProps & import("react").RefAttributes<HTMLLIElement>>;

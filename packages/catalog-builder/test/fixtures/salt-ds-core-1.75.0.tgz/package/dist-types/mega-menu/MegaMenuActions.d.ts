import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MegaMenuActionsProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of the actions. Place `MegaMenuActions` inside
     * `MegaMenuContent`, after `MegaMenuGroups`; it renders as a band beneath the
     * groups, spanning their width.
     */
    children?: ReactNode;
}
export declare const MegaMenuActions: import("react").ForwardRefExoticComponent<MegaMenuActionsProps & import("react").RefAttributes<HTMLDivElement>>;

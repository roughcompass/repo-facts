export declare const CornerValues: readonly ["sharp", "rounded"];
/** @deprecated since 1.32.0. Use `CornerValues`. */
export declare const UNSTABLE_CornerValues: readonly ["sharp", "rounded"];
export type Corner = (typeof CornerValues)[number];
/** @deprecated since 1.32.0. Use `Corner`. */
export type UNSTABLE_Corner = Corner;

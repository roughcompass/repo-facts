export declare const DensityValues: readonly ["high", "medium", "low", "touch", "mobile"];
export type Density = (typeof DensityValues)[number];

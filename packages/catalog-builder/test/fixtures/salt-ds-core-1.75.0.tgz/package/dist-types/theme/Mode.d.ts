export declare const ModeValues: readonly ["light", "dark"];
export type Mode = (typeof ModeValues)[number];

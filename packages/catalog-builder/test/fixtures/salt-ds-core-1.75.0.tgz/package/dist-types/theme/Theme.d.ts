export type characteristic = "accent" | "actionable" | "container" | "draggable" | "editable" | "focused" | "measured" | "navigable" | "overlayable" | "selectable" | "separable" | "status" | "taggable" | "target" | "text" | "differential";
export type ThemeName = string;
export declare const getCharacteristicValue: (themeName: ThemeName, characteristicName: characteristic, variant: string, scopeElement?: HTMLElement) => string | null;

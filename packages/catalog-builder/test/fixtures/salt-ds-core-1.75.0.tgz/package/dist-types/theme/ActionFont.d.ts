export declare const ActionFontValues: readonly ["Open Sans", "Amplitude"];
/** @deprecated since 1.32.0. Use `ActionFontValues`. */
export declare const UNSTABLE_ActionFontValues: readonly ["Open Sans", "Amplitude"];
export type ActionFont = (typeof ActionFontValues)[number];
/** @deprecated since 1.32.0. Use `ActionFont`. */
export type UNSTABLE_ActionFont = ActionFont;

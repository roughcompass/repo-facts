export declare const AccentValues: readonly ["blue", "teal"];
/** @deprecated since 1.32.0. Use `AccentValues`. */
export declare const UNSTABLE_AccentValues: readonly ["blue", "teal"];
export type Accent = (typeof AccentValues)[number];
/** @deprecated since 1.32.0. Use `Accent`. */
export type UNSTABLE_Accent = Accent;

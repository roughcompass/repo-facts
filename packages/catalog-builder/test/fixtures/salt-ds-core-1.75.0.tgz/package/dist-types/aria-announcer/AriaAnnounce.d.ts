import { type ComponentType } from "react";
import type { AnnounceFnOptions } from "./AriaAnnouncerContext";
export interface AriaAnnounceProps extends AnnounceFnOptions {
    /**
     * String to be announced by screenreader.
     */
    announcement?: string;
    /**
     * Legacy option, precede the announcement with a delay.
     * @deprecated
     * useAriaAnnouncer `delay` arg is deprecated, use your own `setTimeout` or consider using `duration` through `AnnounceFnOptions` instead.
     */
    delay?: number;
}
export declare const AriaAnnounce: ComponentType<AriaAnnounceProps>;

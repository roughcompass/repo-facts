import { type AriaAnnouncer } from "./AriaAnnouncerContext";
export type useAnnouncerOptions = {
    debounce?: number;
};
export type useAriaAnnouncerHook = (options?: useAnnouncerOptions) => AriaAnnouncer;
export declare const useAriaAnnouncer: useAriaAnnouncerHook;

import type { AnnounceFnOptions } from "./AriaAnnouncerContext";
type Announcer = (announcement: string, options?: AnnounceFnOptions) => void;
export declare function registerAnnouncementTarget(target: string, announce: Announcer): () => void;
export declare function getAnnouncementTarget(target: string): Announcer | undefined;
export {};

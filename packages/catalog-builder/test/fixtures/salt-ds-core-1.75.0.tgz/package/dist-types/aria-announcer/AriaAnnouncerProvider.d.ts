import { type ComponentPropsWithRef } from "react";
export declare const ANNOUNCEMENT_TIME_IN_DOM = 300;
export interface AriaAnnouncerProviderProps extends ComponentPropsWithRef<"div"> {
    /**
     * Optional target key used to route announcements to this provider.
     */
    target?: string;
}
export declare const AriaAnnouncerProvider: import("react").ForwardRefExoticComponent<Omit<AriaAnnouncerProviderProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;

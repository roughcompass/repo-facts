import { type ComponentPropsWithoutRef } from "react";
interface SkipLinkProps extends ComponentPropsWithoutRef<"a"> {
    /**
     * The ID of the target element to apply focus when the link is clicked.
     * If the element with this ID is not found, the SkipLink will not be rendered.
     */
    targetId: string;
}
export declare const SkipLink: import("react").ForwardRefExoticComponent<SkipLinkProps & import("react").RefAttributes<HTMLAnchorElement>>;
export {};

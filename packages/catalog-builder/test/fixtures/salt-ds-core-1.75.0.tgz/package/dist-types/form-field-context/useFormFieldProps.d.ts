import { type FormFieldContextValue } from "./FormFieldContext";
export declare function useFormFieldProps(): Partial<FormFieldContextValue>;

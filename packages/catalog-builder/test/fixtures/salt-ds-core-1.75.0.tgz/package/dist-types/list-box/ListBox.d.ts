import { type ComponentPropsWithoutRef, type ReactElement, type ReactNode, type Ref } from "react";
import { type ListControlProps } from "../list-control/ListControlState";
export type ListBoxProps<Item = string> = {
    /**
     * If `true`, the list box will be disabled.
     */
    disabled?: boolean;
    /**
     * If `false`, the list box will have not a border.
     */
    bordered?: boolean;
    /**
     * The options to display in the list box.
     */
    children?: ReactNode;
    /**
     * If `true`, the list box will be multiselect.
     */
    multiselect?: boolean;
} & ComponentPropsWithoutRef<"div"> & Omit<ListControlProps<Item>, "onOpenChange">;
export declare const ListBox: <Item = string>(props: ListBoxProps<Item> & {
    ref?: Ref<HTMLDivElement>;
}) => ReactElement;

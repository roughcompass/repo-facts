import { type ComponentPropsWithoutRef, type ReactNode } from "react";
import type { ButtonProps } from "../button";
export interface StepProps extends Omit<ComponentPropsWithoutRef<"li">, "onToggle"> {
    /**
     * The label of the step
     */
    label?: ReactNode;
    /**
     * Description text is displayed just below the label
     **/
    description?: ReactNode;
    /**
     * Optional string to determine the status of the step.
     */
    status?: StepStatus;
    /**
     * The stage of the step
     */
    stage?: StepStage;
    /**
     * Whether the step item is expanded.
     */
    expanded?: boolean;
    /**
     * Initial expanded state of the step.
     */
    defaultExpanded?: boolean;
    /**
     * Callback fired when the step is toggled.
     */
    onToggle?: ButtonProps["onClick"];
}
export type StepId = string;
export type StepStatus = "warning" | "error";
export type StepStage = "pending" | "locked" | "completed" | "inprogress" | "active";
export type StepDepth = number;
export interface StepProps extends Omit<ComponentPropsWithoutRef<"li">, "onToggle"> {
    label?: ReactNode;
    description?: ReactNode;
    status?: StepStatus;
    stage?: StepStage;
    expanded?: boolean;
    defaultExpanded?: boolean;
    onToggle?: ButtonProps["onClick"];
}
export declare const Step: import("react").ForwardRefExoticComponent<StepProps & import("react").RefAttributes<HTMLLIElement>>;

import { type ButtonProps } from "../../button";
export interface StepExpandTriggerProps extends ButtonProps {
    expanded: boolean;
}
export declare function StepExpandTrigger({ id, expanded, className, ...props }: StepExpandTriggerProps): import("react").JSX.Element;

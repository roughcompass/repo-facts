export declare function StepConnector(): import("react").JSX.Element;

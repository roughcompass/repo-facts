import { type ReactNode } from "react";
export declare function hasActiveStep(children: ReactNode): boolean;

import { type ComponentPropsWithoutRef } from "react";
export type StepperOrientation = "horizontal" | "vertical";
export interface StepperProps extends ComponentPropsWithoutRef<"ol"> {
    /**
     * The orientation of the stepper: defaults to horizontal.
     */
    orientation?: StepperOrientation;
}
export declare const Stepper: import("react").ForwardRefExoticComponent<StepperProps & import("react").RefAttributes<HTMLOListElement>>;

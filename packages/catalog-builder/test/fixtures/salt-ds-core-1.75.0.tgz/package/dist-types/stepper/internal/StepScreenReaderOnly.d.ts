import type { ComponentPropsWithoutRef, ReactNode } from "react";
export interface StepScreenReaderOnlyProps extends ComponentPropsWithoutRef<"div"> {
    children?: ReactNode;
}
export declare function StepScreenReaderOnly({ children, ...props }: StepScreenReaderOnlyProps): import("react").JSX.Element;

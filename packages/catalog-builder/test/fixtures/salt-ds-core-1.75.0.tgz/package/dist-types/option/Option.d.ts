import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface OptionProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * If `true`, the option will be disabled.
     */
    disabled?: boolean;
    /**
     * The value of the option.
     */
    value: unknown;
    /**
     * The content of the option.
     */
    children?: ReactNode;
}
declare const OptionComponent: import("react").ForwardRefExoticComponent<OptionProps & import("react").RefAttributes<HTMLDivElement>>;
export declare const Option: typeof OptionComponent;
export {};

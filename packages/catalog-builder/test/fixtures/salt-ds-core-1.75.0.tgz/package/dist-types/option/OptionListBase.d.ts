import { type ComponentPropsWithoutRef } from "react";
export interface OptionListBaseProps extends ComponentPropsWithoutRef<"div"> {
}
export declare const OptionListBase: import("react").ForwardRefExoticComponent<OptionListBaseProps & import("react").RefAttributes<HTMLDivElement>>;

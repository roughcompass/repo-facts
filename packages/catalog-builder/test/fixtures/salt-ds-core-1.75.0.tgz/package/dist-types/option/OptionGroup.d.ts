import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface OptionGroupProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The label of the option group.
     */
    label?: string;
    /**
     * Options to be rendered inside the option group.
     */
    children?: ReactNode;
}
export declare const OptionGroup: import("react").ForwardRefExoticComponent<OptionGroupProps & import("react").RefAttributes<HTMLDivElement>>;

import { type FloatingComponentProps } from "../utils";
export interface OptionListProps extends FloatingComponentProps {
    collapsed?: boolean;
}
export declare const OptionList: import("react").ForwardRefExoticComponent<OptionListProps & import("react").RefAttributes<HTMLDivElement>>;

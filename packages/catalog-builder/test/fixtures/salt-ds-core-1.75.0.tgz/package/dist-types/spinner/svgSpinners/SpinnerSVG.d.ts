import type { ComponentPropsWithoutRef } from "react";
type SpinnerSVGProps = ComponentPropsWithoutRef<"svg">;
/**
 * Draws the spinner as two overlapping circles. Each circle is half-stroked
 * (`stroke-dasharray="50 50"` against a normalised `pathLength` of 100) and
 * rotated via `stroke-dashoffset`: the first draws the top half, the second
 * draws the left half with a fading gradient. Radius and stroke width come
 * from CSS custom properties set by the parent `.saltSpinner-*` size class.
 */
export declare const SpinnerSVG: ({ id, ...rest }: SpinnerSVGProps) => import("react").JSX.Element;
export {};

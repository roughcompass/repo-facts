import { type HTMLAttributes } from "react";
/**
 * Spinner component, provides an indeterminate loading indicator
 *
 * @example
 * <Spinner size="small" | "medium" | "large" />
 */
export declare const SpinnerSizeValues: readonly ["default", "large", "small", "medium"];
type SpinnerSize = (typeof SpinnerSizeValues)[number];
export type SpinnerSVGSize = Exclude<SpinnerSize, "default">;
export interface SpinnerProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Determines the interval on which the component will continue to announce the aria-label. Defaults to 5000ms (5s)
     */
    announcerInterval?: number;
    /**
     *  * Determines the interval after which the component will stop announcing the aria-label. Defaults to 20000ms (20s)
     */
    announcerTimeout?: number;
    /**
     * The className(s) of the component
     */
    className?: string;
    /**
     * Determines the message to be announced by the component when it unmounts. Set to null if not needed.
     */
    completionAnnouncement?: string | null;
    /**
     * If true, built in aria announcer will be inactive
     */
    disableAnnouncer?: boolean;
    /**
     * The prop for the role attribute of the component
     */
    role?: string;
    /**
     * Determines the size of the spinner. Must be one of: 'default', 'large', 'small', 'medium'.
     */
    size?: SpinnerSize;
    /**
     * The ids of the SvgSpinner components
     */
    id?: string;
}
export declare const Spinner: import("react").ForwardRefExoticComponent<SpinnerProps & import("react").RefAttributes<HTMLDivElement>>;
export {};

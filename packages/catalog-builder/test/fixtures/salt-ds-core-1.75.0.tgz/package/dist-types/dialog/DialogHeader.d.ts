import { type ComponentPropsWithoutRef, type ReactNode } from "react";
import { type ValidationStatus } from "../status-indicator";
export interface DialogHeaderProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The status of the Dialog
     */
    status?: ValidationStatus | undefined;
    /**
     * Displays the accent bar in the Dialog Title */
    disableAccent?: boolean;
    /**
     * Displays the header at the top of the Dialog
     */
    header: ReactNode;
    /**
     * Displays the preheader just above the header
     **/
    preheader?: ReactNode;
    /**
     * Description text is displayed just below the header
     **/
    description?: ReactNode;
    /**
     * Actions to be displayed in header
     */
    actions?: ReactNode;
}
export declare const DialogHeader: import("react").ForwardRefExoticComponent<DialogHeaderProps & import("react").RefAttributes<HTMLDivElement>>;

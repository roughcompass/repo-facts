import type { ValidationStatus } from "../status-indicator";
export interface DialogContextValue {
    status?: ValidationStatus;
    id?: string;
    setId?: (id: string) => void;
    dialogId?: string;
    setDialogId?: (id: string) => void;
}
export declare const DialogContext: import("react").Context<DialogContextValue>;
export declare const useDialogContext: () => DialogContextValue;

import { type HTMLAttributes, type ReactNode } from "react";
export interface DialogContentProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * The content of Dialog Content
     */
    children?: ReactNode;
}
export declare const DialogContent: import("react").ForwardRefExoticComponent<DialogContentProps & import("react").RefAttributes<HTMLDivElement>>;

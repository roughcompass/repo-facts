import { type HTMLAttributes, type ReactNode } from "react";
export interface DialogActionsProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * The content of Dialog Actions
     */
    children?: ReactNode;
}
export declare const DialogActions: import("react").ForwardRefExoticComponent<DialogActionsProps & import("react").RefAttributes<HTMLDivElement>>;

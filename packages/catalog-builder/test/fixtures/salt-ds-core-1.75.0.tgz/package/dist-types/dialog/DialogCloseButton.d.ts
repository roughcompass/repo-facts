import { type ButtonProps } from "../button";
export declare const DialogCloseButton: import("react").ForwardRefExoticComponent<ButtonProps & import("react").RefAttributes<HTMLButtonElement>>;

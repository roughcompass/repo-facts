import { type IconProps } from "@salt-ds/icons";
import type { ValidationStatus } from "./ValidationStatus";
export interface StatusIndicatorProps extends IconProps {
    /**
     * Status indicator to be displayed.
     */
    status: ValidationStatus;
}
export declare const StatusIndicator: import("react").ForwardRefExoticComponent<StatusIndicatorProps & import("react").RefAttributes<SVGSVGElement>>;

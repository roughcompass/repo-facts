export interface ValidationStatuses {
    error: string;
    warning: string;
    success: string;
    info: string;
}
export type ValidationStatus = keyof ValidationStatuses;
/**
 * @deprecated since 1.55.0. Use `ValidationStatusValues`.
 */
export declare const VALIDATION_NAMED_STATUS: readonly ["error", "warning", "success", "info"];

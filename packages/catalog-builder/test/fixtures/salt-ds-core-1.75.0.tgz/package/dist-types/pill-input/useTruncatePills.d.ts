export declare function useTruncatePills({ pills, enable, }: {
    pills: string[];
    enable?: boolean;
}): {
    pillListRef: import("react").RefObject<HTMLDivElement>;
    visibleCount: number;
    visiblePills: string[];
};

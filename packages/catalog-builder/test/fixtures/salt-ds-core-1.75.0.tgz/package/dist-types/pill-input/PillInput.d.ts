import { type ComponentPropsWithoutRef, type InputHTMLAttributes, type ReactNode, type Ref, type SyntheticEvent } from "react";
import { type FormFieldValidationStatus } from "../form-field-context";
import type { DataAttributes } from "../types";
export interface PillInputProps extends Omit<ComponentPropsWithoutRef<"div">, "defaultValue">, Pick<ComponentPropsWithoutRef<"input">, "disabled" | "value" | "defaultValue" | "placeholder"> {
    /**
     * The marker to use in an empty read only Input.
     * Use `''` to disable this feature. Defaults to '—'.
     */
    emptyReadOnlyMarker?: string;
    /**
     * End adornment component
     */
    endAdornment?: ReactNode;
    /**
     * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Attributes) applied to the `input` element.
     */
    inputProps?: Partial<InputHTMLAttributes<HTMLInputElement>> & DataAttributes;
    /**
     * Optional ref for the input component
     */
    inputRef?: Ref<HTMLInputElement>;
    /**
     * The name applied to the input.
     */
    name?: string;
    /**
     * If `true`, the component is read only.
     */
    readOnly?: boolean;
    /**
     * The tokens to display in the input.
     */
    pills?: string[];
    onPillRemove?: (event: SyntheticEvent, index: number) => void;
    /**
     * Start adornment component
     */
    startAdornment?: ReactNode;
    /**
     * Alignment of text within container. Defaults to "left"
     */
    textAlign?: "left" | "center" | "right";
    /**
     * Validation status.
     */
    validationStatus?: FormFieldValidationStatus;
    /**
     * Styling variant. Defaults to "primary".
     */
    variant?: "primary" | "secondary" | "tertiary";
    hidePillClose?: boolean;
    truncate?: boolean;
    /** Styling variant with full border. Defaults to false
     */
    bordered?: boolean;
}
export declare const PillInput: import("react").ForwardRefExoticComponent<PillInputProps & import("react").RefAttributes<HTMLDivElement>>;

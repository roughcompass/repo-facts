/**
 * The leading slots that items in one alignment scope reserve for each other.
 * Each `MenuGroup` is a scope, and items outside a group share their `MenuPanel`'s scope.
 */
export interface MenuAlignmentContextValue {
    reserveIconSpace: boolean;
    reserveSelectionIconSpace: boolean;
    registerIcon: () => () => void;
    registerSelectionIcon: () => () => void;
}
export declare const MenuAlignmentContext: import("react").Context<MenuAlignmentContextValue>;
export declare function useSlotRegistry(): readonly [boolean, () => () => void];
export declare function useMenuAlignmentScope(): MenuAlignmentContextValue;
export declare function useMenuAlignment(): MenuAlignmentContextValue;

import { type ComponentPropsWithoutRef, type ReactNode, type SyntheticEvent } from "react";
interface BaseMenuGroupProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Menus to be rendered inside the menu group.
     */
    children?: ReactNode;
    /**
     * The label of the menu group.
     */
    label?: string;
    /**
     * Selection variant of the menu group. If "single", the menu items inside behave like radio buttons. If "multiple", they behave like checkboxes. Each selectable menu item needs a `value`. When omitted, the menu items are not selectable.
     */
    selectionVariant?: "single" | "multiple";
}
interface SelectableMenuGroupProps extends BaseMenuGroupProps {
    /**
     * Callback fired when the selection changes.
     * @param event
     * @param newSelected The new selected values.
     */
    onSelectionChange?: (event: SyntheticEvent, newSelected: string[]) => void;
    /**
     * The values of the selected menu items. Required when `selectionVariant` is "single" or "multiple". The menu's content unmounts when it closes, so keep the selection in state and update it in `onSelectionChange`.
     */
    selected: string[];
    selectionVariant: "single" | "multiple";
}
interface NonSelectableMenuGroupProps extends BaseMenuGroupProps {
    selectionVariant?: undefined;
}
export type MenuGroupProps = SelectableMenuGroupProps | NonSelectableMenuGroupProps;
export declare const MenuGroup: import("react").ForwardRefExoticComponent<MenuGroupProps & import("react").RefAttributes<HTMLDivElement>>;
export {};

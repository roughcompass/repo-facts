import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MenuPanelProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The content of the menu panel.
     */
    children?: ReactNode;
}
export declare const MenuPanel: import("react").ForwardRefExoticComponent<MenuPanelProps & import("react").RefAttributes<HTMLDivElement>>;

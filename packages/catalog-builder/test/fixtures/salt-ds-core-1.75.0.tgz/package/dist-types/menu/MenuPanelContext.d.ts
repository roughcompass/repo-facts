import type { MenuContextValue } from "./MenuContext";
export interface MenuPanelContextValue extends Pick<MenuContextValue, "getItemProps" | "activeIndex" | "setFocusInside"> {
    hasSelectionIcon: boolean;
    registerPanelSelectionIcon: () => () => void;
}
export declare const MenuPanelContext: import("react").Context<MenuPanelContextValue>;
export declare function useMenuPanelContext(): MenuPanelContextValue;

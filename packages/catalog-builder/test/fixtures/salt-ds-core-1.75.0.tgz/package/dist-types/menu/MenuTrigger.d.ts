import { type ReactNode } from "react";
export interface MenuTriggerProps {
    /**
     * The trigger element for the menu. This should be a single child element and accept a ref.
     */
    children?: ReactNode;
}
export declare const MenuTrigger: import("react").ForwardRefExoticComponent<MenuTriggerProps & import("react").RefAttributes<HTMLElement>>;

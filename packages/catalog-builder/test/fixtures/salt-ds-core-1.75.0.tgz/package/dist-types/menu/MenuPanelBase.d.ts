import { type ComponentPropsWithoutRef } from "react";
export interface MenuPanelBaseProps extends ComponentPropsWithoutRef<"div"> {
}
export declare const MenuPanelBase: import("react").ForwardRefExoticComponent<MenuPanelBaseProps & import("react").RefAttributes<HTMLDivElement>>;

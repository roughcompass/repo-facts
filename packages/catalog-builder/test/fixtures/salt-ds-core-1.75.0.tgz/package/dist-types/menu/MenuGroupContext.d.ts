import { type SyntheticEvent } from "react";
import type { MenuGroupProps } from "./MenuGroup";
export interface MenuGroupContextValue {
    isSelected: (value: string) => boolean;
    select: (event: SyntheticEvent, value: string) => void;
    selectionVariant?: MenuGroupProps["selectionVariant"];
}
export declare const defaultMenuGroupContextValue: MenuGroupContextValue;
export declare const MenuGroupContext: import("react").Context<MenuGroupContextValue>;
export declare function useMenuGroup(): MenuGroupContextValue;

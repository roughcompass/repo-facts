import type { useInteractions } from "@floating-ui/react";
import { type Dispatch, type MutableRefObject, type SetStateAction } from "react";
import { type UseFloatingUIReturn } from "../utils";
type UseInteractionsReturn = ReturnType<typeof useInteractions>;
export interface MenuContextValue extends Pick<UseInteractionsReturn, "getItemProps" | "getReferenceProps" | "getFloatingProps">, Partial<Pick<UseFloatingUIReturn, "context" | "refs">> {
    openState: boolean;
    activeIndex: number | null;
    getPanelPosition: () => Record<string, unknown>;
    elementsRef: MutableRefObject<(HTMLDivElement | null)[]>;
    focusInside: boolean;
    setFocusInside: Dispatch<SetStateAction<boolean>>;
    isNested: boolean;
    triggerDisabled: boolean;
    setTriggerDisabled: (disabled: boolean) => void;
}
export declare const MenuContext: import("react").Context<MenuContextValue>;
export declare function useMenuContext(): MenuContextValue;
export {};

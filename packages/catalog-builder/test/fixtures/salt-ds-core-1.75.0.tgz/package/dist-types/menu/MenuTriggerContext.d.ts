export interface MenuTriggerContextValue {
    triggersSubmenu: boolean;
    blurActive: boolean;
}
export declare const MenuTriggerContext: import("react").Context<MenuTriggerContextValue>;
export declare function useIsMenuTrigger(): MenuTriggerContextValue;

import { type ComponentPropsWithoutRef } from "react";
export interface MenuItemProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * If `true`, the item will be disabled.
     */
    disabled?: boolean;
    /**
     * The value of the item. Identifies the item inside a `MenuGroup` whose `selectionVariant` is "single" or "multiple".
     */
    value?: string;
}
export declare const MenuItem: import("react").ForwardRefExoticComponent<MenuItemProps & import("react").RefAttributes<HTMLDivElement>>;

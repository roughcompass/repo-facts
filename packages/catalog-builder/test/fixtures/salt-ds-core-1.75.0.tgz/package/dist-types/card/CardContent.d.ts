import { type ComponentPropsWithoutRef } from "react";
export interface CardContentProps extends ComponentPropsWithoutRef<"div"> {
}
export declare const CardContent: import("react").ForwardRefExoticComponent<CardContentProps & import("react").RefAttributes<HTMLDivElement>>;

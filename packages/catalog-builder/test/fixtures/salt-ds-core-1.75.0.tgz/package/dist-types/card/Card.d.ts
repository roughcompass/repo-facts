import { type ComponentPropsWithoutRef } from "react";
export interface CardProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * If provided an accent is shown in the specified position.
     */
    accent?: "bottom" | "top" | "left" | "right";
    /**
     * Visual elevation.
     */
    elevation?: "flat" | "raised";
    /**
     * Border color strength.
     */
    borderColor?: "strong" | "subtle" | "none";
    /**
     * **Deprecated:** Use the InteractableCard component instead
     *
     * If `true`, the card will be disabled.
     */
    disabled?: boolean;
    /**
     * @deprecated since 1.71.0. Use `LinkCard` or `InteractableCard` when the entire card is interactive.
     *
     * If `true` the card will have hover styling.
     */
    hoverable?: boolean;
    /**
     * **Deprecated:** Use the InteractableCard component instead
     *
     * If `true`, interactive styles will be applied to `Card`. These styles give prominence to certain content
     * on the page.
     */
    interactable?: boolean;
    /**
     * Styling variant. Defaults to "primary".
     */
    variant?: "primary" | "secondary" | "tertiary" | "ghost";
}
export declare const Card: import("react").ForwardRefExoticComponent<CardProps & import("react").RefAttributes<HTMLDivElement>>;

import { type ComponentPropsWithoutRef } from "react";
export interface CardFooterProps extends ComponentPropsWithoutRef<"div"> {
}
export declare const CardFooter: import("react").ForwardRefExoticComponent<CardFooterProps & import("react").RefAttributes<HTMLDivElement>>;

import { type ComponentPropsWithoutRef } from "react";
export interface CardHeaderProps extends ComponentPropsWithoutRef<"div"> {
}
export declare const CardHeader: import("react").ForwardRefExoticComponent<CardHeaderProps & import("react").RefAttributes<HTMLDivElement>>;

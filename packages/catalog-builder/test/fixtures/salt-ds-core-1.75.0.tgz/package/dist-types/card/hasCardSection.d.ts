import { type ReactNode } from "react";
export declare function hasCardSection(children: ReactNode): boolean;

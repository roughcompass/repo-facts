import { type ComponentPropsWithoutRef } from "react";
export interface CircularProgressProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The value of the buffer indicator.
     * Value between 0 and max.
     */
    bufferValue?: number;
    /**
     * Whether to hide the text label within the progress. Defaults to `false`.
     */
    hideLabel?: boolean;
    /**
     * The value of the max progress indicator.
     * Default value is 100.
     */
    max?: number;
    /**
     * The value of the min progress indicator.
     * Default value is 0.
     */
    min?: number;
    /**
     * The value of the progress indicator.
     * Value between 0 and max.
     */
    value?: number;
}
export declare const CircularProgress: import("react").ForwardRefExoticComponent<CircularProgressProps & import("react").RefAttributes<HTMLDivElement>>;

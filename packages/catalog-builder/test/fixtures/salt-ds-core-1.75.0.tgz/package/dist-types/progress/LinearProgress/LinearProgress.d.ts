import { type ComponentPropsWithoutRef } from "react";
export interface LinearProgressProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The value of the buffer indicator.
     * Value between `min` and `max`.
     * When no `value` and `bufferValue` is passed in, show as indeterminate state.
     */
    bufferValue?: number;
    /**
     * Whether to hide the text label within the progress. Defaults to `false`.
     */
    hideLabel?: boolean;
    /**
     * The value of the max progress indicator.
     * Default value is 100.
     */
    max?: number;
    /**
     * The value of the min progress indicator.
     * Default value is 0.
     */
    min?: number;
    /**
     * The value of the progress indicator.
     * Value between `min` and `max`.
     * When no `value` and `bufferValue` is passed in, show as indeterminate state.
     */
    value?: number;
}
export declare const LinearProgress: import("react").ForwardRefExoticComponent<LinearProgressProps & import("react").RefAttributes<HTMLDivElement>>;

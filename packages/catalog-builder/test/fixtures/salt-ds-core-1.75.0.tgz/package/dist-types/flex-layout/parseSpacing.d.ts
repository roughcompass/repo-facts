export declare function parseSpacing(value: number | string | undefined): string | undefined;

import { type ElementType, type FunctionComponent } from "react";
import { type PolymorphicComponentPropWithRef, type ResponsiveProp } from "../utils";
export type LayoutSeparator = "start" | "center" | "end";
export type LayoutDirection = "row" | "column" | "row-reverse" | "column-reverse";
export declare const FLEX_ALIGNMENT_BASE: readonly ["start", "end", "center"];
export declare const FLEX_CONTENT_ALIGNMENT_BASE: readonly ["start", "end", "center", "space-between", "space-around", "space-evenly"];
export type FlexAlignment = (typeof FLEX_ALIGNMENT_BASE)[number];
export type FlexContentAlignment = (typeof FLEX_CONTENT_ALIGNMENT_BASE)[number];
export type FlexLayoutProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Defines the default behavior for how flex items are laid out along the cross axis on the current line, default is "stretch".
     */
    align?: FlexAlignment | "stretch" | "baseline";
    /**
     * Establishes the main-axis, defining the direction children are placed. Default is "row".
     */
    direction?: ResponsiveProp<LayoutDirection>;
    /**
     * Controls the space between items, default is 3.
     */
    gap?: ResponsiveProp<number | string>;
    /**
     * Defines the alignment along the main axis, default is "start".
     */
    justify?: FlexContentAlignment;
    /**
     * **Deprecated:** For separators see `StackLayout` component instead.
     *
     * Adds a separator between elements if wrap is not active, default is false.
     */
    separators?: LayoutSeparator | true;
    /**
     * Allow the items to wrap as needed, default is false.
     */
    wrap?: ResponsiveProp<boolean>;
    /**
     * Defines the margin around the component. It can be specified as a number (which acts as a multiplier) or a string representing the margin value. Default is `0`.
     */
    margin?: ResponsiveProp<number | string>;
    /**
     * Defines the padding within the component. It can be specified as a number (which acts as a multiplier) or a string representing the padding value. Default is `0`.
     */
    padding?: ResponsiveProp<number | string>;
}>;
type FlexLayoutComponent = <T extends ElementType = "div">(props: FlexLayoutProps<T>) => ReturnType<FunctionComponent>;
export declare const FlexLayout: FlexLayoutComponent;
export {};

import { type ComponentPropsWithoutRef } from "react";
export interface ScrimProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * If `true` the scrim is bound to the document viewport.
     * The default value of this prop is false, and the default behavior is for Scrim to be bound to its parent container (nearest positioned ancestor).
     */
    fixed?: boolean;
    /**
     * If `true` the scrim is shown.
     */
    open?: boolean;
}
export declare const Scrim: import("react").ForwardRefExoticComponent<ScrimProps & import("react").RefAttributes<HTMLDivElement>>;

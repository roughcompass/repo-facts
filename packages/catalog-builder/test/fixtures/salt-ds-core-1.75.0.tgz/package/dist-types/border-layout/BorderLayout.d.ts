import { type ElementType, type FunctionComponent, type ReactNode } from "react";
import { type GridLayoutProps } from "../grid-layout";
import { type PolymorphicComponentPropWithRef, type ResponsiveProp } from "../utils";
export type BorderLayoutProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Defines the size of the gutter between the columns and the rows by setting a density multiplier. Defaults to 0
     */
    gap?: GridLayoutProps<T>["gap"];
    /**
     * Defines the size of the gutter between the columns by setting a density multiplier. Defaults to 0
     */
    columnGap?: GridLayoutProps<T>["columnGap"];
    /**
     * Defines the size of the gutter between the rows by setting a density multiplier. Defaults to 0
     */
    rowGap?: GridLayoutProps<T>["rowGap"];
    /**
     * Border item components to be rendered.
     */
    children: ReactNode;
    /**
     * Defines the margin around the component. It can be specified as a number (which acts as a multiplier) or a string representing the margin value. Default is `0`.
     */
    margin?: ResponsiveProp<number | string>;
    /**
     * Defines the padding within the component. It can be specified as a number (which acts as a multiplier) or a string representing the padding value. Default is `0`.
     */
    padding?: ResponsiveProp<number | string>;
}>;
type BorderLayoutComponent = <T extends ElementType = "div">(props: BorderLayoutProps<T>) => ReturnType<FunctionComponent>;
export declare const BorderLayout: BorderLayoutComponent;
export {};

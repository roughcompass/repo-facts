import type { ComponentPropsWithoutRef, SyntheticEvent } from "react";
import type { OptionValue } from "../list-control/ListControlContext";
import { type ListControlProps } from "../list-control/ListControlState";
export type UseComboBoxProps<Item> = ListControlProps<Item> & Pick<ComponentPropsWithoutRef<"input">, "value" | "defaultValue">;
export declare function useComboBox<Item>(props: UseComboBoxProps<Item>): {
    select: (event: SyntheticEvent, option: OptionValue<Item>) => void;
    valueState: string | number | readonly string[] | undefined;
    setValueState: import("react").Dispatch<import("react").SetStateAction<string | number | readonly string[] | undefined>>;
    removePill: (event: SyntheticEvent, itemToRemove: Item) => void;
    multiselect: boolean;
    openState: boolean;
    setOpen: (newOpen: boolean, reason?: import("../list-control/ListControlState").OpenChangeReason, key?: string) => void;
    openKey: import("react").MutableRefObject<string | undefined>;
    activeState: OptionValue<Item> | undefined;
    setActive: import("react").Dispatch<import("react").SetStateAction<OptionValue<Item> | undefined>>;
    selectedState: Item[];
    setSelectedState: import("react").Dispatch<import("react").SetStateAction<Item[]>>;
    clear: (event: SyntheticEvent) => void;
    focusVisibleState: boolean;
    setFocusVisibleState: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    focusedState: boolean;
    setFocusedState: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    setListRef: import("react").Ref<HTMLDivElement>;
    listRef: import("react").RefObject<HTMLDivElement>;
    register: (optionValue: OptionValue<Item>, element: HTMLElement) => () => void;
    getOptionAtIndex: (index: number) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getIndexOfOption: (option: OptionValue<Item>) => number;
    getOptionsMatching: (predicate: (option: OptionValue<Item>) => boolean) => import("../list-control/ListControlRegistry").RegisteredOption<Item>[];
    getOptionFromSearch: (search: string, startFrom?: OptionValue<Item> | undefined) => OptionValue<Item> | undefined;
    getOptionAfter: (option: OptionValue<Item>) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getOptionBefore: (option: OptionValue<Item>) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getOptionPageAbove: (start: OptionValue<Item>) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getOptionPageBelow: (start: OptionValue<Item>) => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getFirstOption: () => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    getLastOption: () => {
        data: OptionValue<Item>;
        element: HTMLElement;
    } | undefined;
    valueToString: (item: Item) => string;
    disabled: boolean | undefined;
    optionStateStore: import("../list-control/ListControlOptionStore").ListControlOptionStore<Item>;
};

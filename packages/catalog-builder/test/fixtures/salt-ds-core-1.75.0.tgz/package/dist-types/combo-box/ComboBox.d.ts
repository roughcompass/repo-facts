import { type ComponentPropsWithoutRef, type ReactElement, type ReactNode, type Ref } from "react";
import { type PillInputProps } from "../pill-input";
import type { DataAttributes } from "../types";
import { type UseComboBoxProps } from "./useComboBox";
export interface ComboBoxProps<Item = string> extends UseComboBoxProps<Item>, Omit<PillInputProps, "onPillRemove"> {
    /**
     * The options to display in the combo box.
     */
    children?: ReactNode;
    /**
     * If true, options will be selected when the tab key is pressed.
     */
    selectOnTab?: boolean;
    /**
     * Props to pass to ComboBox's overlay.
     */
    OverlayProps?: Omit<ComponentPropsWithoutRef<"div">, "children" | "id"> & DataAttributes;
}
export declare const ComboBox: <Item = string>(props: ComboBoxProps<Item> & {
    ref?: Ref<HTMLDivElement>;
}) => ReactElement;

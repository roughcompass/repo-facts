import { type ComponentPropsWithoutRef } from "react";
export interface CollapsiblePanelProps extends ComponentPropsWithoutRef<"div"> {
}
export declare const CollapsiblePanel: import("react").ForwardRefExoticComponent<CollapsiblePanelProps & import("react").RefAttributes<HTMLDivElement>>;

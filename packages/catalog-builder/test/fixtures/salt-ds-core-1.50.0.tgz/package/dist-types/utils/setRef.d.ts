import type { MutableRefObject } from "react";
export declare function setRef<T>(ref: MutableRefObject<T | null> | ((instance: T | null) => void) | null | undefined, value: T | null): void;

import { type RefObject } from "react";
export interface UseResizeObserverProps {
    ref: RefObject<HTMLElement>;
    onResize: () => void;
}
export declare function useResizeObserver({ ref, onResize }: UseResizeObserverProps): void;

import type { Middleware } from "@floating-ui/core";
export declare const margin: (value?: number) => Middleware;

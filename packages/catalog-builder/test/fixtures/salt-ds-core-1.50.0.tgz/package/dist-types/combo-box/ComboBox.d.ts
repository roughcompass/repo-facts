import { type ComponentPropsWithoutRef, type ReactNode, type Ref } from "react";
import { type PillInputProps } from "../pill-input";
import type { DataAttributes } from "../types";
import { type UseComboBoxProps } from "./useComboBox";
export type ComboBoxProps<Item = string> = {
    /**
     * The options to display in the combo box.
     */
    children?: ReactNode;
    /**
     * If true, options will be selected when the tab key is pressed.
     */
    selectOnTab?: boolean;
    /**
     *  Props to pass to ComboBox's overlay.
     */
    OverlayProps?: Omit<ComponentPropsWithoutRef<"div">, "children" | "id"> & DataAttributes;
} & UseComboBoxProps<Item> & Omit<PillInputProps, "onPillRemove">;
export declare const ComboBox: <Item = string>(props: ComboBoxProps<Item> & {
    ref?: Ref<HTMLDivElement>;
}) => JSX.Element;

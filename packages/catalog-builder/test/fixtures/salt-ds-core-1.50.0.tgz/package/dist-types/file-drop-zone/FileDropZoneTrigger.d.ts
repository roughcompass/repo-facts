import { type ChangeEvent, type HTMLAttributes } from "react";
export interface FileDropZoneTriggerProps extends Omit<HTMLAttributes<HTMLButtonElement>, "onChange"> {
    /**
     * `accept` attribute for HTML <input>.
     *
     * A comma separated list of file types the user can pick from the file input dialog box.
     */
    accept?: string;
    /**
     * Disable all trigger elements.
     */
    disabled?: boolean;
    /**
     * Allows multiple files to be uploaded.
     */
    multiple?: boolean;
    /**
     * Callback for input change event
     */
    onChange?: (event: ChangeEvent<HTMLInputElement>, files: File[]) => void;
}
export declare const FileDropZoneTrigger: import("react").ForwardRefExoticComponent<FileDropZoneTriggerProps & import("react").RefAttributes<HTMLButtonElement>>;

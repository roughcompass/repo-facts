export declare const AccentValues: readonly ["blue", "teal"];
/** @deprecated use `AccentValues` */
export declare const UNSTABLE_AccentValues: readonly ["blue", "teal"];
export type Accent = (typeof AccentValues)[number];
/** @deprecated use `Accent` */
export type UNSTABLE_Accent = Accent;

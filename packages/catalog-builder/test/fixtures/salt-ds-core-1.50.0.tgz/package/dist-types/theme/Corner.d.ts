export declare const CornerValues: readonly ["sharp", "rounded"];
/** @deprecated use `CornerValues` */
export declare const UNSTABLE_CornerValues: readonly ["sharp", "rounded"];
export type Corner = (typeof CornerValues)[number];
/** @deprecated Use `Corner` */
export type UNSTABLE_Corner = Corner;

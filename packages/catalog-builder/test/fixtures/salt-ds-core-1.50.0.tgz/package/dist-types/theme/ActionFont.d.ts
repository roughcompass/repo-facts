export declare const ActionFontValues: readonly ["Open Sans", "Amplitude"];
/** @deprecated use `ActionFontValues` */
export declare const UNSTABLE_ActionFontValues: readonly ["Open Sans", "Amplitude"];
export type ActionFont = (typeof ActionFontValues)[number];
/** @deprecated use `ActionFont` */
export type UNSTABLE_ActionFont = ActionFont;

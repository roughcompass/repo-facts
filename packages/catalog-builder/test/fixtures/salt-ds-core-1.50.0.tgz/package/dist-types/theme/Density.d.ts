export declare const DensityValues: readonly ["high", "medium", "low", "touch"];
export type Density = (typeof DensityValues)[number];

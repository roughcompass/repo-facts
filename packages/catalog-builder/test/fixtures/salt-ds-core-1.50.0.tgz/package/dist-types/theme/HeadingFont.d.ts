export declare const HeadingFontValues: readonly ["Open Sans", "Amplitude"];
/** @deprecated use `HeadingFontValues` */
export declare const UNSTABLE_HeadingFontValues: readonly ["Open Sans", "Amplitude"];
export type HeadingFont = (typeof HeadingFontValues)[number];
/** @deprecated Use `HeadingFont` */
export type UNSTABLE_HeadingFont = HeadingFont;

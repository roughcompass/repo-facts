import { type ComponentPropsWithoutRef } from "react";
export interface CardProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * If provided an accent is shown in the specified position.
     */
    accent?: "bottom" | "top" | "left" | "right";
    /**
     * **Deprecated:** Use the InteractableCard component instead
     *
     * If `true`, the card will be disabled.
     */
    disabled?: boolean;
    /**
     * If `true` the card will have hover styling.
     */
    hoverable?: boolean;
    /**
     * **Deprecated:** Use the InteractableCard component instead
     *
     * If `true`, interactive styles will be applied to `Card`. These styles give prominence to certain content
     * on the page.
     */
    interactable?: boolean;
    /**
     * Styling variant. Defaults to "primary".
     */
    variant?: "primary" | "secondary" | "tertiary" | "ghost";
}
export declare const Card: import("react").ForwardRefExoticComponent<CardProps & import("react").RefAttributes<HTMLDivElement>>;

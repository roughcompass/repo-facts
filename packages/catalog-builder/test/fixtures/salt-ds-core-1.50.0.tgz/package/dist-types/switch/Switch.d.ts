import { type ChangeEventHandler, type ComponentPropsWithoutRef, type FocusEventHandler, type ReactNode } from "react";
import type { DataAttributes } from "../types";
export interface SwitchProps extends Omit<ComponentPropsWithoutRef<"label">, "children" | "onFocus" | "onBlur" | "onChange"> {
    /**
     * If `true`, the switch will be checked.
     */
    checked?: boolean;
    /**
     * Whether the switch component is checked by default
     * This will be disregarded if checked is already set.
     */
    defaultChecked?: boolean;
    /**
     * If `true`, the switch will be disabled.
     */
    disabled?: boolean;
    /**
     * Properties applied to the input element.
     */
    inputProps?: Partial<ComponentPropsWithoutRef<"input">> & DataAttributes;
    /**
     * The label to be shown next to the switch.
     */
    label?: ReactNode;
    /**
     * The name applied to the input.
     */
    name?: string;
    /**
     * Callback when switch loses focus.
     */
    onBlur?: FocusEventHandler<HTMLInputElement>;
    /**
     * Callback when checked state is changed.
     */
    onChange?: ChangeEventHandler<HTMLInputElement>;
    /**
     * Callback when switch gains focus.
     */
    onFocus?: FocusEventHandler<HTMLInputElement>;
    /**
     * The value of the switch.
     */
    value?: string;
}
export declare const Switch: import("react").ForwardRefExoticComponent<SwitchProps & import("react").RefAttributes<HTMLLabelElement>>;

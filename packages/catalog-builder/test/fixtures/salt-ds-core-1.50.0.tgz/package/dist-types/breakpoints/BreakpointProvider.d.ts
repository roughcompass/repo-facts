import { type ReactNode } from "react";
import type { Breakpoints } from "./Breakpoints";
type Breakpoint = keyof Breakpoints;
interface BreakpointContext {
    matchedBreakpoints: Breakpoint[];
}
interface BreakpointProviderProps {
    children?: ReactNode;
    matchedBreakpoints: Breakpoint[];
}
export declare function BreakpointProvider(props: BreakpointProviderProps): import("react/jsx-runtime").JSX.Element;
export declare function useMatchedBreakpoints(breakpoints: Breakpoints): Breakpoint[];
export declare function useBreakpoint(): BreakpointContext & {
    breakpoint: Breakpoint | null;
};
export {};

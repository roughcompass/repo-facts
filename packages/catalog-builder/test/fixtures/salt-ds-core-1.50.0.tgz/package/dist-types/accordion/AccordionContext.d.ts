import { type SyntheticEvent } from "react";
export interface AccordionContextValue {
    value: string;
    expanded: boolean;
    toggle: (event: SyntheticEvent<HTMLButtonElement>) => void;
    disabled: boolean;
    indicatorSide: "left" | "right";
    headerId: string;
    setHeaderId: (id: string) => void;
    panelId: string;
    setPanelId: (id: string) => void;
    status?: "error" | "warning" | "success";
}
export declare const AccordionContext: import("react").Context<AccordionContextValue>;
export declare function useAccordion(): AccordionContextValue;

import type { IconProps } from "@salt-ds/icons";
export declare const VerticalNavigationItemExpansionIcon: (props: IconProps) => import("react/jsx-runtime").JSX.Element;

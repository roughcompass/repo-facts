import { type ComponentPropsWithoutRef } from "react";
export interface DrawerProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Defines the drawer position within the screen. Defaults to `left`.
     */
    position?: "left" | "top" | "right" | "bottom";
    /**
     * Display or hide the component.
     */
    open?: boolean;
    /**
     * Callback function triggered when open state changes.
     */
    onOpenChange?: (newOpen: boolean) => void;
    /**
     * Change background color palette
     */
    variant?: "primary" | "secondary";
    /**
     * Prevent the dialog closing on click away
     * */
    disableDismiss?: boolean;
    /**
     * Prevent Scrim from rendering
     * */
    disableScrim?: boolean;
}
export declare const Drawer: import("react").ForwardRefExoticComponent<DrawerProps & import("react").RefAttributes<HTMLDivElement>>;

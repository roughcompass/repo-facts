import { type SyntheticEvent } from "react";
export type InteractableCardValue = string | readonly string[] | undefined;
export interface InteractableCardGroupContextValue {
    disabled?: boolean;
    select: (event: SyntheticEvent<HTMLDivElement>, value: InteractableCardValue) => void;
    isSelected: (id: InteractableCardValue) => boolean;
    isFirstChild: (value: InteractableCardValue) => boolean;
    multiSelect?: boolean;
    value: InteractableCardValue;
}
export declare const InteractableCardGroupContext: import("react").Context<InteractableCardGroupContextValue | undefined>;
export declare function useInteractableCardGroup(): InteractableCardGroupContextValue | undefined;

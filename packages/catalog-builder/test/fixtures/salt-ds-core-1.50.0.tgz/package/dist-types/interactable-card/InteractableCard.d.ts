import { type ComponentPropsWithoutRef, type SyntheticEvent } from "react";
import { type InteractableCardValue } from "./InteractableCardGroupContext";
export interface InteractableCardProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Accent border position: defaults to "bottom"
     */
    accent?: "bottom" | "top" | "left" | "right";
    /**
     * @deprecated Use the `accent` prop instead
     */
    accentPlacement?: "bottom" | "top" | "left" | "right";
    /**
     * If `true`, the card will be disabled.
     */
    disabled?: boolean;
    /**
     * Callback fired when the selection changes.
     * @param event
     */
    onChange?: (event: SyntheticEvent<HTMLDivElement>) => void;
    /**
     * Styling variant; defaults to "primary".
     */
    variant?: "primary" | "secondary" | "tertiary";
    /**
     * Value of card (for selectable use case).
     */
    value?: InteractableCardValue;
}
export declare const InteractableCard: import("react").ForwardRefExoticComponent<InteractableCardProps & import("react").RefAttributes<HTMLDivElement>>;

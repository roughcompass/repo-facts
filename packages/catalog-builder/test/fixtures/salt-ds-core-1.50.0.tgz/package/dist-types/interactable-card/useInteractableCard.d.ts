import { type FocusEvent, type KeyboardEvent, type MouseEvent } from "react";
export interface CardHookProps<T extends Element> {
    disabled?: boolean;
    onKeyUp?: (event: KeyboardEvent<T>) => void;
    onKeyDown?: (event: KeyboardEvent<T>) => void;
    onClick?: (event: MouseEvent<T>) => void;
    onBlur?: (event: FocusEvent<T>) => void;
}
export interface CardHookResult<T extends Element> {
    active: boolean;
    cardProps: {
        "aria-disabled"?: boolean;
        disabled?: boolean;
        tabIndex: number;
        onBlur: (event: FocusEvent<T>) => void;
        onClick?: (event: MouseEvent<T>) => void;
        onKeyDown: (event: KeyboardEvent<T>) => void;
        onKeyUp: (event: KeyboardEvent<T>) => void;
    };
}
export declare const useInteractableCard: <T extends Element>({ disabled, onKeyUp, onKeyDown, onClick, onBlur, }: CardHookProps<T>) => CardHookResult<T>;

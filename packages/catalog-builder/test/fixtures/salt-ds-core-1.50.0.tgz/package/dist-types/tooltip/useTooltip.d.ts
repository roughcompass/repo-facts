import { type HTMLProps } from "react";
import { type UseFloatingUIProps } from "../utils";
export interface UseTooltipProps extends Partial<Pick<UseFloatingUIProps, "onOpenChange" | "open" | "placement">> {
    /**
     * When `true`, the tooltip will be disabled.
     */
    disabled?: boolean;
    /**
     * Do not respond to focus events.
     */
    disableFocusListener?: boolean;
    /**
     * Do not respond to hover events.
     */
    disableHoverListener?: boolean;
    /**
     * The number of milliseconds to wait before showing the tooltip.
     * This prop won't impact the enter touch delay (`enterTouchDelay`).
     */
    enterDelay?: number;
    /**
     * The number of milliseconds to wait before hiding the tooltip.
     * This prop won't impact the leave touch delay (`leaveTouchDelay`).
     */
    leaveDelay?: number;
}
export declare function useTooltip(props?: UseTooltipProps): {
    arrowProps: {
        ref: import("react").MutableRefObject<SVGSVGElement | null>;
        context: {
            x: number;
            y: number;
            placement: import("@floating-ui/utils").Placement;
            strategy: import("@floating-ui/utils").Strategy;
            middlewareData: import("@floating-ui/core").MiddlewareData;
            isPositioned: boolean;
            update: () => void;
            floatingStyles: React.CSSProperties;
            open: boolean;
            onOpenChange: (open: boolean, event?: Event, reason?: import("@floating-ui/react").OpenChangeReason) => void;
            events: import("@floating-ui/react").FloatingEvents;
            dataRef: React.MutableRefObject<import("@floating-ui/react").ContextData>;
            nodeId: string | undefined;
            floatingId: string;
            refs: import("@floating-ui/react").ExtendedRefs<import("@floating-ui/react").ReferenceType>;
            elements: import("@floating-ui/react").ExtendedElements<import("@floating-ui/react").ReferenceType>;
        };
    };
    open: boolean;
    floating: ((node: HTMLElement | null) => void) & ((node: HTMLElement | null) => void);
    reference: ((node: import("@floating-ui/react-dom").ReferenceType | null) => void) & ((node: import("@floating-ui/react").ReferenceType | null) => void);
    getTooltipProps: () => HTMLProps<HTMLDivElement>;
    getTriggerProps: () => Record<string, unknown>;
    getTooltipPosition: () => {
        top: number;
        left: number;
        position: import("@floating-ui/utils").Strategy;
        width: number | undefined;
        height: number | undefined;
    };
};

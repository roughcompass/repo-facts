import { type HTMLAttributes, type ReactNode } from "react";
import { type ValidationStatus } from "../status-indicator";
import { type UseFloatingUIProps } from "../utils";
export interface TooltipProps extends Pick<UseFloatingUIProps, "open" | "onOpenChange" | "placement">, Omit<HTMLAttributes<HTMLDivElement>, "content"> {
    /**
     * The children will be the Tooltip's trigger.
     */
    children: ReactNode;
    /**
     * Whether to hide the Tooltip arrow. Defaults to `false`.
     */
    hideArrow?: boolean;
    /**
     * Whether to hide the status icon within the Tooltip. Defaults to `false`.
     * If no status is provided, icon will also be hidden.
     */
    hideIcon?: boolean;
    /**
     * Content displayed inside the Tooltip. Can be a string or a React component.
     */
    content: ReactNode;
    /**
     * Optional string to determine the status of the Tooltip.
     */
    status?: ValidationStatus;
    /**
     * Delay in milliseconds before the Tooltip is shown.
     */
    enterDelay?: number;
    /**
     * Delay in milliseconds before the Tooltip is hidden. Defaults to 300ms.
     */
    leaveDelay?: number;
    /**
     * Option to not display the Tooltip. Can be used in conditional situations like text truncation. Defaults to 0.
     */
    disabled?: boolean;
    /**
     * Option to remove the hover listener.
     */
    disableHoverListener?: boolean;
    /**
     * Option to remove the focus listener.
     */
    disableFocusListener?: boolean;
}
export declare const Tooltip: import("react").ForwardRefExoticComponent<TooltipProps & import("react").RefAttributes<HTMLDivElement>>;

import { type ComponentPropsWithoutRef, type ReactNode, type Ref, type TextareaHTMLAttributes } from "react";
import type { DataAttributes } from "../types";
export interface MultilineInputProps extends Omit<ComponentPropsWithoutRef<"div">, "defaultValue">, Pick<ComponentPropsWithoutRef<"textarea">, "disabled" | "value" | "defaultValue" | "placeholder"> {
    /**
     * Styling variant with full border. Defaults to false
     */
    bordered?: boolean;
    /**
     * End adornment component
     */
    endAdornment?: ReactNode;
    /**
     * If `true`, the component is read only.
     */
    readOnly?: boolean;
    /**
     * The default minimum number of rows. Defaults to 3
     */
    rows?: number;
    /**
     * Start adornment component
     */
    startAdornment?: ReactNode;
    /**
     * [Attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/textarea#Attributes) applied to the `textarea` element.
     */
    textAreaProps?: Partial<TextareaHTMLAttributes<HTMLTextAreaElement>> & DataAttributes;
    /**
     * Optional ref for the textarea component
     */
    textAreaRef?: Ref<HTMLTextAreaElement>;
    /**
     * Validation status.
     */
    validationStatus?: "error" | "warning" | "success";
    /**
     * Styling variant. Defaults to "primary".
     */
    variant?: "primary" | "secondary";
}
export declare const MultilineInput: import("react").ForwardRefExoticComponent<MultilineInputProps & import("react").RefAttributes<HTMLDivElement>>;

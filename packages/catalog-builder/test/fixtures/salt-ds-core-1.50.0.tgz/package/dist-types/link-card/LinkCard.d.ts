import { type ComponentPropsWithoutRef } from "react";
export interface LinkCardProps extends ComponentPropsWithoutRef<"a"> {
    /**
     * If provided an accent is shown in the specified position.
     */
    accent?: "bottom" | "top" | "left" | "right";
    /**
     * Styling variant; defaults to "primary".
     */
    variant?: "primary" | "secondary" | "tertiary";
}
export declare const LinkCard: import("react").ForwardRefExoticComponent<LinkCardProps & import("react").RefAttributes<HTMLAnchorElement>>;

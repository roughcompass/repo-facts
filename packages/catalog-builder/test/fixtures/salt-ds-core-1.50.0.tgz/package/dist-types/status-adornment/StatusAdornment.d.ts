import type { IconProps } from "@salt-ds/icons";
import type { ValidationStatus } from "../status-indicator";
export type AdornmentValidationStatus = Exclude<ValidationStatus, "info">;
export interface StatusAdornmentProps extends IconProps {
    /**
     * Status adornment to be displayed.
     */
    status: AdornmentValidationStatus;
}
export declare const StatusAdornment: import("react").ForwardRefExoticComponent<StatusAdornmentProps & import("react").RefAttributes<SVGSVGElement>>;

import { type RefObject, type SyntheticEvent } from "react";
export interface OptionValue<Item> {
    id: string;
    disabled: boolean;
    value: Item;
}
export type OpenChangeReason = "input" | "manual";
export interface ListControlContextValue<Item> {
    openState: boolean;
    setOpen: (newOpen: boolean, openChangeReason?: OpenChangeReason) => void;
    register: (optionValue: OptionValue<Item>, element: HTMLElement) => () => void;
    selectedState: unknown[];
    select: (event: SyntheticEvent, option: OptionValue<Item>) => void;
    activeState?: OptionValue<Item>;
    setActive: (option: OptionValue<Item>) => void;
    multiselect: boolean;
    focusVisibleState: boolean;
    valueToString: (item: Item) => string;
    disabled?: boolean;
    listRef?: RefObject<HTMLDivElement>;
}
export declare const ListControlContext: import("react").Context<ListControlContextValue<any>>;
export declare function useListControlContext<Item>(): ListControlContextValue<Item>;

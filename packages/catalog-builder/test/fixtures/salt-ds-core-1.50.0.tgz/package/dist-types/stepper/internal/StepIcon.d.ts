import type { IconProps } from "@salt-ds/icons";
import type { StepStage, StepStatus } from "../Step";
export interface StepIconProps extends IconProps {
    stage: StepStage;
    status?: StepStatus;
    sizeMultiplier?: IconProps["size"];
}
export declare function StepIcon({ status, stage, size, sizeMultiplier, className, ...props }: StepIconProps): import("react/jsx-runtime").JSX.Element;

import { type TextProps } from "../../text";
export interface StepTextProps extends TextProps<"div"> {
    purpose: "label" | "description";
}
export declare function StepText({ id, purpose, className, styleAs, children, ...props }: StepTextProps): import("react/jsx-runtime").JSX.Element;

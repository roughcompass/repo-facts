export declare function StepConnector(): import("react/jsx-runtime").JSX.Element;

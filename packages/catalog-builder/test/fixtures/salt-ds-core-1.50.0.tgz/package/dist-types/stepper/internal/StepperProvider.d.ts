import { type ReactNode } from "react";
import type { StepperOrientation } from "../Stepper";
export declare const StepperOrientationContext: import("react").Context<StepperOrientation>;
export declare const StepDepthContext: import("react").Context<number>;
export interface StepperProviderProps {
    orientation: StepperOrientation;
    children: ReactNode;
}
export declare function StepperProvider({ orientation: orientationProp, children, }: StepperProviderProps): import("react/jsx-runtime").JSX.Element;

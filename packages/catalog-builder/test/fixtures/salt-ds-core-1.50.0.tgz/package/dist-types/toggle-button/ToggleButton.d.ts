import { type ComponentPropsWithoutRef, type MouseEvent } from "react";
import type { ButtonAppearance, ButtonSentiment } from "../button";
export interface ToggleButtonProps extends ComponentPropsWithoutRef<"button"> {
    /**
     * The appearance of the toggle button when `selected` is true.
     * @default solid
     */
    appearance?: Extract<ButtonAppearance, "bordered" | "solid">;
    /**
     * Callback fired when the toggle button's selection state is changed.
     */
    onChange?: (event: MouseEvent<HTMLButtonElement>) => void;
    /**
     * If `true`, the toggle button will be read-only.
     */
    readOnly?: boolean;
    /**
     * The sentiment of the toggle button.
     * @default neutral
     */
    sentiment?: ButtonSentiment;
    /**
     * Whether the toggle button is in a selected state.
     */
    selected?: boolean;
    /**
     * Whether the toggle button is selected by default.
     * This will be disregarded if `selected` is already set.
     */
    defaultSelected?: boolean;
    /**
     * Value of the toggle button, to be used when in a controlled state.
     */
    value: string | ReadonlyArray<string> | number | undefined;
}
export declare const ToggleButton: import("react").ForwardRefExoticComponent<ToggleButtonProps & import("react").RefAttributes<HTMLButtonElement>>;

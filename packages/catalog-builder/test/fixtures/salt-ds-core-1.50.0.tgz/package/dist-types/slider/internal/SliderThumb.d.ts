import { type ChangeEvent, type ComponentPropsWithoutRef, type RefObject } from "react";
interface SliderThumbProps extends Omit<ComponentPropsWithoutRef<"input">, "onChange" | "defaultValue" | "min" | "max"> {
    accessibleMaxText?: string;
    accessibleMinText?: string;
    disabled: boolean;
    format?: (value: number) => number | string;
    handleInputChange: (event: ChangeEvent<HTMLInputElement>) => void;
    handleKeydownOnThumb: (event: React.KeyboardEvent) => void;
    handlePointerDown: (event: React.PointerEvent<HTMLDivElement>) => void;
    index?: number;
    inputRef?: RefObject<HTMLInputElement>;
    isFocusVisible: boolean;
    max: number;
    maxLabel?: string;
    min: number;
    minLabel?: string;
    offsetPercentage?: string;
    restrictToMarks?: boolean;
    showTooltip?: boolean;
    sliderValue: [number, number] | number;
    step: number;
    stepMultiplier: number;
    trackDragging: boolean;
}
export declare const SliderThumb: ({ "aria-label": ariaLabel, "aria-valuetext": ariaValueText, "aria-labelledby": ariaLabelledBy, accessibleMaxText, accessibleMinText, disabled, format, handleInputChange, handleKeydownOnThumb, handlePointerDown, index, inputRef, isFocusVisible, max, maxLabel, min, minLabel, offsetPercentage, restrictToMarks, showTooltip, sliderValue, step, stepMultiplier, trackDragging, ...rest }: SliderThumbProps) => import("react/jsx-runtime").JSX.Element;
export {};

interface SliderTooltipProps {
    value: number | string;
    open?: boolean;
}
export declare const SliderTooltip: ({ value, open }: SliderTooltipProps) => import("react/jsx-runtime").JSX.Element;
export {};

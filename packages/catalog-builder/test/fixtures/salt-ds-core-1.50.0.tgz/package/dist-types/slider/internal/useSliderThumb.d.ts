import { type ChangeEvent, type Dispatch, type RefObject, type SetStateAction } from "react";
import type { SliderProps } from "../Slider";
type UseSliderThumbProps = Pick<SliderProps, "min" | "max" | "step"> & {
    decimalPlaces: number;
    handleInputChange: (event: ChangeEvent<HTMLInputElement>) => void;
    inputRef: RefObject<HTMLInputElement>;
    marks?: {
        label: string;
        value: number;
    }[];
    onChange?: (event: Event, value: number) => void;
    onChangeEnd?: (event: Event, value: number) => void;
    restrictToMarks?: boolean;
    setValue: Dispatch<SetStateAction<number>>;
    stepMultiplier: number;
    value: number;
};
export declare const useSliderThumb: ({ decimalPlaces, handleInputChange, inputRef, marks, min, max, step, onChange, onChangeEnd, restrictToMarks, setValue, stepMultiplier, value, }: UseSliderThumbProps) => {
    handleBlur: () => void;
    handleFocus: () => void;
    handleKeydownOnThumb: (event: React.KeyboardEvent) => void;
    handlePointerDownOnThumb: (event: React.PointerEvent<HTMLDivElement>) => void;
    handlePointerDownOnTrack: (event: React.PointerEvent<HTMLDivElement>) => void;
    isDragging: boolean;
    isFocusVisible: boolean;
    sliderRef: RefObject<HTMLDivElement>;
};
export {};

import { type HTMLAttributes, type RefObject } from "react";
interface SliderTrackProps extends Omit<HTMLAttributes<HTMLDivElement>, "onChange" | "defaultValue"> {
    children: React.ReactNode;
    constrainLabelPosition?: boolean;
    disabled: boolean;
    showTicks?: boolean;
    format?: (value: number) => string | number;
    handlePointerDown: (event: React.PointerEvent<HTMLDivElement>) => void;
    isDragging: boolean;
    isRange?: boolean;
    marks?: {
        label: string;
        value: number;
    }[];
    max: number;
    maxLabel?: number | string;
    min: number;
    minLabel?: number | string;
    progressPercentage?: number;
    progressPercentageRange?: [number, number];
    sliderRef: RefObject<HTMLDivElement>;
}
export declare const SliderTrack: import("react").ForwardRefExoticComponent<SliderTrackProps & import("react").RefAttributes<HTMLDivElement>>;
export {};

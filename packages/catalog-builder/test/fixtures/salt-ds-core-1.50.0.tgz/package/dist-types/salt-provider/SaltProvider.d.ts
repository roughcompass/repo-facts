import { type WindowContextType } from "@salt-ds/window";
import { type ReactElement, type ReactNode } from "react";
import { type Breakpoints } from "../breakpoints";
import type { Accent, ActionFont, Corner, Density, HeadingFont, Mode, ThemeName } from "../theme";
export declare const DEFAULT_DENSITY = "medium";
export interface ThemeContextProps {
    theme: ThemeName;
    mode: Mode;
    window?: WindowContextType;
    /** Only available when using SaltProviderNext. */
    themeNext: boolean;
    corner: Corner;
    /** @deprecated use `corner`*/
    UNSTABLE_corner: Corner;
    headingFont: HeadingFont;
    /** @deprecated use `headingFont` */
    UNSTABLE_headingFont: HeadingFont;
    accent: Accent;
    /** @deprecated use `accent` */
    UNSTABLE_accent: Accent;
    actionFont: ActionFont;
    /** @deprecated use `actionFont` */
    UNSTABLE_actionFont: ActionFont;
}
export declare const DensityContext: import("react").Context<"touch" | "high" | "low" | "medium">;
export declare const ThemeContext: import("react").Context<ThemeContextProps>;
export declare const BreakpointContext: import("react").Context<Breakpoints>;
type TargetElement = "root" | "scope" | "child";
interface SaltProviderBaseProps {
    /**
     * Either "root", "scope" or "child".
     * Specifies the location of salt theme class and attributes should be applied to.
     *
     * Defaults to "root" for a root provider, otherwise "scope".
     */
    applyClassesTo?: TargetElement;
    /**
     * Either "high", "medium", "low" or "touch".
     * Determines the amount of content that can fit on a screen based on the size and spacing of components.
     * Refer to [density](https://www.saltdesignsystem.com/salt/foundations/density) doc for more detail.
     *
     * @default "medium"
     */
    density?: Density;
    /**
     * A string. Specifies custom theme name(s) you want to apply, similar to `className`.
     */
    theme?: ThemeName;
    /**
     * Either "light" or "dark". Enable the color palette to change from light to dark.
     * Refer to [modes](https://www.saltdesignsystem.com/salt/foundations/modes) doc for more detail.
     *
     * @default "light"
     */
    mode?: Mode;
    /**
     * Shape of `{ xs: number; sm: number; md: number; lg: number; xl: number; }`.
     * Determines breakpoints used in responsive calculation for layout components.
     */
    breakpoints?: Breakpoints;
    /**
     * A boolean. Enables dynamic style injection for each component.
     *
     * If `false`, you'll need to include component CSS yourself.
     *
     * @default true
     */
    enableStyleInjection?: boolean;
}
interface SaltProviderThatAppliesClassesToChild extends SaltProviderBaseProps {
    children: ReactElement;
    applyClassesTo: "child";
}
interface SaltProviderThatInjectsThemeElement extends SaltProviderBaseProps {
    children: ReactNode;
}
interface SaltProviderThatClassesToRoot extends SaltProviderThatInjectsThemeElement {
    applyClassesTo: "root";
}
type SaltProviderProps = SaltProviderThatAppliesClassesToChild | SaltProviderThatInjectsThemeElement | SaltProviderThatClassesToRoot;
export declare function SaltProvider({ enableStyleInjection, ...restProps }: SaltProviderProps): import("react/jsx-runtime").JSX.Element;
interface SaltProviderNextAdditionalProps {
    /**
     * Either "sharp" or "rounded".
     * Determines selected components corner radius.
     * @default "sharp"
     */
    corner?: Corner;
    /**
     * Either "Open Sans" or "Amplitude".
     * Determines font family of display and heading text.
     * @default "Open Sans"
     */
    headingFont?: HeadingFont;
    /**
     * Either "blue" or "teal".
     * Determines accent color used across components, e.g. Accent Button, List, Calendar.
     * @default "blue"
     */
    accent?: Accent;
    /**
     * Either "Open Sans" or "Amplitude".
     * Determines font family of action components, mostly Buttons.
     * @default "Open Sans"
     */
    actionFont?: ActionFont;
}
export type SaltProviderNextProps = SaltProviderProps & SaltProviderNextAdditionalProps;
/** @deprecated use `SaltProviderNextProps` */
export type UNSTABLE_SaltProviderNextProps = SaltProviderNextProps;
export declare function SaltProviderNext({ enableStyleInjection, ...restProps }: SaltProviderNextProps): import("react/jsx-runtime").JSX.Element;
/** @deprecated use `SaltProviderNext` */
export declare const UNSTABLE_SaltProviderNext: typeof SaltProviderNext;
export declare const useTheme: () => ThemeContextProps;
/**
 * `useDensity` merges density value from `DensityContext` with the one from component's props.
 */
export declare function useDensity(density?: Density): Density;
export declare const useBreakpoints: () => Breakpoints;
export {};

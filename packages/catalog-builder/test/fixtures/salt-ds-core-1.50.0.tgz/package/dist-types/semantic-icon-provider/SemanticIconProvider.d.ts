import { type ElementType, type ReactNode } from "react";
export type SemanticIconMap = {
    ExpandIcon: ElementType;
    CollapseIcon: ElementType;
    ExpandGroupIcon: ElementType;
    CollapseGroupIcon: ElementType;
    NextIcon: ElementType;
    PreviousIcon: ElementType;
    IncreaseIcon: ElementType;
    DecreaseIcon: ElementType;
    UploadIcon: ElementType;
    ErrorIcon: ElementType;
    SuccessIcon: ElementType;
    InfoIcon: ElementType;
    WarningIcon: ElementType;
    OverflowIcon: ElementType;
    UserIcon: ElementType;
    CalendarIcon: ElementType;
    CloseIcon: ElementType;
    ExternalIcon: ElementType;
    PendingIcon: ElementType;
    ActiveIcon: ElementType;
    CompletedIcon: ElementType;
    LockedIcon: ElementType;
    InProgressIcon: ElementType;
};
export interface SemanticIconProviderProps {
    /**
     * Custom mapping of icon names to components. Overrides default icons if provided.
     */
    iconMap?: Partial<SemanticIconMap>;
    /**
     * Child elements that will use the provided icons.
     */
    children: ReactNode;
}
export declare const SemanticIconProvider: ({ iconMap, children, }: SemanticIconProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const useIcon: () => SemanticIconMap;

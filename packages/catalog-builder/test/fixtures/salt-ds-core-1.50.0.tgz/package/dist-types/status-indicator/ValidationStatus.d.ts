export declare const VALIDATION_NAMED_STATUS: readonly ["error", "warning", "success", "info"];
export type ValidationStatus = (typeof VALIDATION_NAMED_STATUS)[number];

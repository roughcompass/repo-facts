import type { FloatingArrowProps, FloatingContext, ReferenceType, Strategy } from "@floating-ui/react";
import { type HTMLProps } from "react";
type FloatingStyleProps = {
    top: number;
    left: number;
    position: Strategy;
    width?: number;
    height?: number;
};
export interface OverlayContextValue {
    openState: boolean;
    floatingStyles: FloatingStyleProps;
    arrowProps: FloatingArrowProps;
    context: FloatingContext;
    reference?: (node: ReferenceType | null) => void;
    floating?: (node: HTMLElement | null) => void;
    getFloatingProps: (userProps?: HTMLProps<HTMLElement> | undefined) => Record<string, unknown>;
    getReferenceProps: (userProps?: HTMLProps<Element> | undefined) => Record<string, unknown>;
}
export declare const OverlayContext: import("react").Context<OverlayContextValue>;
export declare function useOverlayContext(): OverlayContextValue;
export {};

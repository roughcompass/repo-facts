import { type ComponentPropsWithoutRef } from "react";
export interface OverlayProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * Display or hide the component.
     */
    open?: boolean;
    /**
     * Callback function triggered when open state changes.
     */
    onOpenChange?: (open: boolean) => void;
    placement?: "top" | "bottom" | "left" | "right";
}
export declare const Overlay: ({ children, open, onOpenChange, placement: placementProp, }: OverlayProps) => import("react/jsx-runtime").JSX.Element;

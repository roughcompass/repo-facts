import { type FocusEventHandler, type KeyboardEventHandler, type MouseEventHandler, type RefObject } from "react";
interface ManageFocusOnTargetProps {
    onBlur?: FocusEventHandler;
    onClick?: MouseEventHandler;
    onKeyUp?: KeyboardEventHandler;
    targetRef: RefObject<HTMLElement> | undefined;
    targetClass: string;
}
interface ManageFocusOnTargetResult {
    onBlur?: FocusEventHandler<HTMLAnchorElement>;
    onClick?: MouseEventHandler<HTMLAnchorElement>;
    onKeyUp?: KeyboardEventHandler<HTMLAnchorElement>;
}
export declare const useManageFocusOnTarget: ({ onKeyUp, onBlur, onClick, targetRef, targetClass, }: ManageFocusOnTargetProps) => ManageFocusOnTargetResult;
export {};

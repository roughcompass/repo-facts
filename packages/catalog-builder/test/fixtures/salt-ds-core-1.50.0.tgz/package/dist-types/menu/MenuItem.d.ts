import { type ComponentPropsWithoutRef } from "react";
export interface MenuItemProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * If `true`, the item will be disabled.
     */
    disabled?: boolean;
}
export declare const MenuItem: import("react").ForwardRefExoticComponent<MenuItemProps & import("react").RefAttributes<HTMLDivElement>>;

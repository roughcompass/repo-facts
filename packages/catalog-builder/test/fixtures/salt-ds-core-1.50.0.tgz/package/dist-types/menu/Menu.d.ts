import { type MenuBaseProps } from "./MenuBase";
export interface MenuProps extends MenuBaseProps {
}
export declare function Menu(props: MenuProps): import("react/jsx-runtime").JSX.Element;

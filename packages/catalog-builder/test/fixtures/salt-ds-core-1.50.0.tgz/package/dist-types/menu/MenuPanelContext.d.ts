import type { MenuContextValue } from "./MenuContext";
export interface MenuPanelContextValue extends Pick<MenuContextValue, "getItemProps" | "activeIndex" | "setFocusInside"> {
}
export declare const MenuPanelContext: import("react").Context<MenuPanelContextValue>;
export declare function useMenuPanelContext(): MenuPanelContextValue;

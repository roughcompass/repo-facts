import { type ReferenceType } from "@floating-ui/react";
import { type ReactNode } from "react";
import { type UseFloatingUIProps } from "../utils";
export interface MenuBaseProps {
    children?: ReactNode;
    /**
     * Display or hide the component.
     */
    open?: boolean;
    /**
     * If true, the menu will be open by default.
     */
    defaultOpen?: boolean;
    /**
     * Callback function triggered when open state changes.
     */
    onOpenChange?: (newOpen: boolean) => void;
    /**
     * Set the placement of the Menu component relative to the trigger element. Defaults to `bottom-start` if it's the root menu or `right-start` if it's nested.
     */
    placement?: UseFloatingUIProps["placement"];
    /**
     * Function that returns a [virtual element](https://floating-ui.com/docs/virtual-elements). If this is provided, it will override MenuTrigger.
     */
    getVirtualElement?: () => ReferenceType | null;
}
export declare function MenuBase(props: MenuBaseProps): import("react/jsx-runtime").JSX.Element;

import { type ComponentPropsWithoutRef, type ReactNode } from "react";
export interface MenuGroupProps extends ComponentPropsWithoutRef<"div"> {
    /**
     * The label of the menu group.
     */
    label?: string;
    /**
     * Menus to be rendered inside the menu group.
     */
    children?: ReactNode;
}
export declare const MenuGroup: import("react").ForwardRefExoticComponent<MenuGroupProps & import("react").RefAttributes<HTMLDivElement>>;

import { type ElementType, type FunctionComponent } from "react";
import type { ValidationStatus } from "../status-indicator";
import { type PolymorphicComponentPropWithRef } from "../utils";
export type TextProps<T extends ElementType> = PolymorphicComponentPropWithRef<T, {
    /**
     * Applies disabled styling when true
     */
    disabled?: boolean;
    /**
     * Apply text truncation by mentioning number of rows to be displayed
     */
    maxRows?: number;
    /**
     * Match styling to another text component's style
     */
    styleAs?: "h1" | "h2" | "h3" | "h4" | "label" | "display1" | "display2" | "display3" | "display4" | "notation" | "action" | "code";
    /**
     * Change text color palette
     * @deprecated Use `color` instead
     */
    variant?: "primary" | "secondary";
    color?: "inherit" | "primary" | "secondary" | ValidationStatus;
}>;
type TextComponent = <T extends ElementType = "div">(props: TextProps<T>) => ReturnType<FunctionComponent>;
export declare const Text: TextComponent;
export {};

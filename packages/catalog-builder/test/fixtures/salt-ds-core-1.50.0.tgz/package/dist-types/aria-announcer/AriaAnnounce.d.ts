import { type ComponentType } from "react";
export interface AriaAnnounceProps {
    /**
     * String which will be announced by screen readers on change
     */
    announcement?: string;
}
export declare const AriaAnnounce: ComponentType<AriaAnnounceProps>;

import { type CSSProperties, type ReactNode } from "react";
export declare const ARIA_ANNOUNCE_DELAY = 150;
export interface AriaAnnouncerProviderProps {
    children?: ReactNode;
    /**
     * Style overrides for the aria-live element
     */
    style?: CSSProperties;
}
export declare function AriaAnnouncerProvider({ children, style, }: AriaAnnouncerProviderProps): import("react/jsx-runtime").JSX.Element;

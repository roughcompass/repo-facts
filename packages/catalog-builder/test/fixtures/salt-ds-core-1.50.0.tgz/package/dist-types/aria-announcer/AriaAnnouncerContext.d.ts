export type AnnounceFn = (announcement: string, delay?: number) => void;
export type AriaAnnouncer = {
    announce: AnnounceFn;
};
export declare const AriaAnnouncerContext: import("react").Context<AriaAnnouncer | undefined>;

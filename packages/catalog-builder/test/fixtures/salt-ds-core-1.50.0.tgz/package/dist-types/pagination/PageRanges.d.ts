export interface PageRangesProps {
    boundaryCount?: number;
    siblingCount?: number;
}
export declare function PageRanges({ siblingCount, boundaryCount, }: PageRangesProps): import("react/jsx-runtime").JSX.Element;

import { type ComponentPropsWithoutRef } from "react";
interface LinkActionProps extends ComponentPropsWithoutRef<"a"> {
}
export declare const LinkAction: import("react").ForwardRefExoticComponent<LinkActionProps & import("react").RefAttributes<HTMLAnchorElement>>;
export {};

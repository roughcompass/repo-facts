import { type ComponentPropsWithoutRef } from "react";
export interface PillProps extends ComponentPropsWithoutRef<"button"> {
}
export declare const Pill: import("react").ForwardRefExoticComponent<PillProps & import("react").RefAttributes<HTMLButtonElement>>;

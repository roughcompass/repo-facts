import { type ReactNode } from "react";
declare const ViewportContext: import("react").Context<number | null>;
type ViewportProviderProps = {
    children?: ReactNode;
};
declare const ViewportProvider: ({ children }: ViewportProviderProps) => import("react/jsx-runtime").JSX.Element;
declare const useViewport: () => number;
export { ViewportProvider, ViewportContext, useViewport };

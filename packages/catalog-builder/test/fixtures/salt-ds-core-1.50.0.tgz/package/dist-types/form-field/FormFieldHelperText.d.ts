import { type TextProps } from "../text";
export interface FormFieldHelperTextProps extends Omit<TextProps<"label">, "variant" | "styleAs"> {
}
export declare const FormFieldHelperText: ({ className, children, ...restProps }: FormFieldHelperTextProps) => import("react/jsx-runtime").JSX.Element;

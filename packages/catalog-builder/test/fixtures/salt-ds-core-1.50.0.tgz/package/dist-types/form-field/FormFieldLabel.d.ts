import { type TextProps } from "../text";
export interface FormFieldLabelProps extends Omit<TextProps<"label">, "variant" | "styleAs"> {
    /**
     * Intent for the label.
     *
     * Defaults to "label"
     * Using "sentence" gives more prominent styling
     */
    intent?: "label" | "sentence";
}
export declare const FormFieldLabel: ({ className, children, intent, onClick, ...restProps }: FormFieldLabelProps) => import("react/jsx-runtime").JSX.Element;

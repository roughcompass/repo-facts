import { type HTMLAttributes } from "react";
/**
 * Panel component that acts as wrapper around a node
 *
 * @example
 * const PanelExample = () => (
 *   <Panel>
 *     <p>This is a panel around some text.</p>
 *   </Panel>
 * );
 *
 */
export interface PanelProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Styling variant; defaults to "primary".
     */
    variant?: "primary" | "secondary" | "tertiary";
}
export declare const Panel: import("react").ForwardRefExoticComponent<PanelProps & import("react").RefAttributes<HTMLDivElement>>;

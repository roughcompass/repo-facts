import { type SyntheticEvent } from "react";
import type { ButtonAppearance, ButtonSentiment } from "../button";
export type Value = string | readonly string[] | number | undefined;
export interface ToggleButtonGroupContextValue {
    appearance?: Extract<ButtonAppearance, "bordered" | "solid">;
    disabled?: boolean;
    focus: (id: Value) => void;
    isFocused: (id: Value) => boolean;
    isSelected: (id: Value) => boolean;
    orientation: "horizontal" | "vertical";
    readOnly?: boolean;
    select: (event: SyntheticEvent<HTMLButtonElement>) => void;
    sentiment?: ButtonSentiment;
}
export declare const ToggleButtonGroupContext: import("react").Context<ToggleButtonGroupContextValue | undefined>;
export declare function useToggleButtonGroup(): ToggleButtonGroupContextValue | undefined;

import type { SVGAttributes } from "react";
import type { Density } from "../../theme";
import type { SpinnerSVGSize } from "../Spinner";
interface SpinnerProps {
    id?: string;
    rest?: Omit<SVGAttributes<SVGSVGElement>, "id">;
    size: SpinnerSVGSize;
    density: Density;
}
export declare const SpinnerSVG: ({ id, rest, size, density, }: SpinnerProps) => import("react/jsx-runtime").JSX.Element;
export {};

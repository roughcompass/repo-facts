import type { ValidationStatus } from "../status-indicator";
export declare const DialogContext: import("react").Context<{
    status?: ValidationStatus;
    id: string | undefined;
}>;
export declare const useDialogContext: () => {
    status?: ValidationStatus;
    id: string | undefined;
};

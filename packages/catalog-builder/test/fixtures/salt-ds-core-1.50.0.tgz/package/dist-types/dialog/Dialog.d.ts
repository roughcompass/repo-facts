import { type FloatingFocusManager } from "@floating-ui/react";
import { type ComponentProps, type HTMLAttributes, type ReactNode } from "react";
import type { ValidationStatus } from "../status-indicator";
interface ConditionalScrimWrapperProps {
    children?: ReactNode;
    condition: boolean;
}
export declare const ConditionalScrimWrapper: ({ condition, children, }: ConditionalScrimWrapperProps) => import("react/jsx-runtime").JSX.Element;
export interface DialogProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Display or hide the component.
     */
    open?: boolean;
    /**
     * Callback function triggered when open state changes.
     */
    onOpenChange?: (open: boolean) => void;
    /**
     * The status of the Dialog
     * */
    status?: ValidationStatus;
    /**
     * Which element to initially focus. Can be either a number (tabbable index as specified by the order) or a ref.
     * Default value is 0 (first tabbable element).
     * */
    initialFocus?: ComponentProps<typeof FloatingFocusManager>["initialFocus"];
    /**
     * Size of the Dialog
     * */
    size?: "small" | "medium" | "large";
    /**
     * Prevent the dialog closing on click away
     * */
    disableDismiss?: boolean;
    /**
     * Prevent Scrim from rendering
     * */
    disableScrim?: boolean;
    /**
     * Optional id prop
     * Used for accessibility purposes to announce the title and subtitle when using a screen reader
     * */
    idProp?: string;
}
export declare const Dialog: import("react").ForwardRefExoticComponent<DialogProps & import("react").RefAttributes<HTMLDivElement>>;
export {};

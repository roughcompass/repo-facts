import { type IconProps } from "../icon";
export type Replay15IconProps = IconProps;
export declare const Replay15Icon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SymphonyIconProps = IconProps;
export declare const SymphonyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ScalesSolidIconProps = IconProps;
export declare const ScalesSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

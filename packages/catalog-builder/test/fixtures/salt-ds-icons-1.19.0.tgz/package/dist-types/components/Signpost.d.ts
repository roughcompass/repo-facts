import { type IconProps } from "../icon";
export type SignpostIconProps = IconProps;
export declare const SignpostIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type RestoreIconProps = IconProps;
export declare const RestoreIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ArrowRightIconProps = IconProps;
export declare const ArrowRightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

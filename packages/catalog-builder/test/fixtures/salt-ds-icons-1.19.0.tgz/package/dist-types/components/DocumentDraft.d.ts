import { type IconProps } from "../icon";
export type DocumentDraftIconProps = IconProps;
export declare const DocumentDraftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SuccessTickIconProps = IconProps;
/** @deprecated since 1.13.0. Use `CheckmarkIcon` instead. */
export declare const SuccessTickIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type TriangleUpIconProps = IconProps;
export declare const TriangleUpIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

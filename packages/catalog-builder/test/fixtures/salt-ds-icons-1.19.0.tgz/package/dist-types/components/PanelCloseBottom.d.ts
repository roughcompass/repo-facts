import { type IconProps } from "../icon";
export type PanelCloseBottomIconProps = IconProps;
export declare const PanelCloseBottomIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SuccessCircleIconProps = IconProps;
export declare const SuccessCircleIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

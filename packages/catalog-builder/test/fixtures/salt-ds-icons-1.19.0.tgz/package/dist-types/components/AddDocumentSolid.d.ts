import { type IconProps } from "../icon";
export type AddDocumentSolidIconProps = IconProps;
export declare const AddDocumentSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SchoolIconProps = IconProps;
export declare const SchoolIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type RunReportIconProps = IconProps;
export declare const RunReportIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

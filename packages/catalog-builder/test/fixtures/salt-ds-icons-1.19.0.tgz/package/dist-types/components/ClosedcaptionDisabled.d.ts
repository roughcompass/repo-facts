import { type IconProps } from "../icon";
export type ClosedcaptionDisabledIconProps = IconProps;
export declare const ClosedcaptionDisabledIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PriceLadderIconProps = IconProps;
export declare const PriceLadderIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type FolderClosedSolidIconProps = IconProps;
export declare const FolderClosedSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

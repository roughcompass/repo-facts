import { type IconProps } from "../icon";
export type CurrencyIconProps = IconProps;
export declare const CurrencyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

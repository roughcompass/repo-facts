import { type IconProps } from "../icon";
export type StepActiveIconProps = IconProps;
export declare const StepActiveIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

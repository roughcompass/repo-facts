import { type IconProps } from "../icon";
export type MarkerIconProps = IconProps;
export declare const MarkerIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type BankCheckIconProps = IconProps;
export declare const BankCheckIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

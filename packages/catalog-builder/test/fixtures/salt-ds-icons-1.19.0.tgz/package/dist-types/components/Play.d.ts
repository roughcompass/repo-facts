import { type IconProps } from "../icon";
export type PlayIconProps = IconProps;
export declare const PlayIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

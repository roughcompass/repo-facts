import { type IconProps } from "../icon";
export type TailsIconProps = IconProps;
export declare const TailsIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

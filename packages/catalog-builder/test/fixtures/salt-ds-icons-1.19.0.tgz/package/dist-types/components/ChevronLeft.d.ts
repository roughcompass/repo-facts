import { type IconProps } from "../icon";
export type ChevronLeftIconProps = IconProps;
export declare const ChevronLeftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

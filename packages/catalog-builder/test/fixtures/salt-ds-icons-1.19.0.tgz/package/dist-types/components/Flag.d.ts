import { type IconProps } from "../icon";
export type FlagIconProps = IconProps;
export declare const FlagIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PicnicSolidIconProps = IconProps;
export declare const PicnicSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SortDescendIconProps = IconProps;
export declare const SortDescendIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

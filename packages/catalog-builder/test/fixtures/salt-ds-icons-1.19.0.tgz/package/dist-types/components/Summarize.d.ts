import { type IconProps } from "../icon";
export type SummarizeIconProps = IconProps;
export declare const SummarizeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

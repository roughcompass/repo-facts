import { type IconProps } from "../icon";
export type ChartLineIconProps = IconProps;
export declare const ChartLineIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

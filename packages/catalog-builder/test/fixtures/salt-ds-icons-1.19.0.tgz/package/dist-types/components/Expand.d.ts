import { type IconProps } from "../icon";
export type ExpandIconProps = IconProps;
export declare const ExpandIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type HandshakeIconProps = IconProps;
export declare const HandshakeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

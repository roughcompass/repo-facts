import { type IconProps } from "../icon";
export type ImportSolidIconProps = IconProps;
export declare const ImportSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

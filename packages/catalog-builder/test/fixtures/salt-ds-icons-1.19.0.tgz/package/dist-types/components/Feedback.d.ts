import { type IconProps } from "../icon";
export type FeedbackIconProps = IconProps;
export declare const FeedbackIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

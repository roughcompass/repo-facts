import { type IconProps } from "../icon";
export type FigmaIconProps = IconProps;
export declare const FigmaIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

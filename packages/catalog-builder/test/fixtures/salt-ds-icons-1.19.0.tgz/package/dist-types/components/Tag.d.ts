import { type IconProps } from "../icon";
export type TagIconProps = IconProps;
export declare const TagIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

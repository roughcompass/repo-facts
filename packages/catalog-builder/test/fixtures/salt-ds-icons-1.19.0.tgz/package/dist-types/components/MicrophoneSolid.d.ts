import { type IconProps } from "../icon";
export type MicrophoneSolidIconProps = IconProps;
export declare const MicrophoneSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

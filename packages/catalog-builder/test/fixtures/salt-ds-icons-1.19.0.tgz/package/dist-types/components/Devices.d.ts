import { type IconProps } from "../icon";
export type DevicesIconProps = IconProps;
export declare const DevicesIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

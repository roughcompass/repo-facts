import { type IconProps } from "../icon";
export type SignalIconProps = IconProps;
export declare const SignalIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type HospitalIconProps = IconProps;
export declare const HospitalIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

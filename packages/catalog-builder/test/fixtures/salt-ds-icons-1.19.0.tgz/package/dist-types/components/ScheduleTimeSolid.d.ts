import { type IconProps } from "../icon";
export type ScheduleTimeSolidIconProps = IconProps;
export declare const ScheduleTimeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

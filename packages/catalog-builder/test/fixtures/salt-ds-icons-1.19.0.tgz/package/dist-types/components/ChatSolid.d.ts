import { type IconProps } from "../icon";
export type ChatSolidIconProps = IconProps;
export declare const ChatSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type StorefrontIconProps = IconProps;
export declare const StorefrontIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type Forward5IconProps = IconProps;
export declare const Forward5Icon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

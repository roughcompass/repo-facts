import { type IconProps } from "../icon";
export type LessThanIconProps = IconProps;
export declare const LessThanIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type TextColorIconProps = IconProps;
export declare const TextColorIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

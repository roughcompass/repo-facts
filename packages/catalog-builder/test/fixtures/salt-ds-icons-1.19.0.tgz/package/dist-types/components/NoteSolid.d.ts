import { type IconProps } from "../icon";
export type NoteSolidIconProps = IconProps;
export declare const NoteSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

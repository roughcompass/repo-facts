import { type IconProps } from "../icon";
export type CreditCardSolidIconProps = IconProps;
export declare const CreditCardSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CalendarIconProps = IconProps;
export declare const CalendarIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

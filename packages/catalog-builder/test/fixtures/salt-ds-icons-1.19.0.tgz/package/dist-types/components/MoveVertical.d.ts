import { type IconProps } from "../icon";
export type MoveVerticalIconProps = IconProps;
export declare const MoveVerticalIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

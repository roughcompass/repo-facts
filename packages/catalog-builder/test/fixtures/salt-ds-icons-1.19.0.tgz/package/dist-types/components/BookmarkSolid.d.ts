import { type IconProps } from "../icon";
export type BookmarkSolidIconProps = IconProps;
export declare const BookmarkSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CsvIconProps = IconProps;
export declare const CsvIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

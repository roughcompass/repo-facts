import { type IconProps } from "../icon";
export type MinimizeIconProps = IconProps;
export declare const MinimizeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

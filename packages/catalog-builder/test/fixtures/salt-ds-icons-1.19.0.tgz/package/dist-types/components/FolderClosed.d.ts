import { type IconProps } from "../icon";
export type FolderClosedIconProps = IconProps;
export declare const FolderClosedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

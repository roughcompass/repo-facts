import { type IconProps } from "../icon";
export type FolderOpenIconProps = IconProps;
export declare const FolderOpenIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

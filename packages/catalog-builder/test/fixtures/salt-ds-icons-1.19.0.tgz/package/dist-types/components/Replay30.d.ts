import { type IconProps } from "../icon";
export type Replay30IconProps = IconProps;
export declare const Replay30Icon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SortAlphaAscendIconProps = IconProps;
export declare const SortAlphaAscendIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

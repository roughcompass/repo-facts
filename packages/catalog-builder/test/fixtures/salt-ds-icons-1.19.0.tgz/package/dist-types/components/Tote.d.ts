import { type IconProps } from "../icon";
export type ToteIconProps = IconProps;
export declare const ToteIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

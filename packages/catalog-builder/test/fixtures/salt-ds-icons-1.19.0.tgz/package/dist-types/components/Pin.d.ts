import { type IconProps } from "../icon";
export type PinIconProps = IconProps;
export declare const PinIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

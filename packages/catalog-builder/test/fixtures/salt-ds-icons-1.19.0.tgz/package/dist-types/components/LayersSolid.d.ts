import { type IconProps } from "../icon";
export type LayersSolidIconProps = IconProps;
export declare const LayersSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

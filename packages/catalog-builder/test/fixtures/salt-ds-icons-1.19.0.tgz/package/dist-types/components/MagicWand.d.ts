import { type IconProps } from "../icon";
export type MagicWandIconProps = IconProps;
export declare const MagicWandIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

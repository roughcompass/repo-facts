import { type IconProps } from "../icon";
export type CollapseIconProps = IconProps;
export declare const CollapseIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

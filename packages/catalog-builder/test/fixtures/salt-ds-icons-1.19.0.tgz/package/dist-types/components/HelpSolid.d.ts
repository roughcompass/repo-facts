import { type IconProps } from "../icon";
export type HelpSolidIconProps = IconProps;
/** @deprecated since 1.18.0. Use `HelpCircleSolidIcon` instead. */
export declare const HelpSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

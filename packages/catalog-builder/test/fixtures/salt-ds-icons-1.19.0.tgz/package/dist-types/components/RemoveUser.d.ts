import { type IconProps } from "../icon";
export type RemoveUserIconProps = IconProps;
export declare const RemoveUserIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

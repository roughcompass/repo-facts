import { type IconProps } from "../icon";
export type ListIconProps = IconProps;
export declare const ListIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

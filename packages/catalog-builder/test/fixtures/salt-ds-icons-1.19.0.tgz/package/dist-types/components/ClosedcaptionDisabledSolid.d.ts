import { type IconProps } from "../icon";
export type ClosedcaptionDisabledSolidIconProps = IconProps;
export declare const ClosedcaptionDisabledSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

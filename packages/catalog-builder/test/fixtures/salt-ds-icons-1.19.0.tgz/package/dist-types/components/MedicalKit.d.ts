import { type IconProps } from "../icon";
export type MedicalKitIconProps = IconProps;
export declare const MedicalKitIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type LinkedinIconProps = IconProps;
export declare const LinkedinIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

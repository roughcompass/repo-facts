import { type IconProps } from "../icon";
export type TextBoldIconProps = IconProps;
export declare const TextBoldIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

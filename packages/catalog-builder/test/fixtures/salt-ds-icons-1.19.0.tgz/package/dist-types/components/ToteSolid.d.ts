import { type IconProps } from "../icon";
export type ToteSolidIconProps = IconProps;
export declare const ToteSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

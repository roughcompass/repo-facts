import { type IconProps } from "../icon";
export type RemoveDocumentIconProps = IconProps;
export declare const RemoveDocumentIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ErrorIconProps = IconProps;
export declare const ErrorIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type InboxIconProps = IconProps;
export declare const InboxIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

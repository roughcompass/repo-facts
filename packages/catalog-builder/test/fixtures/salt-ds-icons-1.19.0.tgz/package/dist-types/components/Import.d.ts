import { type IconProps } from "../icon";
export type ImportIconProps = IconProps;
export declare const ImportIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

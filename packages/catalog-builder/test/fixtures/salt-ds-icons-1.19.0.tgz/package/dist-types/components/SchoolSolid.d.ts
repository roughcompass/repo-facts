import { type IconProps } from "../icon";
export type SchoolSolidIconProps = IconProps;
export declare const SchoolSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

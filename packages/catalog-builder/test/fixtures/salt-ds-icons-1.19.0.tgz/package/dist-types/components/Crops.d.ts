import { type IconProps } from "../icon";
export type CropsIconProps = IconProps;
export declare const CropsIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

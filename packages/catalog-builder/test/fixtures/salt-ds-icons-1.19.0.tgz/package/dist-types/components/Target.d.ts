import { type IconProps } from "../icon";
export type TargetIconProps = IconProps;
export declare const TargetIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

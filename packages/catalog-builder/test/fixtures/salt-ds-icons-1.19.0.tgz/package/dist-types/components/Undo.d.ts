import { type IconProps } from "../icon";
export type UndoIconProps = IconProps;
export declare const UndoIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

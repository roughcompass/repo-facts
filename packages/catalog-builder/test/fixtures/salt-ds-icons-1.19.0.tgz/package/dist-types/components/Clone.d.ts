import { type IconProps } from "../icon";
export type CloneIconProps = IconProps;
export declare const CloneIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

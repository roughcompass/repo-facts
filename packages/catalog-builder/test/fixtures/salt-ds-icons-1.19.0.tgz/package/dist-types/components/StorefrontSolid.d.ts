import { type IconProps } from "../icon";
export type StorefrontSolidIconProps = IconProps;
export declare const StorefrontSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

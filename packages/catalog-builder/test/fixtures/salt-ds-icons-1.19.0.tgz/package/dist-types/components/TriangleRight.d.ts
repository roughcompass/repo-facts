import { type IconProps } from "../icon";
export type TriangleRightIconProps = IconProps;
export declare const TriangleRightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type DisplaySolidIconProps = IconProps;
export declare const DisplaySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

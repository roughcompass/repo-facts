import { type IconProps } from "../icon";
export type DocumentSearchIconProps = IconProps;
export declare const DocumentSearchIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

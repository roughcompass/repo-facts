import { type IconProps } from "../icon";
export type CompareIconProps = IconProps;
export declare const CompareIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

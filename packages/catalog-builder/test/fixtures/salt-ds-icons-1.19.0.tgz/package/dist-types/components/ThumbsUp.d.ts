import { type IconProps } from "../icon";
export type ThumbsUpIconProps = IconProps;
export declare const ThumbsUpIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type InboxSolidIconProps = IconProps;
export declare const InboxSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

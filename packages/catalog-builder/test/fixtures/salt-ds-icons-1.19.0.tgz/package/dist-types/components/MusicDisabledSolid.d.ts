import { type IconProps } from "../icon";
export type MusicDisabledSolidIconProps = IconProps;
export declare const MusicDisabledSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PanelCloseBottomSolidIconProps = IconProps;
export declare const PanelCloseBottomSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

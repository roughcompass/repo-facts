import { type IconProps } from "../icon";
export type StopSolidIconProps = IconProps;
export declare const StopSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type LikeSolidIconProps = IconProps;
export declare const LikeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ScalesIconProps = IconProps;
export declare const ScalesIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ChartBulletIconProps = IconProps;
export declare const ChartBulletIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type DoubleChevronRightIconProps = IconProps;
export declare const DoubleChevronRightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ChartBoxPlotIconProps = IconProps;
export declare const ChartBoxPlotIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PanelOpenRightIconProps = IconProps;
export declare const PanelOpenRightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

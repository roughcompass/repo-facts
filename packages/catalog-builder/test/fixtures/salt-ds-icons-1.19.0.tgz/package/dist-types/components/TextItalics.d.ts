import { type IconProps } from "../icon";
export type TextItalicsIconProps = IconProps;
export declare const TextItalicsIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

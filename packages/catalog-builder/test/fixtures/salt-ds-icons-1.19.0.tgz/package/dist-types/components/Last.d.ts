import { type IconProps } from "../icon";
export type LastIconProps = IconProps;
export declare const LastIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

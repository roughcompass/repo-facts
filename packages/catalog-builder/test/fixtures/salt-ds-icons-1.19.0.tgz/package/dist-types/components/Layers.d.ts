import { type IconProps } from "../icon";
export type LayersIconProps = IconProps;
export declare const LayersIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

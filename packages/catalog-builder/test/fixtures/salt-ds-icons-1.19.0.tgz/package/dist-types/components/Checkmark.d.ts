import { type IconProps } from "../icon";
export type CheckmarkIconProps = IconProps;
export declare const CheckmarkIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type TextUnorderedListIconProps = IconProps;
export declare const TextUnorderedListIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

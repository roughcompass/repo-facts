import { type IconProps } from "../icon";
export type KeyCapslockIconProps = IconProps;
export declare const KeyCapslockIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

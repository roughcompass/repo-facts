import { type IconProps } from "../icon";
export type FavoriteHalfIconProps = IconProps;
export declare const FavoriteHalfIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

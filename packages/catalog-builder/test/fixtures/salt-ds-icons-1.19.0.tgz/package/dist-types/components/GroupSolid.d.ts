import { type IconProps } from "../icon";
export type GroupSolidIconProps = IconProps;
export declare const GroupSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

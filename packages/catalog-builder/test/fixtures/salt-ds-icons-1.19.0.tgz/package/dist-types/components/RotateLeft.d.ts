import { type IconProps } from "../icon";
export type RotateLeftIconProps = IconProps;
export declare const RotateLeftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type MicrophoneDisabledSolidIconProps = IconProps;
export declare const MicrophoneDisabledSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ChartBubbleIconProps = IconProps;
export declare const ChartBubbleIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CookieSolidIconProps = IconProps;
export declare const CookieSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CommentarySolidIconProps = IconProps;
export declare const CommentarySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type FirstIconProps = IconProps;
export declare const FirstIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

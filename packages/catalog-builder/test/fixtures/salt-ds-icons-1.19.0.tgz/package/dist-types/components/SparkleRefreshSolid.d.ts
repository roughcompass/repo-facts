import { type IconProps } from "../icon";
export type SparkleRefreshSolidIconProps = IconProps;
export declare const SparkleRefreshSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

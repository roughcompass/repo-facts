import { type IconProps } from "../icon";
export type ProgressOnholdIconProps = IconProps;
export declare const ProgressOnholdIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

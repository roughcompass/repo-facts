import { type IconProps } from "../icon";
export type MouseIconProps = IconProps;
export declare const MouseIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ChartCandlestickIconProps = IconProps;
export declare const ChartCandlestickIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

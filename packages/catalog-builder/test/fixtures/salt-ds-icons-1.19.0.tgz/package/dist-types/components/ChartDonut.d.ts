import { type IconProps } from "../icon";
export type ChartDonutIconProps = IconProps;
export declare const ChartDonutIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

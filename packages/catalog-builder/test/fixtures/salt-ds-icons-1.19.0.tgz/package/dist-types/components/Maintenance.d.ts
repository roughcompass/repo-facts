import { type IconProps } from "../icon";
export type MaintenanceIconProps = IconProps;
export declare const MaintenanceIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type BankIconProps = IconProps;
export declare const BankIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

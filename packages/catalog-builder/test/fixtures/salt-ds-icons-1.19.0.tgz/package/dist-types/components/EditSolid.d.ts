import { type IconProps } from "../icon";
export type EditSolidIconProps = IconProps;
export declare const EditSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

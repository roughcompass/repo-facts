import { type IconProps } from "../icon";
export type SemanticVeryDissatisfiedSolidIconProps = IconProps;
export declare const SemanticVeryDissatisfiedSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

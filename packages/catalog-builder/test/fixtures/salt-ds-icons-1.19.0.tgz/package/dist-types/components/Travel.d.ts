import { type IconProps } from "../icon";
export type TravelIconProps = IconProps;
export declare const TravelIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

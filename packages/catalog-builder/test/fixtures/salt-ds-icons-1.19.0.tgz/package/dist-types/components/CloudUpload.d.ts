import { type IconProps } from "../icon";
export type CloudUploadIconProps = IconProps;
export declare const CloudUploadIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

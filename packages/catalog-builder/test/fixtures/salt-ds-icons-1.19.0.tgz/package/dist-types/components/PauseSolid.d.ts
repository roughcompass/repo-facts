import { type IconProps } from "../icon";
export type PauseSolidIconProps = IconProps;
export declare const PauseSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

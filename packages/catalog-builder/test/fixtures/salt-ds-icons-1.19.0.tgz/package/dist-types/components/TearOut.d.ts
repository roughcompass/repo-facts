import { type IconProps } from "../icon";
export type TearOutIconProps = IconProps;
export declare const TearOutIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

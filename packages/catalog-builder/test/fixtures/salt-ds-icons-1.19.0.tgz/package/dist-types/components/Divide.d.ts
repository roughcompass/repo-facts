import { type IconProps } from "../icon";
export type DivideIconProps = IconProps;
export declare const DivideIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

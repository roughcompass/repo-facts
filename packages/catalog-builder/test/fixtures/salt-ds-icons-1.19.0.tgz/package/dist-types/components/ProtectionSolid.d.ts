import { type IconProps } from "../icon";
export type ProtectionSolidIconProps = IconProps;
export declare const ProtectionSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type MusicIconProps = IconProps;
export declare const MusicIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

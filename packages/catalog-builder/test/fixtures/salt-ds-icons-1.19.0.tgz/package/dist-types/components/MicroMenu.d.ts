import { type IconProps } from "../icon";
export type MicroMenuIconProps = IconProps;
export declare const MicroMenuIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

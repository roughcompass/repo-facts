import { type IconProps } from "../icon";
export type CheckmarkSolidIconProps = IconProps;
export declare const CheckmarkSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CurrencySolidIconProps = IconProps;
export declare const CurrencySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type KeyTabIconProps = IconProps;
export declare const KeyTabIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

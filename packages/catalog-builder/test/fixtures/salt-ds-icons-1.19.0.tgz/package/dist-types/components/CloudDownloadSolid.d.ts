import { type IconProps } from "../icon";
export type CloudDownloadSolidIconProps = IconProps;
export declare const CloudDownloadSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

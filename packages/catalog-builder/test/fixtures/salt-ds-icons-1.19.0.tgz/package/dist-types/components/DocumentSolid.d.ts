import { type IconProps } from "../icon";
export type DocumentSolidIconProps = IconProps;
export declare const DocumentSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

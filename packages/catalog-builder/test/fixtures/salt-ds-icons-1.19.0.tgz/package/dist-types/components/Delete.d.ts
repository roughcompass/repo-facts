import { type IconProps } from "../icon";
export type DeleteIconProps = IconProps;
export declare const DeleteIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

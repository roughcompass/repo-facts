import { type IconProps } from "../icon";
export type DocumentEditIconProps = IconProps;
export declare const DocumentEditIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ChartStackedBarIconProps = IconProps;
export declare const ChartStackedBarIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

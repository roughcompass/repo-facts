import { type IconProps } from "../icon";
export type KeySolidIconProps = IconProps;
export declare const KeySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

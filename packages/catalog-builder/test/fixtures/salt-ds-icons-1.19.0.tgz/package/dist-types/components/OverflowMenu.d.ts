import { type IconProps } from "../icon";
export type OverflowMenuIconProps = IconProps;
export declare const OverflowMenuIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type TextStrikethroughIconProps = IconProps;
export declare const TextStrikethroughIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SuccessSmallIconProps = IconProps;
/** @deprecated since 1.13.0. Use `CheckmarkIcon` instead. */
export declare const SuccessSmallIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

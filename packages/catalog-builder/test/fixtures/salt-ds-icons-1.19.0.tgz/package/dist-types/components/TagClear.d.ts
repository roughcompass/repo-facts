import { type IconProps } from "../icon";
export type TagClearIconProps = IconProps;
export declare const TagClearIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

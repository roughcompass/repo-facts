import { type IconProps } from "../icon";
export type AddIconProps = IconProps;
export declare const AddIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

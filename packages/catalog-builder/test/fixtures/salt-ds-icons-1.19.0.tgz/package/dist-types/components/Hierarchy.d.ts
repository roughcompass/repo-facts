import { type IconProps } from "../icon";
export type HierarchyIconProps = IconProps;
export declare const HierarchyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type DragRowIconProps = IconProps;
export declare const DragRowIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

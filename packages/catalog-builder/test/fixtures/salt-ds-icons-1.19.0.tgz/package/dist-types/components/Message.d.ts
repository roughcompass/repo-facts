import { type IconProps } from "../icon";
export type MessageIconProps = IconProps;
export declare const MessageIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

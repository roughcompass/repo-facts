import { type IconProps } from "../icon";
export type CompassIconProps = IconProps;
export declare const CompassIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

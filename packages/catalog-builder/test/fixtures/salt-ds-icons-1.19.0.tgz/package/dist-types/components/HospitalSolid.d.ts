import { type IconProps } from "../icon";
export type HospitalSolidIconProps = IconProps;
export declare const HospitalSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type AttachIconProps = IconProps;
export declare const AttachIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

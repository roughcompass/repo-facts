import { type IconProps } from "../icon";
export type SignpostSolidIconProps = IconProps;
export declare const SignpostSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

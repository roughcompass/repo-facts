import { type IconProps } from "../icon";
export type PanelCloseRightIconProps = IconProps;
export declare const PanelCloseRightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type DashboardSolidIconProps = IconProps;
export declare const DashboardSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

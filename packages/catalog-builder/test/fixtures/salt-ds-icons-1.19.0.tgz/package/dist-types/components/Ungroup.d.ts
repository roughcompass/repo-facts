import { type IconProps } from "../icon";
export type UngroupIconProps = IconProps;
export declare const UngroupIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

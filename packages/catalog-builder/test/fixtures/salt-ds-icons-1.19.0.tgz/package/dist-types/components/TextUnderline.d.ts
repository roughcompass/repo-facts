import { type IconProps } from "../icon";
export type TextUnderlineIconProps = IconProps;
export declare const TextUnderlineIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

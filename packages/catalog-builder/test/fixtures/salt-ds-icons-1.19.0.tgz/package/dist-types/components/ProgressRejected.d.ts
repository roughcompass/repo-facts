import { type IconProps } from "../icon";
export type ProgressRejectedIconProps = IconProps;
export declare const ProgressRejectedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type DownloadIconProps = IconProps;
export declare const DownloadIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

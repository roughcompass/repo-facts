import { type IconProps } from "../icon";
export type SemanticVeryDissatisfiedIconProps = IconProps;
export declare const SemanticVeryDissatisfiedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

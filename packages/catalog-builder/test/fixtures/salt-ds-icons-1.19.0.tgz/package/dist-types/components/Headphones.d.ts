import { type IconProps } from "../icon";
export type HeadphonesIconProps = IconProps;
export declare const HeadphonesIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CommentaryIconProps = IconProps;
export declare const CommentaryIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

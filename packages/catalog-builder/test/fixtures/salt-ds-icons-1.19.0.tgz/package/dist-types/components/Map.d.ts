import { type IconProps } from "../icon";
export type MapIconProps = IconProps;
export declare const MapIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

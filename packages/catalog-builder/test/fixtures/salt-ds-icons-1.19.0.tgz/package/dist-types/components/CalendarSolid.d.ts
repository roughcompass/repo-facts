import { type IconProps } from "../icon";
export type CalendarSolidIconProps = IconProps;
export declare const CalendarSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

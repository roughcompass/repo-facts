import { type IconProps } from "../icon";
export type StorageSolidIconProps = IconProps;
export declare const StorageSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type Forward15IconProps = IconProps;
export declare const Forward15Icon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

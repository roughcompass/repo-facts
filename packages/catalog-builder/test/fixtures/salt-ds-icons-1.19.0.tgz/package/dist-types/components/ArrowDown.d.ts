import { type IconProps } from "../icon";
export type ArrowDownIconProps = IconProps;
export declare const ArrowDownIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type MobileIconProps = IconProps;
export declare const MobileIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

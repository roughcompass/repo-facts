import { type IconProps } from "../icon";
export type HeadphonesSolidIconProps = IconProps;
export declare const HeadphonesSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

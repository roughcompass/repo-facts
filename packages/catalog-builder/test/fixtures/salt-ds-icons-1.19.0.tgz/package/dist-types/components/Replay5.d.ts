import { type IconProps } from "../icon";
export type Replay5IconProps = IconProps;
export declare const Replay5Icon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

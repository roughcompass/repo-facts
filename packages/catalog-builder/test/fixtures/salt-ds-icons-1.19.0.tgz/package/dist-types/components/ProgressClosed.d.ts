import { type IconProps } from "../icon";
export type ProgressClosedIconProps = IconProps;
export declare const ProgressClosedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

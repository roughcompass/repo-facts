import { type IconProps } from "../icon";
export type SearchIconProps = IconProps;
export declare const SearchIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

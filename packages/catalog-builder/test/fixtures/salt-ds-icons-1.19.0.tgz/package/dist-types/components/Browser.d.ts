import { type IconProps } from "../icon";
export type BrowserIconProps = IconProps;
export declare const BrowserIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

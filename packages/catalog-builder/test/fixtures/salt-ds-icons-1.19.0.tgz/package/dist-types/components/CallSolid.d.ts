import { type IconProps } from "../icon";
export type CallSolidIconProps = IconProps;
export declare const CallSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

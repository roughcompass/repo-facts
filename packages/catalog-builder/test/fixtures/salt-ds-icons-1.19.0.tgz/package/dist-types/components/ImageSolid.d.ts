import { type IconProps } from "../icon";
export type ImageSolidIconProps = IconProps;
export declare const ImageSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

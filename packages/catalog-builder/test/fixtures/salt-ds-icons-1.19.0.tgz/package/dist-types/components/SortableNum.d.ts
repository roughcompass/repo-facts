import { type IconProps } from "../icon";
export type SortableNumIconProps = IconProps;
export declare const SortableNumIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

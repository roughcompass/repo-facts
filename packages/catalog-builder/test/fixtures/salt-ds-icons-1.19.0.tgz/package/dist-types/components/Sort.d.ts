import { type IconProps } from "../icon";
export type SortIconProps = IconProps;
export declare const SortIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

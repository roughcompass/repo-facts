import { type IconProps } from "../icon";
export type PieChartIconProps = IconProps;
/** @deprecated since 1.16.0. Use `ChartPieIcon` instead. */
export declare const PieChartIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

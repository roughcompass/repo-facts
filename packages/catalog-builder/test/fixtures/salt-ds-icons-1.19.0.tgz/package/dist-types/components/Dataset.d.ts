import { type IconProps } from "../icon";
export type DatasetIconProps = IconProps;
export declare const DatasetIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

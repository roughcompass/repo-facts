import { type IconProps } from "../icon";
export type InfoSolidIconProps = IconProps;
export declare const InfoSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

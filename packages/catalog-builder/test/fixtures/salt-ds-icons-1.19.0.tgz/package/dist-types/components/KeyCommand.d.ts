import { type IconProps } from "../icon";
export type KeyCommandIconProps = IconProps;
export declare const KeyCommandIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type HistoryIconProps = IconProps;
export declare const HistoryIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

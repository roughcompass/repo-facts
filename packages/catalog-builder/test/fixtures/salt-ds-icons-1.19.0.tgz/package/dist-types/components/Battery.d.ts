import { type IconProps } from "../icon";
export type BatteryIconProps = IconProps;
export declare const BatteryIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

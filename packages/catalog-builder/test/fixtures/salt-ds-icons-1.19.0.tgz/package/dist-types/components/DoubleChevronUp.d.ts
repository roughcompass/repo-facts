import { type IconProps } from "../icon";
export type DoubleChevronUpIconProps = IconProps;
export declare const DoubleChevronUpIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

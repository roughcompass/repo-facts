import { type IconProps } from "../icon";
export type LightIconProps = IconProps;
export declare const LightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PasteSolidIconProps = IconProps;
export declare const PasteSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PanelCloseTopIconProps = IconProps;
export declare const PanelCloseTopIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

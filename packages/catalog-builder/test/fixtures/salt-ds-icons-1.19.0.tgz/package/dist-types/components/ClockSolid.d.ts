import { type IconProps } from "../icon";
export type ClockSolidIconProps = IconProps;
export declare const ClockSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

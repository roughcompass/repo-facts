import { type IconProps } from "../icon";
export type ProgressActiveIconProps = IconProps;
export declare const ProgressActiveIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

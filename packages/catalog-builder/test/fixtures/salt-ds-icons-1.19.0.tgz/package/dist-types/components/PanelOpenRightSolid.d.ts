import { type IconProps } from "../icon";
export type PanelOpenRightSolidIconProps = IconProps;
export declare const PanelOpenRightSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

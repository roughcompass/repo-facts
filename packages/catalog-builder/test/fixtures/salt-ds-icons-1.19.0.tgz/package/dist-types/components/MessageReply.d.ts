import { type IconProps } from "../icon";
export type MessageReplyIconProps = IconProps;
export declare const MessageReplyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type IndentIconProps = IconProps;
export declare const IndentIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

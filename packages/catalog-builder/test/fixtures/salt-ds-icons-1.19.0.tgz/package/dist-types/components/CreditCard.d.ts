import { type IconProps } from "../icon";
export type CreditCardIconProps = IconProps;
export declare const CreditCardIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

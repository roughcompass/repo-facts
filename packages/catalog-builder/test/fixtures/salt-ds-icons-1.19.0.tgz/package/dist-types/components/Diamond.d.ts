import { type IconProps } from "../icon";
export type DiamondIconProps = IconProps;
export declare const DiamondIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PanelCloseLeftSolidIconProps = IconProps;
export declare const PanelCloseLeftSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

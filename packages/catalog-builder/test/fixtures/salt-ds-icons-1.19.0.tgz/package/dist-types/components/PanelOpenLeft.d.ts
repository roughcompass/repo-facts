import { type IconProps } from "../icon";
export type PanelOpenLeftIconProps = IconProps;
export declare const PanelOpenLeftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

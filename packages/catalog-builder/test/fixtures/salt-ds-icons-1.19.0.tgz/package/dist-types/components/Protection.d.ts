import { type IconProps } from "../icon";
export type ProtectionIconProps = IconProps;
export declare const ProtectionIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

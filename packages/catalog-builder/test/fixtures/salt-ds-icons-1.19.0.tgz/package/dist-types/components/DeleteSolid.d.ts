import { type IconProps } from "../icon";
export type DeleteSolidIconProps = IconProps;
export declare const DeleteSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ExpandAllIconProps = IconProps;
export declare const ExpandAllIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

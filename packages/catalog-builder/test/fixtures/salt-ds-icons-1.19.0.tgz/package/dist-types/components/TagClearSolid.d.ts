import { type IconProps } from "../icon";
export type TagClearSolidIconProps = IconProps;
export declare const TagClearSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

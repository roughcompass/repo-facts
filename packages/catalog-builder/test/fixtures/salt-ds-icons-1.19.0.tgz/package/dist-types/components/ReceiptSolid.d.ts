import { type IconProps } from "../icon";
export type ReceiptSolidIconProps = IconProps;
export declare const ReceiptSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

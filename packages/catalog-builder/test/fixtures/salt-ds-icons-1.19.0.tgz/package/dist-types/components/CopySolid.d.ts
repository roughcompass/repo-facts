import { type IconProps } from "../icon";
export type CopySolidIconProps = IconProps;
export declare const CopySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

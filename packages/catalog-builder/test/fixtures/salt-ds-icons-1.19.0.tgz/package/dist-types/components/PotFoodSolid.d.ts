import { type IconProps } from "../icon";
export type PotFoodSolidIconProps = IconProps;
export declare const PotFoodSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type LightSolidIconProps = IconProps;
export declare const LightSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

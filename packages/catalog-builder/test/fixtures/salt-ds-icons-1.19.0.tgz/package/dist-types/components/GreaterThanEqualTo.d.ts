import { type IconProps } from "../icon";
export type GreaterThanEqualToIconProps = IconProps;
export declare const GreaterThanEqualToIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type MessageSolidIconProps = IconProps;
export declare const MessageSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

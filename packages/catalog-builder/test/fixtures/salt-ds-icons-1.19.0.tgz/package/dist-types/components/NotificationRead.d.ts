import { type IconProps } from "../icon";
export type NotificationReadIconProps = IconProps;
export declare const NotificationReadIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

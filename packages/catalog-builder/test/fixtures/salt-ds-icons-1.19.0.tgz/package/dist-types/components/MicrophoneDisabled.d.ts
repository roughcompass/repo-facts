import { type IconProps } from "../icon";
export type MicrophoneDisabledIconProps = IconProps;
export declare const MicrophoneDisabledIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type FavoriteIconProps = IconProps;
export declare const FavoriteIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ChartWaterfallIconProps = IconProps;
export declare const ChartWaterfallIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type StackoverflowIconProps = IconProps;
export declare const StackoverflowIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SortNumDescendIconProps = IconProps;
export declare const SortNumDescendIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

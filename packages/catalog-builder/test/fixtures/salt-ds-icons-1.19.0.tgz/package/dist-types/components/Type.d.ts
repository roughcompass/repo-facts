import { type IconProps } from "../icon";
export type TypeIconProps = IconProps;
export declare const TypeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

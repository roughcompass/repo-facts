import { type IconProps } from "../icon";
export type GithubIconProps = IconProps;
export declare const GithubIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

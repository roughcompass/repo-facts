import { type IconProps } from "../icon";
export type SaltShakerSolidIconProps = IconProps;
export declare const SaltShakerSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

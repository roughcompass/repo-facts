import { type IconProps } from "../icon";
export type SortNumAscendIconProps = IconProps;
export declare const SortNumAscendIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

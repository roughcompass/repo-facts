import { type IconProps } from "../icon";
export type ExpandAllHorizontalIconProps = IconProps;
export declare const ExpandAllHorizontalIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

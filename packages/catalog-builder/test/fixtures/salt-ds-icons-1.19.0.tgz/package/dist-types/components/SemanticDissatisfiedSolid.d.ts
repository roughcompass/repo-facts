import { type IconProps } from "../icon";
export type SemanticDissatisfiedSolidIconProps = IconProps;
export declare const SemanticDissatisfiedSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

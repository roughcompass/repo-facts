import { type IconProps } from "../icon";
export type CollapseAllHorizontalIconProps = IconProps;
export declare const CollapseAllHorizontalIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

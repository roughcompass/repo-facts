import { type IconProps } from "../icon";
export type CloseSmallIconProps = IconProps;
export declare const CloseSmallIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

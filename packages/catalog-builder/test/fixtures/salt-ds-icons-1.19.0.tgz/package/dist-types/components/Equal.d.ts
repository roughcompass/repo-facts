import { type IconProps } from "../icon";
export type EqualIconProps = IconProps;
export declare const EqualIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

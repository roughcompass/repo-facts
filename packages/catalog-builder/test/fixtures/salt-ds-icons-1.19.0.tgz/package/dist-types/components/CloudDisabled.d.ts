import { type IconProps } from "../icon";
export type CloudDisabledIconProps = IconProps;
export declare const CloudDisabledIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

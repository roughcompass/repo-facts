import { type IconProps } from "../icon";
export type TypeSolidIconProps = IconProps;
export declare const TypeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

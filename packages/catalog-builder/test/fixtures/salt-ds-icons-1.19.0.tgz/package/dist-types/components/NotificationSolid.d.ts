import { type IconProps } from "../icon";
export type NotificationSolidIconProps = IconProps;
export declare const NotificationSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

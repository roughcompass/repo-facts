import { type IconProps } from "../icon";
export type TriangleDownIconProps = IconProps;
export declare const TriangleDownIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

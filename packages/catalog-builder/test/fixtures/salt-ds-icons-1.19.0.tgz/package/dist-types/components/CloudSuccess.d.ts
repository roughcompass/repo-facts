import { type IconProps } from "../icon";
export type CloudSuccessIconProps = IconProps;
export declare const CloudSuccessIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

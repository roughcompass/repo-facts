import { type IconProps } from "../icon";
export type ProgressPendingIconProps = IconProps;
export declare const ProgressPendingIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

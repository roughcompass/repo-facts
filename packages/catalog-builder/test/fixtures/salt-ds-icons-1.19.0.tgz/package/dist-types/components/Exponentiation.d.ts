import { type IconProps } from "../icon";
export type ExponentiationIconProps = IconProps;
export declare const ExponentiationIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type TextAlignJustifyIconProps = IconProps;
export declare const TextAlignJustifyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

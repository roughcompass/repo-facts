import { type IconProps } from "../icon";
export type FilterClearSolidIconProps = IconProps;
export declare const FilterClearSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type DoesNotEqualIconProps = IconProps;
export declare const DoesNotEqualIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

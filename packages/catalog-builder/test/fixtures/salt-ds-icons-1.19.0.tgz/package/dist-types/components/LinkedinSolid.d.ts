import { type IconProps } from "../icon";
export type LinkedinSolidIconProps = IconProps;
export declare const LinkedinSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

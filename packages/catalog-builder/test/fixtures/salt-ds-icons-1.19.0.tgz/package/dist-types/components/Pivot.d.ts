import { type IconProps } from "../icon";
export type PivotIconProps = IconProps;
export declare const PivotIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

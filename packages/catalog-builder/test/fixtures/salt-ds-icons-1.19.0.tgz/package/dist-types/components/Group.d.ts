import { type IconProps } from "../icon";
export type GroupIconProps = IconProps;
export declare const GroupIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

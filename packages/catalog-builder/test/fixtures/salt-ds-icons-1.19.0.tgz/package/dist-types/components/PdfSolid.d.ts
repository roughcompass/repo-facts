import { type IconProps } from "../icon";
export type PdfSolidIconProps = IconProps;
export declare const PdfSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

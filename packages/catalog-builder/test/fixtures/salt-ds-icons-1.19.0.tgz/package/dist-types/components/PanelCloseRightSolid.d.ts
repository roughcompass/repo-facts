import { type IconProps } from "../icon";
export type PanelCloseRightSolidIconProps = IconProps;
export declare const PanelCloseRightSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

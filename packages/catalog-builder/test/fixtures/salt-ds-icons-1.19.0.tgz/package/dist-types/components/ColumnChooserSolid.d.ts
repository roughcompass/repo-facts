import { type IconProps } from "../icon";
export type ColumnChooserSolidIconProps = IconProps;
export declare const ColumnChooserSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

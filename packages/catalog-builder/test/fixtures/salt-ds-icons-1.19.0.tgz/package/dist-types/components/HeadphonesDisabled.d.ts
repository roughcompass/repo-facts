import { type IconProps } from "../icon";
export type HeadphonesDisabledIconProps = IconProps;
export declare const HeadphonesDisabledIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

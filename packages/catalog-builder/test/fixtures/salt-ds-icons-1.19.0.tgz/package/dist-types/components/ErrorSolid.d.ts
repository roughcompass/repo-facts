import { type IconProps } from "../icon";
export type ErrorSolidIconProps = IconProps;
export declare const ErrorSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

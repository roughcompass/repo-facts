import { type IconProps } from "../icon";
export type NoteIconProps = IconProps;
export declare const NoteIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

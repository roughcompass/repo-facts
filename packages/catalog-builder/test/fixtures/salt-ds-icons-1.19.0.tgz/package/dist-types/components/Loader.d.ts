import { type IconProps } from "../icon";
export type LoaderIconProps = IconProps;
export declare const LoaderIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

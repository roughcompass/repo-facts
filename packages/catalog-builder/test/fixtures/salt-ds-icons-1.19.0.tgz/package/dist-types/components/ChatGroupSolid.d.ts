import { type IconProps } from "../icon";
export type ChatGroupSolidIconProps = IconProps;
export declare const ChatGroupSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

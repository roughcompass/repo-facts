import { type IconProps } from "../icon";
export type FilterIconProps = IconProps;
export declare const FilterIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PanelOpenBottomSolidIconProps = IconProps;
export declare const PanelOpenBottomSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

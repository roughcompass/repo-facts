import { type IconProps } from "../icon";
export type SparkleSolidIconProps = IconProps;
export declare const SparkleSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

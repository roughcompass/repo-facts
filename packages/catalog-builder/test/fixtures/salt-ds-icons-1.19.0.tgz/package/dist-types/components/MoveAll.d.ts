import { type IconProps } from "../icon";
export type MoveAllIconProps = IconProps;
export declare const MoveAllIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

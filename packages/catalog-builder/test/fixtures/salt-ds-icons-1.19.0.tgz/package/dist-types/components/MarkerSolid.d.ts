import { type IconProps } from "../icon";
export type MarkerSolidIconProps = IconProps;
export declare const MarkerSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

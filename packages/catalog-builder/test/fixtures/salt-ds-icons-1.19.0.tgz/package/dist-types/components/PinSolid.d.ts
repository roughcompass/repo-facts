import { type IconProps } from "../icon";
export type PinSolidIconProps = IconProps;
export declare const PinSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

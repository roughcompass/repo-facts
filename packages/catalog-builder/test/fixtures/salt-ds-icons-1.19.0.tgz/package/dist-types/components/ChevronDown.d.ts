import { type IconProps } from "../icon";
export type ChevronDownIconProps = IconProps;
export declare const ChevronDownIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

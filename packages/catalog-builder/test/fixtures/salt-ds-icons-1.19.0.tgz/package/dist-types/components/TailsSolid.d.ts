import { type IconProps } from "../icon";
export type TailsSolidIconProps = IconProps;
export declare const TailsSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

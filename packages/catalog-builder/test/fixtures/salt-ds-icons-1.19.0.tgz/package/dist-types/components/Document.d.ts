import { type IconProps } from "../icon";
export type DocumentIconProps = IconProps;
export declare const DocumentIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

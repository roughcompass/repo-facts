import { type IconProps } from "../icon";
export type GuideClosedIconProps = IconProps;
export declare const GuideClosedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SemanticDissatisfiedIconProps = IconProps;
export declare const SemanticDissatisfiedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SemanticNeutralIconProps = IconProps;
export declare const SemanticNeutralIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

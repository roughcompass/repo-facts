import { type IconProps } from "../icon";
export type SaltShakerIconProps = IconProps;
export declare const SaltShakerIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

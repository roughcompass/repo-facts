import { type IconProps } from "../icon";
export type DevicesSolidIconProps = IconProps;
export declare const DevicesSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

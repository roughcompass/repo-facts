import { type IconProps } from "../icon";
export type ChartScatterIconProps = IconProps;
export declare const ChartScatterIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

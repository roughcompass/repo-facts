import { type IconProps } from "../icon";
export type CalculatorSolidIconProps = IconProps;
export declare const CalculatorSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

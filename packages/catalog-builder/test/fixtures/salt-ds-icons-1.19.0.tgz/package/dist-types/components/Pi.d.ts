import { type IconProps } from "../icon";
export type PiIconProps = IconProps;
export declare const PiIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

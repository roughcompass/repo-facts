import { type IconProps } from "../icon";
export type CloudSolidIconProps = IconProps;
export declare const CloudSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

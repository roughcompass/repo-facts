import { type IconProps } from "../icon";
export type RedoIconProps = IconProps;
export declare const RedoIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

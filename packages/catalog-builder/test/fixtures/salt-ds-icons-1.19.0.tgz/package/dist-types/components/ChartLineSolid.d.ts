import { type IconProps } from "../icon";
export type ChartLineSolidIconProps = IconProps;
export declare const ChartLineSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

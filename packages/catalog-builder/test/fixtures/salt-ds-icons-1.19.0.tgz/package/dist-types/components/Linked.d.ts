import { type IconProps } from "../icon";
export type LinkedIconProps = IconProps;
export declare const LinkedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

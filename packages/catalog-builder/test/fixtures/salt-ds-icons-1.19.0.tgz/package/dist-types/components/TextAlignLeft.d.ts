import { type IconProps } from "../icon";
export type TextAlignLeftIconProps = IconProps;
export declare const TextAlignLeftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

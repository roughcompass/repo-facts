import { type IconProps } from "../icon";
export type CollapseAllIconProps = IconProps;
export declare const CollapseAllIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

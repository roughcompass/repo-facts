import { type IconProps } from "../icon";
export type InfoIconProps = IconProps;
export declare const InfoIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

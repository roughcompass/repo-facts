import { type IconProps } from "../icon";
export type CloudDownloadIconProps = IconProps;
export declare const CloudDownloadIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type LocationIconProps = IconProps;
export declare const LocationIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type DisplayIconProps = IconProps;
export declare const DisplayIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

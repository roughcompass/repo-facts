import { type IconProps } from "../icon";
export type DoubleChevronDownIconProps = IconProps;
export declare const DoubleChevronDownIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

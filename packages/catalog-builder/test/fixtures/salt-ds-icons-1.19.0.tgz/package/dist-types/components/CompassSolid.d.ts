import { type IconProps } from "../icon";
export type CompassSolidIconProps = IconProps;
export declare const CompassSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

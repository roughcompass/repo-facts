import { type IconProps } from "../icon";
export type CloudSuccessSolidIconProps = IconProps;
export declare const CloudSuccessSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

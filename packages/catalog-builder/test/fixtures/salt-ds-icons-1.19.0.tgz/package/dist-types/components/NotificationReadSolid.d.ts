import { type IconProps } from "../icon";
export type NotificationReadSolidIconProps = IconProps;
export declare const NotificationReadSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

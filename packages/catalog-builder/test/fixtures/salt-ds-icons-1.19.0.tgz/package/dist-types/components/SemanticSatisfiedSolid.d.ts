import { type IconProps } from "../icon";
export type SemanticSatisfiedSolidIconProps = IconProps;
export declare const SemanticSatisfiedSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

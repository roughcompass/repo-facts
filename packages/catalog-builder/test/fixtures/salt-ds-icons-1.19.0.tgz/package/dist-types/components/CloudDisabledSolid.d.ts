import { type IconProps } from "../icon";
export type CloudDisabledSolidIconProps = IconProps;
export declare const CloudDisabledSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type AccessibleSolidIconProps = IconProps;
export declare const AccessibleSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

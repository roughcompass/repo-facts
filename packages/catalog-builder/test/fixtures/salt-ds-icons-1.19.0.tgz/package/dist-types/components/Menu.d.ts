import { type IconProps } from "../icon";
export type MenuIconProps = IconProps;
export declare const MenuIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

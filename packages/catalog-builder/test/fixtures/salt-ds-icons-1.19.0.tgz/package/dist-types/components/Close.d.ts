import { type IconProps } from "../icon";
export type CloseIconProps = IconProps;
export declare const CloseIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

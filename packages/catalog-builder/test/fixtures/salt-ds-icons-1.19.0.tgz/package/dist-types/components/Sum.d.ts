import { type IconProps } from "../icon";
export type SumIconProps = IconProps;
export declare const SumIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

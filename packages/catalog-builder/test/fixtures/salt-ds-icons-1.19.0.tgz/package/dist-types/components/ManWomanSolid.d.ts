import { type IconProps } from "../icon";
export type ManWomanSolidIconProps = IconProps;
export declare const ManWomanSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

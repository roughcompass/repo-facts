import { type IconProps } from "../icon";
export type HiddenSolidIconProps = IconProps;
export declare const HiddenSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

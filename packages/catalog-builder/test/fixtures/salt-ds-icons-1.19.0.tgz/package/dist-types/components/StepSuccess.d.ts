import { type IconProps } from "../icon";
export type StepSuccessIconProps = IconProps;
/** @deprecated since 1.13.0. Use `SuccessCircleIcon` instead. */
export declare const StepSuccessIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

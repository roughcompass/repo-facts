import { type IconProps } from "../icon";
export type PivotSolidIconProps = IconProps;
export declare const PivotSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

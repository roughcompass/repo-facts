import { type IconProps } from "../icon";
export type CookieIconProps = IconProps;
export declare const CookieIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

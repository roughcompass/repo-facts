import { type IconProps } from "../icon";
export type AddToGridSolidIconProps = IconProps;
export declare const AddToGridSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type KeyControlIconProps = IconProps;
export declare const KeyControlIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CartSolidIconProps = IconProps;
export declare const CartSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

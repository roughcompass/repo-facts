import { type IconProps } from "../icon";
export type StorageIconProps = IconProps;
export declare const StorageIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

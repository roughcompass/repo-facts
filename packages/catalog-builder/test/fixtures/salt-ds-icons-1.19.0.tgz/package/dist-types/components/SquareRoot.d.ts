import { type IconProps } from "../icon";
export type SquareRootIconProps = IconProps;
export declare const SquareRootIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

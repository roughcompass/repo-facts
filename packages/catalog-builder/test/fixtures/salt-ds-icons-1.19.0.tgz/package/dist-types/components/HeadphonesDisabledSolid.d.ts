import { type IconProps } from "../icon";
export type HeadphonesDisabledSolidIconProps = IconProps;
export declare const HeadphonesDisabledSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

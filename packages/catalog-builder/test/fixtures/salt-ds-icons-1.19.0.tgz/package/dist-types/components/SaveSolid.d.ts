import { type IconProps } from "../icon";
export type SaveSolidIconProps = IconProps;
export declare const SaveSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

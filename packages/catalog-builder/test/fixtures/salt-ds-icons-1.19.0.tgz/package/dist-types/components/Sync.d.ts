import { type IconProps } from "../icon";
export type SyncIconProps = IconProps;
export declare const SyncIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

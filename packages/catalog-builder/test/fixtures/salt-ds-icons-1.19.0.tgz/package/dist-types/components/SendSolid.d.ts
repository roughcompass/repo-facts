import { type IconProps } from "../icon";
export type SendSolidIconProps = IconProps;
export declare const SendSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

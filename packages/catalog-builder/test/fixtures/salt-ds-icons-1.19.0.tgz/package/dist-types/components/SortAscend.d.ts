import { type IconProps } from "../icon";
export type SortAscendIconProps = IconProps;
export declare const SortAscendIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

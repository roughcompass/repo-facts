import { type IconProps } from "../icon";
export type ChattingIconProps = IconProps;
export declare const ChattingIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

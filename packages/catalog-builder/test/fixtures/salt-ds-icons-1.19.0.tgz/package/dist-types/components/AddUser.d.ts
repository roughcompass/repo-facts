import { type IconProps } from "../icon";
export type AddUserIconProps = IconProps;
export declare const AddUserIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SparkleRefreshIconProps = IconProps;
export declare const SparkleRefreshIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

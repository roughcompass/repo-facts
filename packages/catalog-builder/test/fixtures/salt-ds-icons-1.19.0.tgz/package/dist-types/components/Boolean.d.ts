import { type IconProps } from "../icon";
export type BooleanIconProps = IconProps;
export declare const BooleanIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PauseIconProps = IconProps;
export declare const PauseIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

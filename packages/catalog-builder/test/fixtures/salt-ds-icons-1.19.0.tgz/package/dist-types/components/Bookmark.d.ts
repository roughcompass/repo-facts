import { type IconProps } from "../icon";
export type BookmarkIconProps = IconProps;
export declare const BookmarkIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

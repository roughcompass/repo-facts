import { type IconProps } from "../icon";
export type SlideIconProps = IconProps;
export declare const SlideIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

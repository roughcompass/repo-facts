import { type IconProps } from "../icon";
export type BuildReportSolidIconProps = IconProps;
export declare const BuildReportSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ChartCandlestickSolidIconProps = IconProps;
export declare const ChartCandlestickSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

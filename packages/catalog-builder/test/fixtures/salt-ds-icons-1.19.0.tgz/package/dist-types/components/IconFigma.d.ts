import { type IconProps } from "../icon";
export type IconFigmaIconProps = IconProps;
/** @deprecated since 1.16.0. Use `FigmaIcon` instead. */
export declare const IconFigmaIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ErrorExecuteIconProps = IconProps;
/** @deprecated since 1.17.0. Use `NotAllowedIcon` instead. */
export declare const ErrorExecuteIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

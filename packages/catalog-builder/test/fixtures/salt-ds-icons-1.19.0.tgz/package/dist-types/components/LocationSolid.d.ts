import { type IconProps } from "../icon";
export type LocationSolidIconProps = IconProps;
export declare const LocationSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

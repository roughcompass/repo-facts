import { type IconProps } from "../icon";
export type GuideOpenIconProps = IconProps;
export declare const GuideOpenIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

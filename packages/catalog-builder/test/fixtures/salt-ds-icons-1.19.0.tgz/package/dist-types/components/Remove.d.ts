import { type IconProps } from "../icon";
export type RemoveIconProps = IconProps;
export declare const RemoveIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

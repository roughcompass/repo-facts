import { type IconProps } from "../icon";
export type ClockIconProps = IconProps;
export declare const ClockIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

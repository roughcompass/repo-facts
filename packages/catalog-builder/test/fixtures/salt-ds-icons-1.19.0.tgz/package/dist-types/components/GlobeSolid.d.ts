import { type IconProps } from "../icon";
export type GlobeSolidIconProps = IconProps;
export declare const GlobeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

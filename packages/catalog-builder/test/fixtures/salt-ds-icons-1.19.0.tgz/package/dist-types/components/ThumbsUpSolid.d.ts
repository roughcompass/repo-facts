import { type IconProps } from "../icon";
export type ThumbsUpSolidIconProps = IconProps;
export declare const ThumbsUpSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

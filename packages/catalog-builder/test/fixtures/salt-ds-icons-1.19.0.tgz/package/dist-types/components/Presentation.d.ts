import { type IconProps } from "../icon";
export type PresentationIconProps = IconProps;
export declare const PresentationIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

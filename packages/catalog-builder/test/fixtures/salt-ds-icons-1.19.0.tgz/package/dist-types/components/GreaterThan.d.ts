import { type IconProps } from "../icon";
export type GreaterThanIconProps = IconProps;
export declare const GreaterThanIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

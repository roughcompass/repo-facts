import { type IconProps } from "../icon";
export type HierarchySolidIconProps = IconProps;
export declare const HierarchySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

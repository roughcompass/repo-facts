import { type IconProps } from "../icon";
export type BankSolidIconProps = IconProps;
export declare const BankSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

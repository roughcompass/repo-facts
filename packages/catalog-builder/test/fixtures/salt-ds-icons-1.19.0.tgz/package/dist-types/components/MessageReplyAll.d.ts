import { type IconProps } from "../icon";
export type MessageReplyAllIconProps = IconProps;
export declare const MessageReplyAllIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

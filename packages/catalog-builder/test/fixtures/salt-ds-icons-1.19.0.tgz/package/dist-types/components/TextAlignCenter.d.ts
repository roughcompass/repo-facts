import { type IconProps } from "../icon";
export type TextAlignCenterIconProps = IconProps;
export declare const TextAlignCenterIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

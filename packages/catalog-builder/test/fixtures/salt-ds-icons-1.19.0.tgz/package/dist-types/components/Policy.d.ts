import { type IconProps } from "../icon";
export type PolicyIconProps = IconProps;
export declare const PolicyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

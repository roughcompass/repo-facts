import { type IconProps } from "../icon";
export type LaptopSolidIconProps = IconProps;
export declare const LaptopSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

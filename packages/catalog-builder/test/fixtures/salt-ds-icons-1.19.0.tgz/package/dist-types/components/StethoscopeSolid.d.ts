import { type IconProps } from "../icon";
export type StethoscopeSolidIconProps = IconProps;
export declare const StethoscopeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type KeyShiftIconProps = IconProps;
export declare const KeyShiftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

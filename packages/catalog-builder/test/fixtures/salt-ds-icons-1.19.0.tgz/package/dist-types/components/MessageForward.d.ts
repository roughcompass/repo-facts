import { type IconProps } from "../icon";
export type MessageForwardIconProps = IconProps;
export declare const MessageForwardIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

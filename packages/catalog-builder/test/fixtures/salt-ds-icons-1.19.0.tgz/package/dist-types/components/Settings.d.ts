import { type IconProps } from "../icon";
export type SettingsIconProps = IconProps;
export declare const SettingsIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PanelOpenTopSolidIconProps = IconProps;
export declare const PanelOpenTopSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

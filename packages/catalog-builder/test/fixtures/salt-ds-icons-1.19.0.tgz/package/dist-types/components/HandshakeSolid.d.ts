import { type IconProps } from "../icon";
export type HandshakeSolidIconProps = IconProps;
export declare const HandshakeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

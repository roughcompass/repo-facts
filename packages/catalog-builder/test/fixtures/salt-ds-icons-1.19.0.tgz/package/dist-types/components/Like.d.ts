import { type IconProps } from "../icon";
export type LikeIconProps = IconProps;
export declare const LikeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

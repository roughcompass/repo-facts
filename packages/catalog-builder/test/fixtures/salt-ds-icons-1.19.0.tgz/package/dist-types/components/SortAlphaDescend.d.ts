import { type IconProps } from "../icon";
export type SortAlphaDescendIconProps = IconProps;
export declare const SortAlphaDescendIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

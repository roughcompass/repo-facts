import { type IconProps } from "../icon";
export type DarkSolidIconProps = IconProps;
export declare const DarkSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

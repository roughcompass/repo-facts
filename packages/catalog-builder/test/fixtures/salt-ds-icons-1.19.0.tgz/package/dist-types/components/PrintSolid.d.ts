import { type IconProps } from "../icon";
export type PrintSolidIconProps = IconProps;
export declare const PrintSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type EditIconProps = IconProps;
export declare const EditIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

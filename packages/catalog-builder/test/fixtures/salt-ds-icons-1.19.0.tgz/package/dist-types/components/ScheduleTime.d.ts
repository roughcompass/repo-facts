import { type IconProps } from "../icon";
export type ScheduleTimeIconProps = IconProps;
export declare const ScheduleTimeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

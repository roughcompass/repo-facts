import { type IconProps } from "../icon";
export type CropsSolidIconProps = IconProps;
export declare const CropsSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

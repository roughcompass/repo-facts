import { type IconProps } from "../icon";
export type ChartAreaIconProps = IconProps;
export declare const ChartAreaIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

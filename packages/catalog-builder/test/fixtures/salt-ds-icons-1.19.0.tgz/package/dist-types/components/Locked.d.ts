import { type IconProps } from "../icon";
export type LockedIconProps = IconProps;
export declare const LockedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type MaintenanceSolidIconProps = IconProps;
export declare const MaintenanceSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

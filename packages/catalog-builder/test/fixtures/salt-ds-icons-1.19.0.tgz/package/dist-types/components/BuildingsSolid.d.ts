import { type IconProps } from "../icon";
export type BuildingsSolidIconProps = IconProps;
export declare const BuildingsSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

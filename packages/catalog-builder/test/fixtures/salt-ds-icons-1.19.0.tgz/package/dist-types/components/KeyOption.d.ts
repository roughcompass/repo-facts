import { type IconProps } from "../icon";
export type KeyOptionIconProps = IconProps;
export declare const KeyOptionIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

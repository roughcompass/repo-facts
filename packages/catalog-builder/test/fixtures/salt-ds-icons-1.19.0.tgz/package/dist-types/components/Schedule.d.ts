import { type IconProps } from "../icon";
export type ScheduleIconProps = IconProps;
export declare const ScheduleIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

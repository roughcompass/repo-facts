import { type IconProps } from "../icon";
export type ChartPieSolidIconProps = IconProps;
export declare const ChartPieSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

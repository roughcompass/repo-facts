import { type IconProps } from "../icon";
export type FilterClearIconProps = IconProps;
export declare const FilterClearIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

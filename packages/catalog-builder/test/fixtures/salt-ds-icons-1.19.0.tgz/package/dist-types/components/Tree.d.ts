import { type IconProps } from "../icon";
export type TreeIconProps = IconProps;
export declare const TreeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

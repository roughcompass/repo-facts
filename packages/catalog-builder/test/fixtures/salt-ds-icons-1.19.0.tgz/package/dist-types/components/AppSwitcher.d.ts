import { type IconProps } from "../icon";
export type AppSwitcherIconProps = IconProps;
export declare const AppSwitcherIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type TextOrderedListIconProps = IconProps;
export declare const TextOrderedListIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

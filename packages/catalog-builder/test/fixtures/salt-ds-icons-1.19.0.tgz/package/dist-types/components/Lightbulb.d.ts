import { type IconProps } from "../icon";
export type LightbulbIconProps = IconProps;
export declare const LightbulbIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

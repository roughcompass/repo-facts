import { type IconProps } from "../icon";
export type AnnouncementIconProps = IconProps;
export declare const AnnouncementIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

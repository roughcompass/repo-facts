import { type IconProps } from "../icon";
export type MedicalKitSolidIconProps = IconProps;
export declare const MedicalKitSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

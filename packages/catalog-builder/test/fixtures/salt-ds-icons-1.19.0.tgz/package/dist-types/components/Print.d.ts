import { type IconProps } from "../icon";
export type PrintIconProps = IconProps;
export declare const PrintIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

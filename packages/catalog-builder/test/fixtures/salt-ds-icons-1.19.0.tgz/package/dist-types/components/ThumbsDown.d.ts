import { type IconProps } from "../icon";
export type ThumbsDownIconProps = IconProps;
export declare const ThumbsDownIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

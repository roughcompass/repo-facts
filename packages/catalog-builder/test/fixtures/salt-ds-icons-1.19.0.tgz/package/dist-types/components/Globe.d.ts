import { type IconProps } from "../icon";
export type GlobeIconProps = IconProps;
export declare const GlobeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PanelOpenBottomIconProps = IconProps;
export declare const PanelOpenBottomIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type BatterySolidIconProps = IconProps;
export declare const BatterySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

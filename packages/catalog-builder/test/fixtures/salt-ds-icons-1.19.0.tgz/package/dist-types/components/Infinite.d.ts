import { type IconProps } from "../icon";
export type InfiniteIconProps = IconProps;
export declare const InfiniteIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

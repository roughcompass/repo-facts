import { type IconProps } from "../icon";
export type ThumbsDownSolidIconProps = IconProps;
export declare const ThumbsDownSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

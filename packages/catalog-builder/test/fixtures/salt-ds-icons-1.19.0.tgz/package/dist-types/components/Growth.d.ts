import { type IconProps } from "../icon";
export type GrowthIconProps = IconProps;
export declare const GrowthIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

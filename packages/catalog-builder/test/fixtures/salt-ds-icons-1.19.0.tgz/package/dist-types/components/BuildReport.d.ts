import { type IconProps } from "../icon";
export type BuildReportIconProps = IconProps;
export declare const BuildReportIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

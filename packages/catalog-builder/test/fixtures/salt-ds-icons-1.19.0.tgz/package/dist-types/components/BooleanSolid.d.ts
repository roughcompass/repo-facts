import { type IconProps } from "../icon";
export type BooleanSolidIconProps = IconProps;
export declare const BooleanSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

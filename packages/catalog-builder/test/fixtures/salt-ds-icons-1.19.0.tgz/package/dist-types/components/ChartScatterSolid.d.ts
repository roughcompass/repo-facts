import { type IconProps } from "../icon";
export type ChartScatterSolidIconProps = IconProps;
export declare const ChartScatterSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

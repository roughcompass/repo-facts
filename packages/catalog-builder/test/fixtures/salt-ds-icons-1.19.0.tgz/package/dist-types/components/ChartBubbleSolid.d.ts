import { type IconProps } from "../icon";
export type ChartBubbleSolidIconProps = IconProps;
export declare const ChartBubbleSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

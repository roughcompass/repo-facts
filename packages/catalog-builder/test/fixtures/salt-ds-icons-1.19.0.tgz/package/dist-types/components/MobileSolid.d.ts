import { type IconProps } from "../icon";
export type MobileSolidIconProps = IconProps;
export declare const MobileSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

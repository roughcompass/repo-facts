import { type IconProps } from "../icon";
export type BuildingSolidIconProps = IconProps;
export declare const BuildingSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SuccessSmallSolidIconProps = IconProps;
/** @deprecated since 1.13.0. Use `CheckmarkSolidIcon` instead. */
export declare const SuccessSmallSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

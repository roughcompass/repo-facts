import { type IconProps } from "../icon";
export type StopIconProps = IconProps;
export declare const StopIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type MusicSolidIconProps = IconProps;
export declare const MusicSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

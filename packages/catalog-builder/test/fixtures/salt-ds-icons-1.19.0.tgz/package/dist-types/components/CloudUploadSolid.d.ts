import { type IconProps } from "../icon";
export type CloudUploadSolidIconProps = IconProps;
export declare const CloudUploadSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

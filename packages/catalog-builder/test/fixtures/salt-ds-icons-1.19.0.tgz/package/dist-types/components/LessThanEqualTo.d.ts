import { type IconProps } from "../icon";
export type LessThanEqualToIconProps = IconProps;
export declare const LessThanEqualToIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

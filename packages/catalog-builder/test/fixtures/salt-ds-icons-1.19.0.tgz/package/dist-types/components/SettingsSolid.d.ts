import { type IconProps } from "../icon";
export type SettingsSolidIconProps = IconProps;
export declare const SettingsSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

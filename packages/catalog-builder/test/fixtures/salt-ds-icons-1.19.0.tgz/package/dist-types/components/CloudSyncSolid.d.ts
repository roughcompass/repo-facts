import { type IconProps } from "../icon";
export type CloudSyncSolidIconProps = IconProps;
export declare const CloudSyncSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

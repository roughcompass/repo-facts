import { type IconProps } from "../icon";
export type AddToGridIconProps = IconProps;
export declare const AddToGridIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

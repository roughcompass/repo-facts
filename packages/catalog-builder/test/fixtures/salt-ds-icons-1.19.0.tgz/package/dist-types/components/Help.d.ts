import { type IconProps } from "../icon";
export type HelpIconProps = IconProps;
/** @deprecated since 1.18.0. Use `HelpCircleIcon` instead. */
export declare const HelpIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

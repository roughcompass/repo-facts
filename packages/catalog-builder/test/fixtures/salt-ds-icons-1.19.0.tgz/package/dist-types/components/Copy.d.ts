import { type IconProps } from "../icon";
export type CopyIconProps = IconProps;
export declare const CopyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PdfIconProps = IconProps;
export declare const PdfIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

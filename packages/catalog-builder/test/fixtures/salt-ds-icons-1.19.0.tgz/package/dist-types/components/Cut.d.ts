import { type IconProps } from "../icon";
export type CutIconProps = IconProps;
export declare const CutIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

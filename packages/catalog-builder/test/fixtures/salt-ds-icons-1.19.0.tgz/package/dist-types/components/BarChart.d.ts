import { type IconProps } from "../icon";
export type BarChartIconProps = IconProps;
/** @deprecated since 1.16.0. Use `ChartBarIcon` instead. */
export declare const BarChartIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

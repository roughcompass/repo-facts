import { type IconProps } from "../icon";
export type ClosedcaptionIconProps = IconProps;
export declare const ClosedcaptionIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

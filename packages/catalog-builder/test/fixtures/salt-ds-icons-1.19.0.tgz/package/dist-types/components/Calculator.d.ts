import { type IconProps } from "../icon";
export type CalculatorIconProps = IconProps;
export declare const CalculatorIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

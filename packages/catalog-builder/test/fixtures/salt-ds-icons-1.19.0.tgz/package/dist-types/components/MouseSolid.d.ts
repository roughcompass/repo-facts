import { type IconProps } from "../icon";
export type MouseSolidIconProps = IconProps;
export declare const MouseSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

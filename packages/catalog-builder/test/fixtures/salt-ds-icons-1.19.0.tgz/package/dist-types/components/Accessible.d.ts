import { type IconProps } from "../icon";
export type AccessibleIconProps = IconProps;
export declare const AccessibleIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type TagSolidIconProps = IconProps;
export declare const TagSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

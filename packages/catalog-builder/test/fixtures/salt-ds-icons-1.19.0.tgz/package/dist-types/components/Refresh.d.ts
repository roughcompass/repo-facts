import { type IconProps } from "../icon";
export type RefreshIconProps = IconProps;
export declare const RefreshIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

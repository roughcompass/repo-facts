import { type IconProps } from "../icon";
export type HolidayIconProps = IconProps;
export declare const HolidayIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

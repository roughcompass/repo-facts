import { type IconProps } from "../icon";
export type ChatIconProps = IconProps;
export declare const ChatIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type GridSolidIconProps = IconProps;
export declare const GridSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

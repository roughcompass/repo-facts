import { type IconProps } from "../icon";
export type MaximizeSolidIconProps = IconProps;
export declare const MaximizeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

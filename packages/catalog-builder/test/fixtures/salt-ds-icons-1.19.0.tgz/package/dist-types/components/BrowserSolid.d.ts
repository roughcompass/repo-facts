import { type IconProps } from "../icon";
export type BrowserSolidIconProps = IconProps;
export declare const BrowserSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

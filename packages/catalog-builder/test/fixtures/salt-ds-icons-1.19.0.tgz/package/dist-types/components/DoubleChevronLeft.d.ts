import { type IconProps } from "../icon";
export type DoubleChevronLeftIconProps = IconProps;
export declare const DoubleChevronLeftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

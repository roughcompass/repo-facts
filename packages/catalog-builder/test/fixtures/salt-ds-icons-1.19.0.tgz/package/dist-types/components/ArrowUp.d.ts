import { type IconProps } from "../icon";
export type ArrowUpIconProps = IconProps;
export declare const ArrowUpIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ProgressTodoIconProps = IconProps;
export declare const ProgressTodoIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

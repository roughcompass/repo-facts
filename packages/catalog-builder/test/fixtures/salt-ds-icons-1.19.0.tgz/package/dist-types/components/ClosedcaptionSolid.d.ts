import { type IconProps } from "../icon";
export type ClosedcaptionSolidIconProps = IconProps;
export declare const ClosedcaptionSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

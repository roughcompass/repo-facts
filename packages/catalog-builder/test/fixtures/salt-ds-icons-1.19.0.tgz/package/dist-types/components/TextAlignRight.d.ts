import { type IconProps } from "../icon";
export type TextAlignRightIconProps = IconProps;
export declare const TextAlignRightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

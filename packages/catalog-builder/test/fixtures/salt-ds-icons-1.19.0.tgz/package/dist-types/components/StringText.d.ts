import { type IconProps } from "../icon";
export type StringTextIconProps = IconProps;
export declare const StringTextIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

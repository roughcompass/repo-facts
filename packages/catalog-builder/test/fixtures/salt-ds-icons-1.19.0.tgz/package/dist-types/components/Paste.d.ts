import { type IconProps } from "../icon";
export type PasteIconProps = IconProps;
export declare const PasteIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CloudSyncIconProps = IconProps;
export declare const CloudSyncIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

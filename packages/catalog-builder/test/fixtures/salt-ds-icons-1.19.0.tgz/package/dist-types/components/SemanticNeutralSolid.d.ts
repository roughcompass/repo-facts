import { type IconProps } from "../icon";
export type SemanticNeutralSolidIconProps = IconProps;
export declare const SemanticNeutralSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

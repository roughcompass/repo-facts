import { type IconProps } from "../icon";
export type PlaceInIconProps = IconProps;
export declare const PlaceInIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PercentageIconProps = IconProps;
export declare const PercentageIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

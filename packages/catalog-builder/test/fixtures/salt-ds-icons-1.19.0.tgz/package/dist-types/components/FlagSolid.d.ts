import { type IconProps } from "../icon";
export type FlagSolidIconProps = IconProps;
export declare const FlagSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

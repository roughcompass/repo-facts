import { type IconProps } from "../icon";
export type TriangleRightDownIconProps = IconProps;
export declare const TriangleRightDownIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

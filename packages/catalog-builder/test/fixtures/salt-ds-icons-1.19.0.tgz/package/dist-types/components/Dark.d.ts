import { type IconProps } from "../icon";
export type DarkIconProps = IconProps;
export declare const DarkIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type TreeSolidIconProps = IconProps;
export declare const TreeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type RemoveDocumentSolidIconProps = IconProps;
export declare const RemoveDocumentSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

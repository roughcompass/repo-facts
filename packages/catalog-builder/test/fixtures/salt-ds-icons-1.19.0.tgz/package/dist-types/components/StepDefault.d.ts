import { type IconProps } from "../icon";
export type StepDefaultIconProps = IconProps;
export declare const StepDefaultIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

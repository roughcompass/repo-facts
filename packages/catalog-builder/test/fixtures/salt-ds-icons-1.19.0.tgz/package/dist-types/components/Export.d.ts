import { type IconProps } from "../icon";
export type ExportIconProps = IconProps;
export declare const ExportIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

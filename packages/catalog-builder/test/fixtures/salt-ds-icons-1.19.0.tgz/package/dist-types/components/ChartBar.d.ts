import { type IconProps } from "../icon";
export type ChartBarIconProps = IconProps;
export declare const ChartBarIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

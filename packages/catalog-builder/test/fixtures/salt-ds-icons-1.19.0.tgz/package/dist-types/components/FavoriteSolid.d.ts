import { type IconProps } from "../icon";
export type FavoriteSolidIconProps = IconProps;
export declare const FavoriteSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

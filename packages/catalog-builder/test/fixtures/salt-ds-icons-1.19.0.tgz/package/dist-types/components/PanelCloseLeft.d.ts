import { type IconProps } from "../icon";
export type PanelCloseLeftIconProps = IconProps;
export declare const PanelCloseLeftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

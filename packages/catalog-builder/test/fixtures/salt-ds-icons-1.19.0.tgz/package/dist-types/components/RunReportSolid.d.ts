import { type IconProps } from "../icon";
export type RunReportSolidIconProps = IconProps;
export declare const RunReportSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type GuideClosedSolidIconProps = IconProps;
export declare const GuideClosedSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

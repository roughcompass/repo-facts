import { type IconProps } from "../icon";
export type SuccessCircleSolidIconProps = IconProps;
export declare const SuccessCircleSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CsvSolidIconProps = IconProps;
export declare const CsvSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

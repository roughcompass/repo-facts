import { type IconProps } from "../icon";
export type PlaySolidIconProps = IconProps;
export declare const PlaySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

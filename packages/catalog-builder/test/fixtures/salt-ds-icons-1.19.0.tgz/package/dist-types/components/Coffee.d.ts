import { type IconProps } from "../icon";
export type CoffeeIconProps = IconProps;
export declare const CoffeeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type BankCheckSolidIconProps = IconProps;
export declare const BankCheckSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

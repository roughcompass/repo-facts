import { type IconProps } from "../icon";
export type SearchSolidIconProps = IconProps;
export declare const SearchSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

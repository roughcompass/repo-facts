import { type IconProps } from "../icon";
export type JigsawIconProps = IconProps;
export declare const JigsawIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

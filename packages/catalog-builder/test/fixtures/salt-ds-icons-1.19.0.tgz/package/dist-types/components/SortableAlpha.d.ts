import { type IconProps } from "../icon";
export type SortableAlphaIconProps = IconProps;
export declare const SortableAlphaIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

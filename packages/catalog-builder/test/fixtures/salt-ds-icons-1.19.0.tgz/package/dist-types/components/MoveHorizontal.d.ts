import { type IconProps } from "../icon";
export type MoveHorizontalIconProps = IconProps;
export declare const MoveHorizontalIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

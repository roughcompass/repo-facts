import { type IconProps } from "../icon";
export type AddDocumentIconProps = IconProps;
export declare const AddDocumentIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

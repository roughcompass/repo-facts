import { type IconProps } from "../icon";
export type DatabaseIconProps = IconProps;
export declare const DatabaseIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

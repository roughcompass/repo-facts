import { type IconProps } from "../icon";
export type SemanticSatisfiedIconProps = IconProps;
export declare const SemanticSatisfiedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

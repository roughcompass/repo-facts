import { type IconProps } from "../icon";
export type ColumnChooserIconProps = IconProps;
export declare const ColumnChooserIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

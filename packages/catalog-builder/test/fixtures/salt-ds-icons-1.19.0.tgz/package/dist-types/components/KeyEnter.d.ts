import { type IconProps } from "../icon";
export type KeyEnterIconProps = IconProps;
export declare const KeyEnterIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

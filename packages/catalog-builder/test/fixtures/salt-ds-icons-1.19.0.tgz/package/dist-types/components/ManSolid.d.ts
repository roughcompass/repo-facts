import { type IconProps } from "../icon";
export type ManSolidIconProps = IconProps;
export declare const ManSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

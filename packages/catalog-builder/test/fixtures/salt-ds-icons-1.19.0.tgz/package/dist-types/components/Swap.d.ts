import { type IconProps } from "../icon";
export type SwapIconProps = IconProps;
export declare const SwapIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

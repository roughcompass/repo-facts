import { type IconProps } from "../icon";
export type LockedSolidIconProps = IconProps;
export declare const LockedSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

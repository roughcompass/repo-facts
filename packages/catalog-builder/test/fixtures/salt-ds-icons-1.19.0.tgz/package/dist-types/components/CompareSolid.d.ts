import { type IconProps } from "../icon";
export type CompareSolidIconProps = IconProps;
export declare const CompareSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

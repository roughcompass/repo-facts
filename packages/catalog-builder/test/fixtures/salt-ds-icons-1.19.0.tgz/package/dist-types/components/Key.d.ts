import { type IconProps } from "../icon";
export type KeyIconProps = IconProps;
export declare const KeyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

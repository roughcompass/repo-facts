import { type IconProps } from "../icon";
export type PanelCloseTopSolidIconProps = IconProps;
export declare const PanelCloseTopSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

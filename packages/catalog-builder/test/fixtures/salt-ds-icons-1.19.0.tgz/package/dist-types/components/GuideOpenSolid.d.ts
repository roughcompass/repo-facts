import { type IconProps } from "../icon";
export type GuideOpenSolidIconProps = IconProps;
export declare const GuideOpenSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ApiIconProps = IconProps;
export declare const ApiIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

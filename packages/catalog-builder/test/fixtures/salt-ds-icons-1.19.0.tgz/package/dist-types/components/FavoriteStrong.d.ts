import { type IconProps } from "../icon";
export type FavoriteStrongIconProps = IconProps;
export declare const FavoriteStrongIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

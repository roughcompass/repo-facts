import { type IconProps } from "../icon";
export type TravelSolidIconProps = IconProps;
export declare const TravelSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

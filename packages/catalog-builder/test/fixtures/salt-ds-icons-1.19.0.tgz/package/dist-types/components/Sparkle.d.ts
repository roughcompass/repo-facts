import { type IconProps } from "../icon";
export type SparkleIconProps = IconProps;
export declare const SparkleIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ReceiptIconProps = IconProps;
export declare const ReceiptIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

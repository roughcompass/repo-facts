import { type IconProps } from "../icon";
export type ChatGroupIconProps = IconProps;
export declare const ChatGroupIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

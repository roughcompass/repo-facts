import { type IconProps } from "../icon";
export type CloudIconProps = IconProps;
export declare const CloudIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ImageIconProps = IconProps;
export declare const ImageIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

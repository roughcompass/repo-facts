import { type IconProps } from "../icon";
export type GridIconProps = IconProps;
export declare const GridIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

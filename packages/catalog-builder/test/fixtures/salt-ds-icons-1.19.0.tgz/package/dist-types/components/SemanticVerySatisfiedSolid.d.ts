import { type IconProps } from "../icon";
export type SemanticVerySatisfiedSolidIconProps = IconProps;
export declare const SemanticVerySatisfiedSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

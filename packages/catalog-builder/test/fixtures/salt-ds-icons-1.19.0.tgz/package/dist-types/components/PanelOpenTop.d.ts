import { type IconProps } from "../icon";
export type PanelOpenTopIconProps = IconProps;
export declare const PanelOpenTopIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

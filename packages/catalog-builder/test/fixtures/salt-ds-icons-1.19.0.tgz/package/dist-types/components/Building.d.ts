import { type IconProps } from "../icon";
export type BuildingIconProps = IconProps;
export declare const BuildingIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

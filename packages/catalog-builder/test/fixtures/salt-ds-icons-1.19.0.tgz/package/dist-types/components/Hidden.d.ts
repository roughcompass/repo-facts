import { type IconProps } from "../icon";
export type HiddenIconProps = IconProps;
export declare const HiddenIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

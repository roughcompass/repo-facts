import { type IconProps } from "../icon";
export type HomeIconProps = IconProps;
export declare const HomeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

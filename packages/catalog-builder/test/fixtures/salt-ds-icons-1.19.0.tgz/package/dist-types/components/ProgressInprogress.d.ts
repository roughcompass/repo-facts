import { type IconProps } from "../icon";
export type ProgressInprogressIconProps = IconProps;
export declare const ProgressInprogressIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ManWomanIconProps = IconProps;
export declare const ManWomanIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type MapSolidIconProps = IconProps;
export declare const MapSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

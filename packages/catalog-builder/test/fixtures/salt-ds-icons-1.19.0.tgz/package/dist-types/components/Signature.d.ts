import { type IconProps } from "../icon";
export type SignatureIconProps = IconProps;
export declare const SignatureIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SuccessIconProps = IconProps;
/** @deprecated since 1.13.0. Use `CheckmarkIcon` instead. */
export declare const SuccessIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

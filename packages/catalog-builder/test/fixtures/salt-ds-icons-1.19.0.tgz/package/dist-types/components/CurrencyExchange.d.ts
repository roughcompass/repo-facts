import { type IconProps } from "../icon";
export type CurrencyExchangeIconProps = IconProps;
export declare const CurrencyExchangeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

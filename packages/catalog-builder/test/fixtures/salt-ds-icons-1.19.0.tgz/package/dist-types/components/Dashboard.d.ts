import { type IconProps } from "../icon";
export type DashboardIconProps = IconProps;
export declare const DashboardIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

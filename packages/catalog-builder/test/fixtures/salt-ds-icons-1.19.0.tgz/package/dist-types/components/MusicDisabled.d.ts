import { type IconProps } from "../icon";
export type MusicDisabledIconProps = IconProps;
export declare const MusicDisabledIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ArrowLeftIconProps = IconProps;
export declare const ArrowLeftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

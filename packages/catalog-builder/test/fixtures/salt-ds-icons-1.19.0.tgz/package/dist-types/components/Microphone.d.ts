import { type IconProps } from "../icon";
export type MicrophoneIconProps = IconProps;
export declare const MicrophoneIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type CartIconProps = IconProps;
export declare const CartIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

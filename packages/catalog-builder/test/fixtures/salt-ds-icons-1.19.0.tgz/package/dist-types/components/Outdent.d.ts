import { type IconProps } from "../icon";
export type OutdentIconProps = IconProps;
export declare const OutdentIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

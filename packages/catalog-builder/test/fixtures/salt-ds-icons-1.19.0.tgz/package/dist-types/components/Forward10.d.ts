import { type IconProps } from "../icon";
export type Forward10IconProps = IconProps;
export declare const Forward10Icon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SumSolidIconProps = IconProps;
export declare const SumSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

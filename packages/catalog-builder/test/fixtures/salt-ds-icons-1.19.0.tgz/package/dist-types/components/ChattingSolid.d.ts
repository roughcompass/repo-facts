import { type IconProps } from "../icon";
export type ChattingSolidIconProps = IconProps;
export declare const ChattingSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type LineChartSolidIconProps = IconProps;
export declare const LineChartSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

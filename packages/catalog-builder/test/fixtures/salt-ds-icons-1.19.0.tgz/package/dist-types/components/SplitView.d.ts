import { type IconProps } from "../icon";
export type SplitViewIconProps = IconProps;
export declare const SplitViewIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

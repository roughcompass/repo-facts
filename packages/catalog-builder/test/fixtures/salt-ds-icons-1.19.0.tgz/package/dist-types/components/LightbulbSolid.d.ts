import { type IconProps } from "../icon";
export type LightbulbSolidIconProps = IconProps;
export declare const LightbulbSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

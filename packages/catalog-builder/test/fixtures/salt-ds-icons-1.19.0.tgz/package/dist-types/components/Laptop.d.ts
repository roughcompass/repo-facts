import { type IconProps } from "../icon";
export type LaptopIconProps = IconProps;
export declare const LaptopIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SlideSolidIconProps = IconProps;
export declare const SlideSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

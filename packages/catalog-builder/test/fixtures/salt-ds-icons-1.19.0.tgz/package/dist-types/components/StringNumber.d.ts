import { type IconProps } from "../icon";
export type StringNumberIconProps = IconProps;
export declare const StringNumberIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

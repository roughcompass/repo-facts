import { type IconProps } from "../icon";
export type ChartPieIconProps = IconProps;
export declare const ChartPieIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type LineChartIconProps = IconProps;
/** @deprecated since 1.16.0. Use `ChartLineIcon` instead. */
export declare const LineChartIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

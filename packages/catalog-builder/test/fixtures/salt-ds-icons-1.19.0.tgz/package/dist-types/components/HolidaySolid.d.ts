import { type IconProps } from "../icon";
export type HolidaySolidIconProps = IconProps;
export declare const HolidaySolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

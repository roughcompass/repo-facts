import { type IconProps } from "../icon";
export type ChartColumnIconProps = IconProps;
export declare const ChartColumnIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

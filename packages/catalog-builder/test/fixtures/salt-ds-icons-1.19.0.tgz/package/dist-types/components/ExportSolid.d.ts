import { type IconProps } from "../icon";
export type ExportSolidIconProps = IconProps;
export declare const ExportSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

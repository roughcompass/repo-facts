import { type IconProps } from "../icon";
export type Replay10IconProps = IconProps;
export declare const Replay10Icon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

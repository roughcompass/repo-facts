import { type IconProps } from "../icon";
export type MultiplyIconProps = IconProps;
export declare const MultiplyIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

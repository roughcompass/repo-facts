import { type IconProps } from "../icon";
export type FeedbackSolidIconProps = IconProps;
export declare const FeedbackSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

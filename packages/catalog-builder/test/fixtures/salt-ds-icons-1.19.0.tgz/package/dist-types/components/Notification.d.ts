import { type IconProps } from "../icon";
export type NotificationIconProps = IconProps;
export declare const NotificationIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type BuildingsIconProps = IconProps;
export declare const BuildingsIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

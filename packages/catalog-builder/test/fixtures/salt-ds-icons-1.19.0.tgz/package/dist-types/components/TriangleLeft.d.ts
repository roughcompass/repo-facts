import { type IconProps } from "../icon";
export type TriangleLeftIconProps = IconProps;
export declare const TriangleLeftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

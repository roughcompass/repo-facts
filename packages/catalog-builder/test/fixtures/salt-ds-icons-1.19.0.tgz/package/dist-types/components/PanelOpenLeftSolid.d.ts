import { type IconProps } from "../icon";
export type PanelOpenLeftSolidIconProps = IconProps;
export declare const PanelOpenLeftSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ProgressCancelledIconProps = IconProps;
export declare const ProgressCancelledIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

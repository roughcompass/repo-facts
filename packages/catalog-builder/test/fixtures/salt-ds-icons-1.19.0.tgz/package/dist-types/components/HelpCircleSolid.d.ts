import { type IconProps } from "../icon";
export type HelpCircleSolidIconProps = IconProps;
export declare const HelpCircleSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type Forward30IconProps = IconProps;
export declare const Forward30Icon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SendIconProps = IconProps;
export declare const SendIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

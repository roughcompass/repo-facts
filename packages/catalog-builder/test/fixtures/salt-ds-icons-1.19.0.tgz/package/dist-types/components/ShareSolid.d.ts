import { type IconProps } from "../icon";
export type ShareSolidIconProps = IconProps;
export declare const ShareSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

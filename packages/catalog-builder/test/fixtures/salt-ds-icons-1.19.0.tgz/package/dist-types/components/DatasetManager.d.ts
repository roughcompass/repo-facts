import { type IconProps } from "../icon";
export type DatasetManagerIconProps = IconProps;
export declare const DatasetManagerIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

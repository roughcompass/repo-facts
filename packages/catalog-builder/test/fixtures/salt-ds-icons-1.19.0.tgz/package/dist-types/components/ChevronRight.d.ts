import { type IconProps } from "../icon";
export type ChevronRightIconProps = IconProps;
export declare const ChevronRightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type FilterSolidIconProps = IconProps;
export declare const FilterSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type DatabaseSolidIconProps = IconProps;
export declare const DatabaseSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

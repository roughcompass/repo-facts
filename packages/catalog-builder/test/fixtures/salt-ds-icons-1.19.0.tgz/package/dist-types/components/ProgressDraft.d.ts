import { type IconProps } from "../icon";
export type ProgressDraftIconProps = IconProps;
export declare const ProgressDraftIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

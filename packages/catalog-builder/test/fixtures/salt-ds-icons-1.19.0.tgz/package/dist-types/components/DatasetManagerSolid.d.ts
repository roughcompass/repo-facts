import { type IconProps } from "../icon";
export type DatasetManagerSolidIconProps = IconProps;
export declare const DatasetManagerSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type SemanticVerySatisfiedIconProps = IconProps;
export declare const SemanticVerySatisfiedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

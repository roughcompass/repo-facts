import { type IconProps } from "../icon";
export type CoffeeSolidIconProps = IconProps;
export declare const CoffeeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

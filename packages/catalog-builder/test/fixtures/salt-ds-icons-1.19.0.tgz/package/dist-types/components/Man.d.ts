import { type IconProps } from "../icon";
export type ManIconProps = IconProps;
export declare const ManIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

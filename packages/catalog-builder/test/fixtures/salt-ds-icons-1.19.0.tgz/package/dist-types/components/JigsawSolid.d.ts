import { type IconProps } from "../icon";
export type JigsawSolidIconProps = IconProps;
export declare const JigsawSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

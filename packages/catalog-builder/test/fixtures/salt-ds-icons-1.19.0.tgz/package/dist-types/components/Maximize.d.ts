import { type IconProps } from "../icon";
export type MaximizeIconProps = IconProps;
export declare const MaximizeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ProgressCompleteIconProps = IconProps;
export declare const ProgressCompleteIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

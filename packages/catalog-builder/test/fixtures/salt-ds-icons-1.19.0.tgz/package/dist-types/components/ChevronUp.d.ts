import { type IconProps } from "../icon";
export type ChevronUpIconProps = IconProps;
export declare const ChevronUpIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type FolderOpenSolidIconProps = IconProps;
export declare const FolderOpenSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

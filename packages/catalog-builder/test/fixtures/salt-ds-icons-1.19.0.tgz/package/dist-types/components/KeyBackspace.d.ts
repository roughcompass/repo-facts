import { type IconProps } from "../icon";
export type KeyBackspaceIconProps = IconProps;
export declare const KeyBackspaceIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type HomeSolidIconProps = IconProps;
export declare const HomeSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PresentationSolidIconProps = IconProps;
export declare const PresentationSolidIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

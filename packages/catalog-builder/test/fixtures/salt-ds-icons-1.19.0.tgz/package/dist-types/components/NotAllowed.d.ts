import { type IconProps } from "../icon";
export type NotAllowedIconProps = IconProps;
export declare const NotAllowedIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

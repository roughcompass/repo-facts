import { type IconProps } from "../icon";
export type HelpCircleIconProps = IconProps;
export declare const HelpCircleIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

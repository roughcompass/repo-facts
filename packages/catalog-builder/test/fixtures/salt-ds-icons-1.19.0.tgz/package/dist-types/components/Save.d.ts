import { type IconProps } from "../icon";
export type SaveIconProps = IconProps;
export declare const SaveIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

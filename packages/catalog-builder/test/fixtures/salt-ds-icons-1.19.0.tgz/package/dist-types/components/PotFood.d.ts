import { type IconProps } from "../icon";
export type PotFoodIconProps = IconProps;
export declare const PotFoodIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type ShareIconProps = IconProps;
export declare const ShareIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

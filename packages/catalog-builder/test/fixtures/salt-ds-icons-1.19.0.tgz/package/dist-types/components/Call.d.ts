import { type IconProps } from "../icon";
export type CallIconProps = IconProps;
export declare const CallIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

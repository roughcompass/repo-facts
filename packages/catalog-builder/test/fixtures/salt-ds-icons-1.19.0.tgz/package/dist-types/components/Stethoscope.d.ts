import { type IconProps } from "../icon";
export type StethoscopeIconProps = IconProps;
export declare const StethoscopeIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

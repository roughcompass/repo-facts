import { type IconProps } from "../icon";
export type TextHighlightIconProps = IconProps;
export declare const TextHighlightIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;

import { type IconProps } from "../icon";
export type PicnicIconProps = IconProps;
export declare const PicnicIcon: import("react").ForwardRefExoticComponent<IconProps & import("react").RefAttributes<SVGSVGElement>>;
